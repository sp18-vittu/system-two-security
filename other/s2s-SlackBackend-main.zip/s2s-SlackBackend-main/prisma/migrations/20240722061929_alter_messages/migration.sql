-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "splitNextStream" BOOLEAN;
