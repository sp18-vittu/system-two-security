#!/bin/bash
cd /home/ec2-user/app/
npm stop >/dev/null 2>&1 &
