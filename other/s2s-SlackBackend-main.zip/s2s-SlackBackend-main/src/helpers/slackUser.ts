import { User } from "../models";
import { SlackMessage } from "../services/slack";
import { welcome } from "../views";

class SlackUser {
  async create(userSlackId: string, teamSlackId: string) {
    const user = await User.findFirst({
      where: { slackId: userSlackId }
    })

    if (!user) {
      const newUser = await User.create({
        data: {
          slackId: userSlackId,
          team: { connect: { slackId: teamSlackId } }
        }
      })

      const message = new SlackMessage(null, welcome, teamSlackId, userSlackId)
      await message.send()

      return newUser
    }

    return user
  }
}

export default SlackUser;