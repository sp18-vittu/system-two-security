export default abstract class CustomError extends Error {
  abstract statusCode: number;

  constructor(message: string) {
    super(message);
  }

  abstract toJson(): { status: string, errors: { message: string; field?: string }[] };
}