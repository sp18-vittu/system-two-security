import os

from dotenv import load_dotenv

load_dotenv()


class Config:
    def __init__(self):
        self.environment = os.getenv("ENVIRONMENT")
        self.aws_region = os.getenv("AWS_REGION")
        self.s3_bucket = os.getenv("S3_BUCKET")
        self.receive_queue_url = os.getenv("REQUEST_QUEUE_URL")
        self.response_queue_url = os.getenv("RESPONSE_QUEUE_URL")
        self.status_queue_url = os.getenv("STATUS_QUEUE_URL")
        self.rule_conversion_endpoint = os.getenv("RULE_CONVERSION_ENDPOINT")