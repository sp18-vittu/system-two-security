import { Prisma } from "@prisma/client";

type messageArgs = Prisma.MessageUpdateArgs;

interface MessageUpdateArgs {
  model: string;
  operation: string;
  args: messageArgs;
  query: Function;
}

export default MessageUpdateArgs;
