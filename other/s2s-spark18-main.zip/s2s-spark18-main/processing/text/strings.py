import html
import re
import unicodedata

from loguru import logger
from stop_words import get_stop_words


def strip_excessive_newlines_and_spaces(string: str) -> str:
    # collapse repeated spaces into one
    string = re.sub(r"[ \t]+", " ", string)
    # remove spaces before and after newlines
    string = re.sub(r" ?[\n\r] ?", "\n", string)
    # remove excessive newlines
    string = re.sub(r"[\n\r]{2,}", "\n", string)
    return string.lstrip(" ")


def clean_string(string: str) -> str:
    string = html.unescape(string)
    string = unicodedata.normalize("NFKD", string)
    string = strip_excessive_newlines_and_spaces(string)
    return string


def get_last_word_cleaned(string: str) -> str:
    cleaned_word = string.split()[-1].strip(".\"`'*")
    return cleaned_word


def get_last_list_number(string: str) -> int | None:
    last_line = string.strip().split("\n")[-1]
    pattern = r"(\d+)\s*[\.\:\-\)]"
    match = re.match(pattern, last_line)
    if not match:
        return None
    try:
        number = int(match.group(1))
        return number
    except ValueError as e:
        logger.error(f"Error getting last list number: {e}")
        return None


def remove_stop_words(string: str, to_lower: bool = False) -> str:
    if to_lower:
        string = string.lower()
    words = string.split()
    stop_words = get_stop_words("en")
    filtered_words = [word for word in words if word.lower() not in stop_words]
    result = " ".join(filtered_words)
    return result
