import logging
from typing import Generator

import pytest
from loguru import logger

from services import CoreDbClient


class PropagateHandler(logging.Handler):
    """
    A logging handler that propagates Loguru logs to the standard logging library.

    This handler is used to connect Loguru's logging with the standard logging library,
    allowing pytest's caplog fixture to capture log messages emitted by Loguru.
    """

    def emit(self, record: logging.LogRecord) -> None:
        """
        Emit a record.

        Overrides the default emit method of logging.Handler to forward the log record
        to the standard logging library's handlers.

        Args:
            record (logging.LogRecord): The log record to be handled.
        """
        logging.getLogger(record.name).handle(record)


@pytest.fixture()
def enable_log_cap() -> Generator[None, None, None]:
    """
    A pytest fixture that configures Loguru's logger to propagate log records to the
    standard logging handlers. It adds a PropagateHandler to Loguru's logger before
    each test and removes it afterward.
    """
    handler_id = logger.add(PropagateHandler(), format="{message}")
    yield
    logger.remove(handler_id)


@pytest.fixture(autouse=True)
def reset_core_db_client() -> Generator[None, None, None]:
    """
    A pytest fixture that resets the singleton CoreDbClient instance after each test.
    This fixture is automatically applied to every test.
    """
    yield
    CoreDbClient.reset_instance()
