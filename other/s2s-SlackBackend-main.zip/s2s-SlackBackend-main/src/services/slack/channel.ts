import { AxiosResponse } from 'axios';
import AxiosConnection from '../connection';
import { SlackChannelCreatePayload, SlackChannelInvitePayload, SlackChannelArchivePayload } from '../../interfaces';
import { Team } from '../../models';

class SlackChannel {
  private readonly teamId: string;

  constructor(teamId: string) {
    this.teamId = teamId;
  }

  async create(channelName: string): Promise<any> {
    const payload: SlackChannelCreatePayload = {
      name: channelName.toLowerCase(),
    }

    try {
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post('conversations.create', payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }

  async invite(channelId: string, user: string): Promise<any> {
    const payload: SlackChannelInvitePayload = {
      channel: channelId,
      users: user,
    }

    try {
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post('conversations.invite', payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }

  async archive(channelId: string): Promise<any> {
    const payload: SlackChannelArchivePayload = {
      channel: channelId
    }

    try {
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post('conversations.archive', payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }
}

export default SlackChannel;
