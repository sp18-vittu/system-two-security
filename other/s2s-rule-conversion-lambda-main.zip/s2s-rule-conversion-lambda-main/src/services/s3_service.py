import json
import boto3


class S3Service:
    def __init__(self, config):
        self.s3 = boto3.client("s3", region_name=config.aws_region)
        self.config = config

    def upload_object(self, bucket_name, key, data):
        if isinstance(data, dict):
            data = json.dumps(data)
        self.s3.put_object(Bucket=bucket_name, Key=key, Body=data)

    def get_object(self, bucket_name, object_key):
        response = self.s3.get_object(Bucket=bucket_name, Key=object_key)
        return response['Body'].read()

    def list_objects(self, bucket_name, prefix=""):
        response = self.s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        return response.get('Contents', [])

    def delete_object(self, bucket_name, object_key):
        response = self.s3.delete_object(Bucket=bucket_name, Key=object_key)
        return response
