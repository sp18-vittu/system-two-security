import { QuestionType, SlackEventType } from "../../../interfaces";
import S2SChat from "../../s2sChat";
import SlackEvent from "../../../abstracts/slackEvent";
import BlockActionHandler from "./blockActionHandler";
import ViewSubmissionHandler from "./viewSubmissionHandler";

class WorkbenchEvent extends SlackEvent {
  category: string = '';
  question: string = '';
  questionType: QuestionType = QuestionType.CategoryQuestion;
  session: string = '';
  url: string = '';
  focus: string = '';

  constructor(event: any) {
    super(event);
    this.type = this.determineEventType()
  }

  checkSlashCommands(command: string): SlackEventType {
    switch (command) {
      case process.env.WORKBENCH_COMMAND:
        return SlackEventType.WorkbenchCommand;
      case process.env.FOCUS_COMMAND:
        this.focus = this._event.text;
        return SlackEventType.OpenFocus;
      case process.env.REPORT_COMMAND:
        this.url = this._event.text.replace(/\/$/, '');
        this.url = this.url.startsWith('https://') ? this.url : `https://${this.url.replace(/^http:\/\//, '')}`;
        return SlackEventType.ChangeReport;
      default:
        return SlackEventType.Other;
    }
  }

  determineEventType(): SlackEventType {
    switch (this._event.type) {
      case 'block_actions':
        return new BlockActionHandler(this._event).handle(this);
      case 'view_submission':
        return new ViewSubmissionHandler(this._event).handle(this);
      default:
        return this.checkSlashCommands(this._event.command);
    }
  }

  async handle(): Promise<boolean> {
    try {
      const chat = new S2SChat()

      if (this.type === SlackEventType.CategorySelect) {
        await chat.addCategory(this)
      } else if (this.type === SlackEventType.QuestionSelect) {
        await chat.updateQuestionSelect(this, this.question)
      }
      else if (this.type === SlackEventType.QuestionSubmission) {
        await chat.addQuestion(this)
      }
      else if (this.type === SlackEventType.OpenFocus) {
        await chat.openFocusSelect(this)
      }
      else if (this.type === SlackEventType.FocusSelect) {
        await chat.updateFocusSelect(this)
      }
      else if (this.type === SlackEventType.ChangeFocus) {
        await chat.changeFocus(this)
      }
      else if (this.type === SlackEventType.ChangeReport) {
        await chat.changeUrl(this)
      }
      return true
    } catch (err: any) {
      console.log(err.stack)
      return false
    }
  }
}

export default WorkbenchEvent;
