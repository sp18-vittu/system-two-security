import { homeView, homeViewLoggin } from "../views";
import { User } from "../models";
import { SlackView } from "../services/slack";

class HomeView {
  async publish(slackId: string): Promise<any | null> {
    const [isExpired, user] = await User.s2sTokenExpired(slackId)

    homeView.blocks.splice(5, 2)

    if (user?.email && !isExpired) {
      homeView.blocks[1].elements![0].text.text = 'Disconnect'; // @ts-ignore
      delete homeView.blocks[1].elements![0].url;
      homeViewLoggin[1].text.text = `Username: ${user?.email}\nURL: ${user?.requestDomain}.systemtwosecurity.com`
      homeViewLoggin[1].accessory!.url = `https://${user?.requestDomain}.systemtwosecurity.com` // @ts-ignore
      homeView.blocks.push(...homeViewLoggin)
    }
    else {
      homeView.blocks[1].elements![0].text.text = 'Connect';
      Object.assign(homeView.blocks[1].elements![0], { url: `${process.env.SIGNUP_URL!}?user-id=${user.id}` });
    }

    const view = new SlackView(homeView, user!.team.slackId)
    return await view.publish(slackId)
  }
}

export default HomeView;