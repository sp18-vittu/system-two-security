-- AlterTable
ALTER TABLE "User" ALTER COLUMN "chatExpiry" DROP NOT NULL;
