cti_schema = {
    "settings": {
        "index": {
            "number_of_shards": 1,
            "number_of_replicas": 1,
        }
    },
    "mappings": {
        "properties": {
            "url": {"type": "keyword"},
            "base_url": {"type": "keyword"},
            "category": {"type": "keyword"},
            "category_values": {"type": "keyword"},
            "delimiter": {"type": "keyword"},
            "hash": {"type": "keyword"},
            "parsed_content": {"type": "text"},
            "parser": {"type": "keyword"},
            "version": {"type": "keyword"},
            "images": {"type": "keyword"},
            "created": {"type": "date"},
            "modified": {"type": "date"},
            "last_check": {"type": "date"},
            "error": {
                "type": "object",
                "properties": {
                    "code": {"type": "integer"},
                    "message": {"type": "text"},
                },
            },
            "sigma_rules": {"type": "keyword"},
        }
    },
}
