from typing import Any

from .cti_parser import CtiParser


class MicrosoftCtiParser(CtiParser):
    """
    A parser for Microsoft CTI reports.

    Also works for other CTI reports such as Splunk.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.1.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            ignore_tags=["header", "footer"],
            ignore_classes=[
                "header",
                "footer",
                "menu",
                "related",
                "wp-block-msxcm-kicker-container",
            ],
            ignore_ids=["headerArea", "single-tags"],
            ocr=True,
        )
