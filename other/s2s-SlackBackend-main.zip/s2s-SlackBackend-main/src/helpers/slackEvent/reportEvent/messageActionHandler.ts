import ReportEvent from ".";
import { SlackEventType } from "../../../interfaces";

class MessageActionHandler {
  private _event: any;

  constructor(event: any) {
    this._event = event;
  }

  handle(reportEvent: ReportEvent): SlackEventType {
    const textElement = this._event.message.blocks[0].elements[0].elements[0];
    reportEvent.url = textElement.url || textElement.text;
    return SlackEventType.MenuAction;
  }
}

export default MessageActionHandler;
