import { categoryModel, questionInput, urlInput } from "../../views";
import { Category } from "../../interfaces";
import s2sCategory from "./s2sCategory";

class CategoryManager {
  buildCategoryBlocks(category: Category, question: string | null = null): void {
    try {
      categoryModel.blocks.splice(1);
      if (category.url_required) { // @ts-ignore
        categoryModel.blocks.push(urlInput)
      } //@ts-ignore
      categoryModel.blocks.push({
        type: 'section', text: { type: 'mrkdwn', text: `Your search focus is now set to *${s2sCategory.categories.focus.find(f => f.type === category.focus)?.displayName}*` },
      })
      const options = category.questions.slice(0, 4).map(q => ({
        text: { type: 'plain_text', text: q }, value: q
      }));
      options.push({ text: { type: 'plain_text', text: 'Ask Your Question' }, value: 'custom_question' });

      const selectedQuestion = question === 'custom_question' ? question : category.questions.find(q => q === question);
      categoryModel.blocks.push({
        type: 'section', text: { type: 'mrkdwn', text: `*${category.name}*` },
        block_id: 'questions', accessory: {// @ts-ignore
          type: "radio_buttons", action_id: "question_select", options,
          ...(selectedQuestion && { initial_option: { text: { type: 'plain_text', text: selectedQuestion === 'custom_question' ? 'Ask Your Question' : selectedQuestion }, value: selectedQuestion } })
        }
      });// @ts-ignore

      if (selectedQuestion === 'custom_question') categoryModel.blocks.push(questionInput);
    } catch (err: any) {
      console.error(err.stack);
    }
  }

  updateCategoryOptions(allCategories: Category[]): void {
    const options = allCategories.map(category => ({
      text: { type: 'plain_text', text: category.name }, value: category.name
    }));// @ts-ignore
    categoryModel.blocks[0].accessory!.options = options;
    const defaultCategory = allCategories.find(category => category.default);
    if (defaultCategory) categoryModel.blocks[0].accessory!.initial_option = {
      text: { type: 'plain_text', text: defaultCategory.name }, value: defaultCategory.name
    };
  }
}

export default CategoryManager;
