import axios, { AxiosRequestConfig } from "axios";

class AxiosConnection {
  private readonly config: AxiosRequestConfig;

  constructor(baseURL: string, token: string | null = null) {
    this.config = {
      baseURL
    };
    if (token) {
      this.config.headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    }
  }

  connection() {
    return axios.create(this.config);
  }
}

export default AxiosConnection;