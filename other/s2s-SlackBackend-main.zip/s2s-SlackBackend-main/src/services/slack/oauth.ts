import { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import { GrantType, SlackOAuthResponse } from '../../interfaces';
import AxiosConnection from '../connection';

class SlackOAuth {
  private readonly formData = new FormData();
  private readonly connection: AxiosInstance;

  constructor() {
    this.formData.append('client_id', process.env.SLACK_CLIENT_ID || '');
    this.formData.append('client_secret', process.env.SLACK_CLIENT_SECRET || '');
    const axiosConnection = new AxiosConnection(process.env.SLACK_URL!);
    this.connection = axiosConnection.connection();
  }

  async getAccessToken(value: string, type: GrantType): Promise<SlackOAuthResponse> {
    if (type === GrantType.Code) {
      this.formData.append('code', value);
    }
    else {
      this.formData.append('refresh_token', value);
      this.formData.append('grant_type', 'refresh_token');
    }

    const config: AxiosRequestConfig = {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    };

    try {
      const response: AxiosResponse = await this.connection.post('oauth.v2.access', this.formData, config);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }
}

export default SlackOAuth;
