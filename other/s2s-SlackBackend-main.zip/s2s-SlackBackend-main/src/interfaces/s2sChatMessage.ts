interface S2SChatMessage {
  message_id: string;
  message?: string;
  created?: string;
  focus?: string;
  done?: boolean;
  error?: string;
  sources?: [{
    title: string;
    category: string;
    id: string;
  }]
}

export default S2SChatMessage;