import { Request, Response, Router } from "express";
import { Status } from "@prisma/client";

import { SlackOAuth } from "../../services/slack";
import { Team } from "../../models"
import SomethingWentWrongError from "../../errors/somethingWentWrongError";
import { GrantType } from "../../interfaces";
import { SlackUser } from "../../helpers";

const router = Router();

router.post('/', async (req: Request, res: Response) => {
  try {
    const slackOAuth = new SlackOAuth();
    const data = await slackOAuth.getAccessToken(req.body.code as string, GrantType.Code);
    const team = await Team.upsert({
      where: {
        slackId: data.team.id
      },
      update: {
        refreshToken: data.refresh_token,
        status: Status.ACTIVE
      },
      create: {
        refreshToken: data.refresh_token,
        slackId: data.team.id,
        name: data.team.name,
      }
    });

    const slackUser = new SlackUser()
    const user = await slackUser.create(data.authed_user.id, team.slackId);

    res.status(200).send({ message: 'Login successful', data: user });
  } catch (err: any) {
    console.log(err.stack);
    const error = new SomethingWentWrongError()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router