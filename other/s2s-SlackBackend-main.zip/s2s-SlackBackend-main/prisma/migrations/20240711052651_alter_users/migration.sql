-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "expiryDate" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "chatExpiry" INTEGER NOT NULL DEFAULT 0;
