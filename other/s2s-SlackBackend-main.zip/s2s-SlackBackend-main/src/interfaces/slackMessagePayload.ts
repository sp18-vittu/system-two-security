interface SlackMessagePayload {
  channel: string;
  text?: string;
  blocks?: object;
  ts?: string;
  username?: string;
  as_user?: boolean;
}

export default SlackMessagePayload;