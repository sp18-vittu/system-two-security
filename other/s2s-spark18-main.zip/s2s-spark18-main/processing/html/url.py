import os
from urllib.parse import urlparse, urlunparse


def is_url(string: str) -> bool:
    parsed_url = urlparse(string)
    return all([parsed_url.scheme, parsed_url.netloc])


def get_base_url(url: str) -> str:
    parsed_url = urlparse(url)
    base_url = urlunparse((parsed_url.scheme, parsed_url.netloc, "", "", "", ""))
    return base_url


def get_path_from_url(url: str) -> str:
    parsed_url = urlparse(url)
    return parsed_url.path.lstrip("/")


def get_clean_url(url: str) -> str:
    parsed_url = urlparse(url)
    clean_url = urlunparse(
        (parsed_url.scheme, parsed_url.netloc, parsed_url.path.rstrip("/"), "", "", "")
    )
    return clean_url


def get_last_url_part(url: str) -> str:
    parsed_url = urlparse(url)
    last_part = os.path.basename(parsed_url.path).rstrip("/")
    return last_part
