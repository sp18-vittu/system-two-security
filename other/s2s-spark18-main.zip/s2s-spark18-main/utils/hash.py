import hashlib


def calculate_sha256_bytes(bytes: bytes) -> str:
    sha256_hash = hashlib.sha256(bytes).hexdigest()
    return sha256_hash


def calculate_sha256_string(string: str) -> str:
    # Convert the string to bytes using UTF-8 encoding
    bytes = string.encode("utf-8")
    return calculate_sha256_bytes(bytes)


def calculate_sha256_file(file_path: str) -> str:
    with open(file_path, "rb") as file:
        file_bytes = file.read()
        return calculate_sha256_bytes(file_bytes)
