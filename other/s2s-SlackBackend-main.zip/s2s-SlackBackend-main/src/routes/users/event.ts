import { Request, Response, Router } from "express";
import { Status } from "@prisma/client";

import SomethingWentWrongError from "../../errors/somethingWentWrongError";
import { Chat, Message, Team } from "../../models";
import { HomeView, SlackUser } from "../../helpers";
import { SlackMessage } from "../../services/slack";
import { noChat } from "../../views";
import s2sCategory from "../../helpers/s2sChat/s2sCategory";

const router = Router();

router.post('/events', async (req: Request, res: Response) => {
  try {
    let message: string | null = null
    let chatBlock: any = noChat

    if (req.body.event?.type === 'app_uninstalled') {
      await Team.update({
        where: { slackId: req.body.team_id },
        data: { status: Status.INACTIVE }
      })
    }
    else if (req.body.event?.type === 'app_home_opened') {
      const slackUser = new SlackUser()
      await slackUser.create(req.body.event.user, req.body.team_id);
      const homeView = new HomeView()
      await homeView.publish(req.body.event.user)
    }
    else if (req.body.event?.type === 'message' && !req.body.event?.bot_id && !req.body.event?.subtype) {
      const chat = await Chat.findUnique({
        where: { channelId: req.body.event.channel, user: { slackId: req.body.event.user } },
        include: { user: true }
      });

      if (chat && chat.sessionId) {
        await Message.create({
          data: {
            question: req.body.event?.text,
            focus: chat.focus!,
            chatId: chat.id
          },
          include: { chat: true }
        })
        message = `:mag_right: ${s2sCategory.categories.metaData.progressText}`
        chatBlock = null
      }
      await new SlackMessage(message, chatBlock, req.body.event?.team!, req.body.event.channel || req.body.event?.user).send()
    }
    res.status(200).send({ challange: req.body.challenge });
  } catch (err: any) {
    console.log(err.stack);
    const error = new SomethingWentWrongError()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router