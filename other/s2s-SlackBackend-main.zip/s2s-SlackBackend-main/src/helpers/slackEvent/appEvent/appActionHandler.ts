import { SlackEventType } from "../../../interfaces";

class AppActionHandler {
  private _event: any;

  constructor(event: any) {
    this._event = event;
  }

  handle(): SlackEventType {
    const action = this._event.actions[0];
    switch (action.action_id) {
      case 'disconnect':
        return SlackEventType.Disconnect;
      default:
        return SlackEventType.Other;
    }
  }
}

export default AppActionHandler;
