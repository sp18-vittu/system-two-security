-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "focus" TEXT;
