# s2s-spark18

## Description

This repository contains the HTML parsing and CTI content extraction code
from the s2s-agent repository.

- Code for parsing HTML is under `processing/html/html_parser.py`
- Code for CTI extraction is under `parsers`
- Sample prompt for finding attack actions is under `entities/prompts.py`

## Installation

### Requirements

- Python 3.10 or 3.11

### Dependencies

- opensearch server
    - Instructions on how to download and run Opensearch can be found [here](https://opensearch.org/docs/latest/quickstart/)

### Virtual Environment

It is recommended to create and activate a virtual environment:

```bash
$ python -m venv .venv

# LINUX
$ . .venv/bin/activate

# WINDOWS
$ . .venv/Scripts/activate
```

### Install Requirements

```bash
$ pip3 install -r requirements.txt
```

### Create `.env` Environment File

```bash
$ cp .env.example .env
```

Replace all the environment variables in `.env` with valid values.

```bash
CORE_DB_HOST=[insert core db host]
CORE_DB_PORT=[insert core db port number]
CORE_DB_USERNAME=[insert core db username]
CORE_DB_PASSWORD=[insert core db password]
CORE_DB_USE_SSL=[true/false]
```

- `CORE_DB` is the opensearch server

## Dev Setup

### Install pre-commit

This repository requires a successful pre-commit run as part of the pull request checks.
To ensure that your changes will pass a pre-commit run, install the git hook scripts:

```bash
$ pre-commit install
```

Once the git hook scripts are installed, a `git commit` will only be allowed if it passes
all pre-commit hooks.

```bash
$ git commit -m "sample commit"
black....................................................................Passed
flake8...................................................................Passed
isort....................................................................Passed
mypy.....................................................................Passed
pytest-check.............................................................Passed
[user/sample-branch abcd123] sample commit
 17 files changed, 22 insertions(+), 21 deletions(-)
(venv)
```