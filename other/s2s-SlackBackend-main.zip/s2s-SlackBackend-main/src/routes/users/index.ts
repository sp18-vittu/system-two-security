import login from "./login";
import event from "./event";

export default [
  login,
  event
];