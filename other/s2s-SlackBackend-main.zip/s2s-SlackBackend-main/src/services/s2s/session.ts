import { AxiosInstance, AxiosResponse } from 'axios';
import { Prisma } from '@prisma/client';
import AxiosConnection from '../connection';
import { S2SSessionResponse } from '../../interfaces';

type ChatI = Prisma.ChatGetPayload<{ include: { user: { include: { team: true } } } }>;

class S2SSession {
  private readonly chat: ChatI;
  private readonly connection: AxiosInstance;

  constructor(chat: ChatI, token: string) {
    this.chat = chat;
    const axiosConnection = new AxiosConnection(process.env.S2S_URL!, token);
    this.connection = axiosConnection.connection();
  }

  async create(): Promise<S2SSessionResponse> {
    const params = {
      vaultId: this.chat.vaultId,
      reportId: this.chat.reportId,
      mitreLocation: this.chat.mitreLocation,
      globalVault: false
    }

    const payload = {
      sessionName: this.chat.lastQuestion
    }

    try {
      const response: AxiosResponse = await this.connection.post('data/chat', payload, { params });
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }
}

export default S2SSession;
