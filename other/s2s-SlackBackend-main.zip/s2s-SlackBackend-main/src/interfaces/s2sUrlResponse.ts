interface S2SUrlResponse {
  id: number;
  global: boolean;
  uuid: string;
  ctiName: string;
  feedlyStream: any;
  url: string;
  mitreLocation: any;
  intelCount: any;
  urlSHA256: string;
  status: string;
  errorDesc: string;
  creationTime: string;
  reportSource: string;
  datavault: {
    id: number,
    global: boolean
  };
}

export default S2SUrlResponse;