from datetime import datetime, timezone


def get_current_time(format: str = "", utc: bool = True, timespec: str = "auto") -> str:
    """
    Gets the current datetime.

    Args:
    - format (str): The format of the time (defaults to ISO 8601)
    - utc (bool): Whether to return UTC time (defaults to True)

    Returns:
    - str: The formatted datetime
    """
    current_time = datetime.now(timezone.utc) if utc else datetime.now()
    formatted_time = (
        current_time.strftime(format)
        if format
        else current_time.isoformat(timespec=timespec)
    )
    return formatted_time
