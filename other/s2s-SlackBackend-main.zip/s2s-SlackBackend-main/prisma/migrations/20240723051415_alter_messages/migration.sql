-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "error" TEXT;
