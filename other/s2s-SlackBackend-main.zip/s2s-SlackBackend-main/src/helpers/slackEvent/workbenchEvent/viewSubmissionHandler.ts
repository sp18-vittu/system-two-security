import { QuestionType, SlackEventType } from "../../../interfaces";
import WorkbenchEvent from ".";

class ViewSubmissionHandler {
  private _event: any;

  constructor(event: any) {
    this._event = event;
  }

  handle(workbenchEvent: WorkbenchEvent): SlackEventType {
    const callbackId = this._event.view.callback_id;

    switch (callbackId) {
      case 'question_select':
        workbenchEvent.category = this._event.view.state.values.category.category_select.selected_option.value;
        workbenchEvent.question = this._event.view.state?.values?.questions?.question_select?.selected_option?.value;
        if (workbenchEvent.question === 'custom_question') {
          workbenchEvent.questionType = QuestionType.CustomQuestion;
          workbenchEvent.question = this._event.view.state.values.custom_question.custom_question.value;
        }
        workbenchEvent.url = this._event.view.state.values.url?.url?.value?.replace(/\/$/, '');
        if (workbenchEvent.url) workbenchEvent.url = workbenchEvent.url.startsWith('https://') ? workbenchEvent.url : `https://${workbenchEvent.url.replace(/^http:\/\//, '')}`;
        return SlackEventType.QuestionSubmission;
      case 'focus_select':
        workbenchEvent.focus = this._event.view.state.values.focus.focus_select.selected_option.value;
        workbenchEvent.url = this._event.view.state.values.url?.url?.value?.replace(/\/$/, '');
        if (workbenchEvent.url) workbenchEvent.url = workbenchEvent.url.startsWith('https://') ? workbenchEvent.url : `https://${workbenchEvent.url.replace(/^http:\/\//, '')}`;
        return SlackEventType.ChangeFocus;
      default:
        return SlackEventType.Other;
    }
  }
}

export default ViewSubmissionHandler;
