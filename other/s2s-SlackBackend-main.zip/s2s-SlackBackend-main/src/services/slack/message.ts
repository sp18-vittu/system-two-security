import { AxiosResponse } from 'axios';
import AxiosConnection from '../connection';
import { SlackMessagePayload } from '../../interfaces';
import { Team } from '../../models';

class SlackMessage {
  private readonly message: string | null;
  private readonly blocks: object | null;
  private readonly channelId: string;
  private readonly teamId: string;

  constructor(message: string | null, blocks: object | null, teamId: string, channelId: string) {
    this.message = message;
    this.blocks = blocks;
    this.channelId = channelId;
    this.teamId = teamId;
  }

  async send(): Promise<any> {
    const payload: SlackMessagePayload = {
      channel: this.channelId,
    }
    if (this.message) {
      payload.text = this.message
    }
    else if (this.blocks) {
      payload.blocks = this.blocks
    }

    try {
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post('chat.postMessage', payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }

  async update(ts: string): Promise<any> {
    const payload: SlackMessagePayload = {
      channel: this.channelId,
      ts
    }
    if (this.message) {
      payload.text = this.message
    }
    else if (this.blocks) {
      payload.blocks = this.blocks
    }

    try {
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post('chat.update', payload);
      return response.data;
    } catch (error: any) {
      const errorResponse = error.response ? error.response.data : error.message;
      console.error('Error:', { ...errorResponse, retryAfter: error.response.headers['retry-after'] });
      return { ...errorResponse, retryAfter: error.response.headers['retry-after'] };
    }
  }
}

export default SlackMessage;
