class Error:
    class Code:
        BAD_URL = 1001
        NON_CTI = 1002
        NO_CONTENT = 1003
        PARTIAL_CONTENT = 1004
        UNKNOWN = 1005

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message

    def to_dict(self) -> dict:
        return {"code": self.code, "message": self.message}

    def __str__(self) -> str:
        return f"error.code: {self.code}, error.message: {self.message}"

    class Message:
        class Chat:
            DEFAULT = "We're currently experiencing technical difficulties. Please try again later."
            CTI_ERROR = "It appears there was an error, and the CTI report is not accessible. Please ensure that there were no errors encountered while processing the CTI report and that the processing has been completed, then try again."
