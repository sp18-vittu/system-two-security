import asyncio
import os
import sys

parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(parent_dir)


from constants import CTI_INDEX, IMAGE_INDEX  # noqa: E402
from database.schemas import cti_schema, image_schema  # noqa: E402
from parsers import CtiParserFactory  # noqa: E402
from services import CoreDbClient  # noqa: E402


async def main(url: str, txt_path: str, ocr: bool, use_db: bool, force: bool) -> None:
    core_db = CoreDbClient()
    if use_db:
        await core_db.create_index(CTI_INDEX, cti_schema)
        await core_db.create_index(IMAGE_INDEX, image_schema)
    llm_client = None
    parser = CtiParserFactory.create_parser(url, llm_client)
    parser.html_parser.ocr = ocr
    cti_doc = await parser.parse(use_db, force)

    if cti_doc.parsed_content:
        with open(txt_path, "w", encoding="utf-8") as file:
            file.write(cti_doc.parsed_content)

    # token_usage = llm_client.token_usage
    # if not token_usage:
    #     print("No tokens used :D\n")
    #     return
    # for model, usage in token_usage.items():
    #     print(f"Token usage | Model: {model}, Usage: {usage}")


if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    url = input("Enter the url: ")
    filename = input("Enter the output filename: ")
    ocr = input("Use OCR on images? (y/n): ").lower() == "y"
    use_db = input("Use database? (y/n): ").lower() == "y"
    force = input("Force parsing? (y/n): ").lower() == "y" if use_db else False

    asyncio.run(main(url, os.path.join("output", filename), ocr, use_db, force))
