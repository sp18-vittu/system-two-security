import { Prisma } from "@prisma/client";

type ChatUserTeam = Prisma.ChatGetPayload<{ include: { user: { include: { team: true } } } }> | null

export default ChatUserTeam;