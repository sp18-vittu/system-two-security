import axios from "axios";
import { Category, S2SCategoryData } from "../../interfaces";

class S2SCategory {
  categories: S2SCategoryData = { categories: [], metaData: { progressText: '' }, focus: [] };

  async getCategories(forced = false): Promise<S2SCategoryData> {
    if (this.categories.categories.length === 0 || forced) {
      const data = await axios.get(process.env.CATEGORY_URL!)
      this.categories = data.data;
    }
    return this.categories;
  }

  categoryByQuestion(questionText: string): Category | undefined {
    return this.categories.categories.find(c => c.questions.some(q => q === questionText));
  }

  categoryByName(categoryName: string): Category | undefined {
    return this.categories.categories.find(c => c.name === categoryName);
  }

  defaultCategory(): Category | undefined {
    return this.categories.categories.find(c => c.default);
  }
}

const s2sCategory = new S2SCategory();

export default s2sCategory;