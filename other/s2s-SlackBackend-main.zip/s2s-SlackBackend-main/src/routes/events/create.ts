import { Request, Response, Router } from "express";
import { ReportEvent, WorkbenchEvent, AppEvent, SettingsEvent } from "../../helpers";
import { SlackEventType } from "../../interfaces";
import CatchError from "../../errors/catchError";

const router = Router();

router.post('/', async (req: Request, res: Response) => {
  let event: ReportEvent | WorkbenchEvent | AppEvent;
  if (new ReportEvent(req.body).valid())
    event = new ReportEvent(req.body);
  else if (new WorkbenchEvent(req.body).valid())
    event = new WorkbenchEvent(req.body);
  else if (new SettingsEvent(req.body).valid())
    event = new SettingsEvent(req.body);
  else if (new AppEvent(req.body).valid())
    event = new AppEvent(req.body);

  try {
    let message = ''
    if (event!) {
      event!.handle();
      if (event!.type === SlackEventType.ReportCommand && event!.url) message = event!.url
    }
    res.status(200).send(message);
  } catch (err: any) {
    console.log(err.stack);
    const catchErr = new CatchError(event!.team, event!.user)
    const error = await catchErr.handle()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router