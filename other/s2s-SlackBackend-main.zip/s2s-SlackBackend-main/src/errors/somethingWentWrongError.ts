import CustomError from "./customError";

class SomethingWentWrongError extends CustomError {
  statusCode = 422;

  constructor(message: string = "Something went wrong. Please check back again") {
    super(message);
  }

  toJson = () => {
    return { status: 'error', errors: [{ message: this.message }] };
  }
}

export default SomethingWentWrongError;