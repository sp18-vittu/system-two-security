import pytest

import processing.text as pt


@pytest.mark.parametrize(
    "text, expected",
    [
        ("This is a sample text.", "sample text."),
        ("ThIs Is A sAmPlE tExT.", "sAmPlE tExT."),
    ],
)
def test_remove_stop_words(text: str, expected: str) -> None:
    """Tests remove_stop_words removes stop words"""
    assert pt.remove_stop_words(text) == expected


def test_remove_stop_words_to_lower() -> None:
    """Tests remove_stop_words returns lowercase"""
    text = "Make This Lower Case"
    assert pt.remove_stop_words(text, to_lower=True) == "make lower case"
