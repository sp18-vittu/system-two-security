import { Chat as ChatI, ChatStatus, Message as MessageI } from "@prisma/client";
import { Chat, Message, User } from "../../models";
import { ChatUserTeam, QuestionType } from "../../interfaces";
import { ReportEvent, SlackUser } from "../";
import { SlackMessage, SlackView } from "../../services/slack";
import { S2SSession, S2SUrl } from "../../services/s2s";
import s2sCategory from "./s2sCategory";
import CategoryModel from "./categoryModel";
import MarkdownToSlackMessage from "./markdownToSlackMessage";
import { S2SUser } from "..";
import { WorkbenchEvent } from "..";
import { apiFailed, channelRedirect, noChat, noQuestion, noUrl, serverDown } from "../../views"
import FocusModel from "./focusModel";
import { SlackChannel } from "../../services/slack";

class S2SChat {
  private s2sCategories = s2sCategory;
  private chat: ChatUserTeam | null = null;

  private async setChat(event: WorkbenchEvent) {
    const slackUser = new SlackUser();
    const user = await slackUser.create(event.user, event.team);
    if (event.channel) {
      this.chat = await Chat.findUnique({
        where: {
          channelId: event.channel,
          userId: user.id
        },
        include: {
          user: {
            include: { team: true }
          }
        }
      });
    }

    const [isExpired] = await User.s2sTokenExpired(user.slackId)

    if ((user?.email && !isExpired)) {
      const selectedQuestion = event.questionType === QuestionType.CustomQuestion ? event.question : this.s2sCategories.categories.categories.find(c => c.name === event.category)?.questions.find(q => q === event.question);
      if (!this.chat && selectedQuestion) {
        const date = new Date();
        if (user.chatExpiry !== null) date.setDate(date.getDate() + user.chatExpiry)
        date.setHours(23, 59, 59, 999)
        const channel = new SlackChannel(event.team!);
        const response = await channel.create(`${event.question.split(' ').slice(0, 2).join('-')}-${Math.random().toString(36).substring(7)}`);
        this.chat = await Chat.create({
          data: {
            channelId: response.channel?.id,
            userId: user.id,
            category: this.s2sCategories.defaultCategory()?.name,
            expiryDate: user.chatExpiry !== null ? date : null
          },
          include: {
            user: {
              include: { team: true }
            }
          }
        });
        await channel.invite(response.channel?.id, user.slackId);
        channelRedirect.blocks[0].accessory!.url = response.channel?.id ? `slack://channel?id=${response.channel?.id}&team=${event.team}` : ""
        await new SlackView(channelRedirect, this.chat.user.team.slackId!).open(event.triggerId);
      }
    }
    else {
      const s2sUser = new S2SUser(user.slackId, event.team);
      return s2sUser.expired()
    }
  }

  private async updateChat(data: any) {
    if (this.chat) {
      this.chat = await Chat.update({
        where: { id: this.chat.id },
        data,
        include: {
          user: {
            include: { team: true }
          }
        }
      });
    }
  }

  static async archiveExpiredChat() {
    try {
      console.log('Archiving expired chats')
      const query = {
        status: ChatStatus.ACTIVE,
        expiryDate: {
          lte: new Date()
        }
      }

      const chats = await Chat.findMany({
        where: query,
        include: {
          user: {
            include: { team: true }
          }
        }
      })

      await Chat.updateMany({
        where: query,
        data: {
          status: ChatStatus.ARCHIVED
        }
      })

      await Promise.all(chats.map(async chat => {
        await new SlackChannel(chat.user.team.slackId!).archive(chat.channelId!)
      }))
      console.log('Archived expired chats')
    } catch (err: any) {
      console.log(err.stack)
    }
  }

  private async handleTokenExpiration() {
    const user = this.chat!.user
    const s2sUser = new S2SUser(user.slackId, user.team.slackId);
    return s2sUser.expired()
  }

  private async fetchReportId(event?: WorkbenchEvent) {
    if (await this.handleTokenExpiration()) return false;

    const s2sUrl = new S2SUrl(this.chat!.url!, '', this.chat!.user!.s2sToken!);
    const reportData = await s2sUrl.get();
    if (!reportData && event && this.s2sCategories.categoryByName(this.chat?.category!)?.url_required) {
      const report = new ReportEvent({ ...event._event, text: this.chat?.url });
      await report.handle()
      this.updateChat({ status: ChatStatus.PENDING })
    }
    else {
      await this.updateChat({
        reportId: reportData.id,
        ctiId: reportData.urlSHA256,
        mitreLocation: reportData.mitreLocation,
        vaultId: reportData.datavault?.id
      });
    }
  }

  private async createSession() {
    if (await this.handleTokenExpiration()) return false;

    const s2sSession = new S2SSession(this.chat!, this.chat!.user!.s2sToken!);
    const sessionData = await s2sSession.create();
    if (sessionData.id) {
      await this.updateChat({ sessionId: sessionData.id });
    }
    else {
      const message = new SlackMessage(null, serverDown, this.chat?.user.team.slackId!, this.chat?.channelId || this.chat?.user.slackId!)
      await message.send()
    }
  }

  async start(event: WorkbenchEvent) {
    await this.s2sCategories.getCategories()
    await new CategoryModel().open(event);
  }

  async addCategory(event: WorkbenchEvent) {
    await new CategoryModel().update(event, event.category, event.question);
  }

  async updateQuestionSelect(event: WorkbenchEvent, question: string) {
    await new CategoryModel().update(event, event.category, question);
  }

  async startSession(chat: ChatI, event?: WorkbenchEvent) {
    this.chat = await Chat.findUnique({
      where: { id: chat!.id },
      include: { user: { include: { team: true } } }
    })
    this.updateChat({ status: ChatStatus.ACTIVE })
    if (this.chat!.url) await this.fetchReportId(event);
    if (!this.s2sCategories.categoryByName(this.chat?.category!)?.url_required || this.chat?.reportId) {
      await this.createSession();
      if (this.chat!.sessionId) {
        await Message.create({
          data: {
            question: this.chat!.lastQuestion!,
            focus: this.chat!.focus!,
            chatId: this.chat!.id,
          },
          include: {
            chat: true
          }
        })
        await new SlackMessage(`:question: ${this.chat!.lastQuestion!}\n\n:mag_right: ${s2sCategory.categories.metaData.progressText}`, null, this.chat!.user.team.slackId!, this.chat?.channelId!).send()
      }
    }
  }

  async addQuestion(event: WorkbenchEvent) {
    await this.setChat(event);
    if (this.chat) {
      const selectedQuestion = event.questionType === QuestionType.CustomQuestion ? event.question : this.s2sCategories.categories.categories.find(c => c.name === event.category)?.questions.find(q => q === event.question);
      if (selectedQuestion) {
        await this.updateChat({
          category: event.category,
          focus: this.s2sCategories.categoryByName(event.category)?.focus,
          lastQuestion: event.question,
          url: event.url
        });
        await this.startSession(this.chat!, event);
      } else {
        await new SlackMessage(null, noQuestion, event.team!, event.user).send()
      }
    }
  }

  async handleError(message: MessageI, error: any, text: string) {
    if (!error.ok && !message.timestamp) {
      if (message.retryAttempt === 3) {
        new SlackMessage(null, apiFailed, this.chat!.user.team.slackId!, this.chat!.channelId! || this.chat!.user.slackId).send()
      }
      else {
        setTimeout(async () => {
          await this.stream(message, text)
        }, 60000)

        await Message.update({
          where: { id: message.id },
          data: {
            error: JSON.stringify(error),
            retryAttempt: {
              increment: 1
            }
          }
        })
      }
    }
  }

  async stream(message: MessageI, text: string) {
    this.chat = await Chat.findUnique({
      where: { id: message.chatId },
      include: { user: { include: { team: true } } }
    })

    if (message.lastSplitIndex) {
      text = text.slice(message.lastSplitIndex + 1)
    }

    if (text.length > 3500) {
      let firstMessage = text.slice(0, 3500)
      const index = firstMessage.lastIndexOf('\n')
      text = text.slice(0, index)
      await Message.update({
        where: {
          id: message.id
        },
        data: {
          lastSplitIndex: {
            increment: index + 1
          },
          splitNextStream: true
        }
      })
    }

    let streamMessage = message.response ? `${text}\n:dart: Hope that answers your question. How can i assist you further?` : text
    const messageResponse = new MarkdownToSlackMessage(streamMessage)
    let finalMessage = !message.lastSplitIndex ? `*${s2sCategory.categories.focus.find(f => f.type === message.focus)?.displayName}*\n${messageResponse.parse()}` : messageResponse.parse()
    const slackMessage = new SlackMessage(finalMessage, null, this.chat!.user.team.slackId!, message.channelId! || this.chat?.channelId!)
    if (message.timestamp && !message.splitNextStream) {
      const res = await slackMessage.update(message.timestamp);
      if (message.response && res.error && res.error === 'ratelimited') {
        setTimeout(async () => {
          await this.stream(message, text)
        }, parseInt(res.retryAfter) * 1000)
      }
    }
    else if (text!.split(' ').length <= 50 || message.splitNextStream) {
      const res = await slackMessage.send()
      this.handleError(message, res, text)
      if (res.ts) {
        const newMessage = await Message.update({
          where: {
            id: message.id
          },
          data: {
            channelId: this.chat!.channelId,
            splitNextStream: false,
            timestamp: res.ts
          }
        })
        if (newMessage.response) {
          await this.stream(newMessage, newMessage.response)
        }
      }
    }
  }

  async openFocusSelect(event: WorkbenchEvent) {
    await this.setChat(event)
    if (this.chat)
      await new FocusModel().open(event, this.chat?.focus!, this.chat?.url!);
    else {
      await new SlackMessage(null, noChat, event.team!, event.user).send()
    }
  }

  async updateFocusSelect(event: WorkbenchEvent) {
    await this.setChat(event)
    await new FocusModel().update(event, event.focus, this.chat?.url!)
  }

  async changeFocus(event: WorkbenchEvent) {
    await this.setChat(event)
    const focus = s2sCategory.categories.focus.find(f => f.type === event.focus);
    if (focus) {
      await this.updateChat({ focus: event.focus, url: event.url })
      if (focus.type === 'cti') {
        await this.fetchReportId(event);
      }
      await new SlackMessage(`Successfully changed focus to ${focus.displayName}`, null, this.chat!.user.team.slackId!, this.chat!.channelId! || this.chat!.user.slackId).send()
    }
  }

  async changeUrl(event: WorkbenchEvent) {
    await this.setChat(event)
    if (this.chat) {
      if (event.url && event.url !== 'https://') {
        await this.updateChat({ url: event.url })
        await this.fetchReportId(event);
        await new SlackMessage(`Successfully changed report to ${event.url}`, null, this.chat!.user.team.slackId!, this.chat!.channelId! || this.chat!.user.slackId).send()
      }
      else {
        await new SlackMessage(null, noUrl, event.team!, event.channel || event.user).send()
      }
    }
    else {
      await new SlackMessage(null, noChat, event.team!, event.user).send()
    }
  }

  async serverDown(sessionId: number) {
    const chat = await Chat.findFirst({
      where: { sessionId },
      include: { user: { include: { team: true } } }
    })
    const message = new SlackMessage(null, serverDown, chat?.user.team.slackId!, chat?.channelId || chat?.user.slackId!)
    await message.send()
  }
}

export default S2SChat;
