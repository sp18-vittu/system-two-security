-- AlterTable
ALTER TABLE "Message" ALTER COLUMN "response" DROP NOT NULL;
