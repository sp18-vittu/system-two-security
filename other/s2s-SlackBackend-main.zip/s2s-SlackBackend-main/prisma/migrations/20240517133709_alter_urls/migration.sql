/*
  Warnings:

  - A unique constraint covering the columns `[userId,domain,s2sUrlId]` on the table `Url` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[userId,domain,url]` on the table `Url` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "Url_userId_s2sUrlId_key";

-- DropIndex
DROP INDEX "Url_userId_url_key";

-- CreateIndex
CREATE UNIQUE INDEX "Url_userId_domain_s2sUrlId_key" ON "Url"("userId", "domain", "s2sUrlId");

-- CreateIndex
CREATE UNIQUE INDEX "Url_userId_domain_url_key" ON "Url"("userId", "domain", "url");
