import { Message } from "@prisma/client";
import { MessageUpdateArgs, MessageCreateArgs } from "../interfaces";
import { S2SChat } from "../helpers";
import prisma from "./prismaClient";
import Socket from "../utils/socket";

const message = {
  async create({ args, query }: MessageCreateArgs): Promise<Message> {
    const result = await query(args);
    const chat = await prisma.chat.findUnique({
      where: { id: result.chatId },
      include: { user: true }
    })
    const socket = new Socket(chat!.sessionId!, chat!.lastQuestion!, chat!.user.s2sToken!);
    socket.sendMessage(result);
    return result
  },
  async update({ args, query }: MessageUpdateArgs): Promise<Message> {
    const oldMessage = await prisma.message.findUnique({ where: args.where });
    const result = await query(args);

    if (!oldMessage!.response && result.response) {
      await new S2SChat().stream(result, result.response);
    }

    return result;
  }
}

const messageModel = {
  async sendToSlack(id: string, text: string) {
    const message = await prisma.message.findUnique({
      where: { id }
    })

    await new S2SChat().stream(message!, text)
  }
}

export { message, messageModel };