-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "retryAttempt" INTEGER DEFAULT 0;
