class Image:
    def __init__(self, type: str | None, width: int, height: int, size: int):
        self.type = type
        self.width = width
        self.height = height
        self.size = size

        if isinstance(self.type, str):
            self.type = self.type.lower()
