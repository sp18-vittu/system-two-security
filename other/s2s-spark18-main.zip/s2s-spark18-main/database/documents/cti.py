from __future__ import annotations

from typing import List, cast

from entities import CtiCategory, Error


class CtiDocument:
    def __init__(
        self,
        id: str = "",
        url: str | None = None,
        base_url: str | None = None,
        category: str | None = None,
        category_values: List[str] | None = None,
        delimiter: str | None = None,
        hash: str | None = None,
        parsed_content: str | None = None,
        parser: str | None = None,
        version: str | None = None,
        images: List[str] | None = None,
        created: str | None = None,
        modified: str | None = None,
        last_check: str | None = None,
        error: Error | None = None,
        sigma_rules: List[str] | None = None,
    ) -> None:
        self.id = id
        self.url = url
        self.base_url = base_url
        self.category = CtiCategory(category) if category else None
        self.category_values = category_values
        self.delimiter = delimiter
        self.hash = hash
        self.parsed_content = parsed_content
        self.parser = parser
        self.version = version
        self.images = images
        self.created = created
        self.modified = modified
        self.last_check = last_check
        self.error = error
        self.sigma_rules = sigma_rules

    @classmethod
    def from_dict(cls, data: dict) -> CtiDocument:
        id = cast(str, data.get("_id"))
        source = cast(dict, data.get("_source"))
        error_dict = source.get("error", None)
        return cls(
            id=id,
            url=source.get("url"),
            base_url=source.get("base_url"),
            category=source.get("category"),
            category_values=source.get("category_values"),
            delimiter=source.get("delimiter"),
            hash=source.get("hash"),
            parsed_content=source.get("parsed_content"),
            parser=source.get("parser"),
            version=source.get("version"),
            images=source.get("images"),
            created=source.get("created"),
            modified=source.get("modified"),
            last_check=source.get("last_check"),
            error=(
                Error(error_dict["code"], error_dict["message"]) if error_dict else None
            ),
            sigma_rules=source.get("sigma_rules"),
        )

    def to_dict(self) -> dict:
        source = {key: value for key, value in vars(self).items() if value is not None}
        if source.get("error") is not None:
            source["error"] = cast(Error, source["error"]).to_dict()
        if source.get("category") is not None:
            source["category"] = cast(CtiCategory, source["category"]).value
        del source["id"]
        return source
