import { BrowserRouter, Route, Routes } from "react-router-dom";
import Root from "./root";
import Login from "./login";

import "../styles/App.css";
import "react-toastify/dist/ReactToastify.css";

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Root />} />
        <Route path="/login" element={<Login />} />
      </Routes>
    </BrowserRouter>
  );
};

export default App;
