import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";

const Root = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);
  const [isCodeError, setIsCodeError] = useState(false);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get("code");
    const userId = urlParams.get("user-id");

    const apiUrl = process.env.REACT_APP_URL + "/callback";

    if (code) {
      fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ code }),
      })
        .then(async (response) => {
          setIsLoading(false);
          const data = await response.json();
          if (data.data.id) {
            window.localStorage.setItem("id", data.data.id);
            navigate("/login");
          }
        })
        .catch(() => {
          setIsError(true);
          toast("Error fetching details.", {
            type: "error",
          });
        });
    } else if (userId) {
      window.localStorage.setItem("id", userId);
      navigate("/login");
    } else {
      setIsCodeError(true);
      toast("Code or team Id not found.", {
        type: "error",
      });
    }
  }, [navigate]);
  return (
    <div className="container">
      <ToastContainer
        toastClassName={"toast"}
        position="top-center"
        hideProgressBar
        limit={1}
        closeButton={false}
        closeOnClick={false}
      />
      <img src="/assets/logo_big.svg" alt="logo" className="logo_big" />
      <div className="integration">
        <img src="/assets/slack_logo.svg" alt="slack" />
        <img src="/assets/infinity.svg" alt="infinity" />
        <img src="/assets/logo.svg" alt="logo" />
      </div>
      <div className="loading-text">
        {isCodeError
          ? "Something went wrong, please try again later."
          : isLoading
            ? "Please wait for a while. We will redirect you to the login screen."
            : isError
              ? "There was some error fetching the details. Please try again later."
              : "Redirecting you to the login page"}
      </div>
    </div>
  );
};

export default Root;
