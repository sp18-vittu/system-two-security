class MarkdownToSlackMessage {
  private markdown: string;

  constructor(markdown: string) {
    this.markdown = markdown;
  }

  parse(): string {
    const lines = this.markdown.split('\n');
    let message = '';

    lines.forEach((line, i) => {
      line = this.replaceBoldAndItalic(line);

      if (line?.startsWith('# ')) {
        message += `*${line.slice(2)}*\n`;
      } else if (line?.startsWith('## ')) {
        message += `*${line.slice(3)}*\n`;
      } else if (line?.startsWith('### ')) {
        message += `*${line.slice(3)}*\n`;
      } else if (line?.startsWith('- ')) {
        message += `• ${line.slice(2)}\n`;
      } else if (line?.startsWith('> ')) {
        message += `>${line.slice(2)}\n`;
      } else if (line?.startsWith('** ')) {
        message += `>${line.slice(2)}\n`;
      } else if (line?.startsWith('---')) {
        message += `\n`;
      } else if (line?.trim()) {
        message += `${line}\n`;
      }
    });

    return message.trim();
  }

  private replaceBoldAndItalic(line: string): string {
    // Replace italic text: *italic* with _italic_
    line = line.replace(/(^|[^*])\*(\S[^*]*?)\*(?!\*)/g, '$1_$2_');
    // Replace bold text: **bold** with *bold*
    line = line.replace(/\*\*(.*?)\*\*/g, '*$1*');

    line = line.replace('```yaml', '```');
    line = line.replace('```json', '```');
    return line;
  }
}

export default MarkdownToSlackMessage;
