import { Router } from "express";

import eventRouter from "./events";
import reportRouter from "./reports";
import oAuthRouter from "./oauth";
import userRouter from "./users";
import notificationRouter from "./notificaitons";
import redirectRouter from "./redirect";
import chatRouter from "./chats";
import settingRouter from "./settings";

const router = Router();

router.use('/events', eventRouter);
router.use('/reports', reportRouter);
router.use('/callback', oAuthRouter);
router.use('/users', userRouter);
router.use('/notifications', notificationRouter);
router.use('/redirect', redirectRouter);
router.use('/chats', chatRouter);
router.use('/settings', settingRouter);

export default router;