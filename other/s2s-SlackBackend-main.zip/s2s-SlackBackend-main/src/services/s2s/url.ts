import { AxiosInstance, AxiosResponse } from 'axios';
import AxiosConnection from '../connection';
import { S2SUrlResponse } from '../../interfaces';

class S2SUrl {
  private readonly url: string;
  private readonly urlTitle: string;
  private readonly connection: AxiosInstance;

  constructor(url: string, urlTitle: string, token: string) {
    this.url = url;
    this.urlTitle = urlTitle;
    const axiosConnection = new AxiosConnection(process.env.S2S_URL!, token);
    this.connection = axiosConnection.connection();
  }

  async create(): Promise<S2SUrlResponse> {
    const payload = {
      url: this.url,
      ctiName: this.urlTitle
    }

    try {
      const response: AxiosResponse = await this.connection.post('data/slack-upload-cti', null, { params: payload });
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }

  async get(): Promise<S2SUrlResponse> {
    try {
      const response: AxiosResponse = await this.connection.post('data/cti-reports-url/', this.url, { params: { slack: true }, headers: { "Content-Type": 'text/plain' } });
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }
}

export default S2SUrl;
