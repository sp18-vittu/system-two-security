from typing import Any, List

from loguru import logger

import utils
from constants import CTI_INDEX
from database.documents import CtiDocument
from entities import Error
from processing.html import HtmlParser
from services import CoreDbClient

HEADER_DELIMITER = "<-|->"


class CtiParser:
    """
    A general parser for CTI reports.

    Args:
    - url (str): CTI report URL
    - llm_client (Any | None): LLM client, or None
    - include_links (bool): Flag to include links in the output in markdown format.
    - header_delimiter (str | None): Delimiter that will be inserted before each
        header.
    - header_level (int | None): Maximum header level that will be used for splitting.
    - ignore_tags (List[str] | None): List of tags to ignore during parsing.
    - ignore_classes (List[str] | None): List of classes to ignore during parsing.
    - ignore_ids (List[str] | None): List of ids to ignore during parsing.
    - ocr (bool): Flag whether to attempt OCR on images.
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        llm_client: Any | None = None,
        include_links: bool = False,
        header_delimiter: str | None = HEADER_DELIMITER,
        header_level: int = 5,
        ignore_tags: List[str] | None = None,
        ignore_classes: List[str] | None = None,
        ignore_ids: List[str] | None = None,
        ocr: bool = True,
    ) -> None:
        self.html_parser = HtmlParser(
            content=url,
            include_links=include_links,
            header_delimiter=header_delimiter,
            header_level=header_level,
            ignore_tags=ignore_tags,
            ignore_classes=ignore_classes,
            ignore_ids=ignore_ids,
            ocr=ocr,
        )
        self.core_db = CoreDbClient()
        self.llm_client = llm_client

    async def parse(self, use_db: bool = True, force: bool = False) -> CtiDocument:
        """
        Parses the CTI report.

        Args:
        - use_db (bool): Whether to use database (defaults to True).
        - force (bool): Flag to force parsing if URL has already been parsed (defaults
            to False).

        Returns:
        - CTIDocument: The parsed CTIDocument class
        """
        cti_doc = CtiDocument()

        url = self.html_parser.get_url()
        base_url = self.html_parser.get_base_url()
        if url is None or base_url is None:
            msg = f"Failed to parse CTI, bad URL: {self.html_parser.content}"
            logger.error(msg)
            return CtiDocument(error=Error(Error.Code.BAD_URL, msg))

        logger.info(f"Parsing CTI: {url}")
        url_hash = utils.calculate_sha256_string(url)

        try:
            if force or not use_db:
                cti_doc = CtiDocument(
                    id=url_hash,
                    url=url,
                    base_url=base_url,
                    delimiter=HEADER_DELIMITER,
                )
            else:
                # Check if the CTI has already been previously parsed
                timestamp = utils.get_current_time()
                doc_dict = await self.core_db.get_document(CTI_INDEX, url_hash)

                # CTI has been previously parsed
                if doc_dict:
                    logger.info(f"CTI found in database ({url})")
                    cti_doc = CtiDocument.from_dict(doc_dict)
                    cti_doc.last_check = timestamp
                    content = self.html_parser.get_content()
                    if content is None:
                        await self.html_parser.fetch_html_content(url)
                        content = self.html_parser.get_content()
                        if not content:
                            raise Exception("No content retrieved")

                    content_hash = utils.calculate_sha256_string(content)

                    # CTI content has not changed
                    if content_hash == cti_doc.hash:
                        logger.info(
                            "CTI content has not changed. Skip parsing after updating "
                            "`last_check` timestamp in database."
                        )
                        doc_source_dict = cti_doc.to_dict()
                        await self.core_db.upsert(CTI_INDEX, url_hash, doc_source_dict)
                        return cti_doc

                    # CTI content has changed
                    else:
                        cti_doc.modified = timestamp

                # CTI has not been previously parsed, create a new one
                else:
                    cti_doc = CtiDocument(
                        id=url_hash,
                        url=url,
                        base_url=base_url,
                        delimiter=HEADER_DELIMITER,
                        parser=self.__class__.__name__,
                        version=self.version,
                    )

            # Parse the CTI
            await self.html_parser.parse(None, self.llm_client, use_db, force)
            content = self.html_parser.get_content()
            if not content:
                raise Exception("No content retrieved")

            # Collect errors
            if self.html_parser.errors:
                cti_doc.error = Error(
                    Error.Code.PARTIAL_CONTENT, " | ".join(self.html_parser.errors)
                )

            cti_doc.hash = utils.calculate_sha256_string(content)
            cti_doc.parsed_content = self.html_parser.get_parsed_content()
            image_map = self.html_parser.get_image_map()
            cti_doc.images = [key for key in image_map]
            if not cti_doc.created:
                cti_doc.created = utils.get_current_time()

            # Update the database
            if use_db:
                doc_dict = cti_doc.to_dict()
                await self.core_db.upsert(CTI_INDEX, url_hash, doc_dict)

            return cti_doc
        except Exception as e:
            msg = f"Error parsing CTI {url}: {e}"
            logger.error(msg)
            cti_doc.error = Error(Error.Code.NO_CONTENT, msg)
            return cti_doc
