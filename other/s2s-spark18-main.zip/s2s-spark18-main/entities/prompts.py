class Prompt:
    """LLM prompts"""

    class System:
        """System prompts"""

        THREAT_HUNTER = "You are an expert threat hunter and cybersecurity expert. Please follow and respond to all questions."

    class User:
        """User prompts"""

        class Sigma:

            ANALYSIS = """\
The following is an excerpt from a CTI report:

<excerpt>
{}
</excerpt>

Your task is to carefully analyze the excerpt and identify all malicious activities or hunting queries that are explicitly mentioned in the excerpt, and then determine whether there is adequate information provided in the excerpt to write an accurate Sigma rule for each type of activity.

Follow these guidelines for determining what should be considered good candidates for Sigma rules:

1. **Specificity of Command/Process/Query**: Sigma rules require specific commands, processes, or queries to be effective. If an activity is identified by a general description without the exact command, process, or hunting query, or if any of the entities involved in the process are not known, it is not a good candidate for a Sigma rule.

2. **Event Log Visibility**: Activities should be ones that typically generate event logs. If an activity does not generate a specific event log, it is not suitable for Sigma rule creation.

3. **Command/Query Representation**: Avoid creating Sigma rules based on alias, link, or ID representations of commands or queries. The actual command or query should be used to ensure accuracy and effectiveness.

4. **Explicit Information Requirement**: Activities must be accompanied by explicit information within the provided excerpt. If an activity being a good Sigma rule is contingent upon additional information that is not provided or is based on hypothetical conditions ("if" statements), it is NOT a good candidate.

You MUST follow the guidelines above. You will be penalized each time a guideline is not followed.
Your response must contain only the following:
- A numbered list of each malicious activity or hunting query and its analysis, including whether it is a good candidate for a Sigma rule. Each item MUST have its own number, no sub-lists are allowed!"""
