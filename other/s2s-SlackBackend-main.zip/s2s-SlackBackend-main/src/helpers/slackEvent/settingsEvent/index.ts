import { SlackEventType } from "../../../interfaces";
import SlackEvent from "../../../abstracts/slackEvent";
import { SlackView } from "../../../services/slack";
import { settingsModel } from "../../../views";
import { User } from "../../../models";

class SettingsEvent extends SlackEvent {
  chatExpiry: number | null = null;

  constructor(event: any) {
    super(event);
    this.type = this.determineEventType()
  }

  checkSlashCommands(command: string): SlackEventType {
    switch (command) {
      case process.env.SETTINGS_COMMAND:
        return SlackEventType.SettingsCommand;
      default:
        return SlackEventType.Other;
    }
  }

  determineEventType(): SlackEventType {
    switch (this._event.type) {
      case 'view_submission':
        const chatExpiry = this._event.view.state.values.expiry_time_select.expiry_time_select.selected_option.value;
        this.chatExpiry = chatExpiry !== 'never' ? parseInt(chatExpiry) : null;
        return SlackEventType.SettingsSubmit;
      default:
        return this.checkSlashCommands(this._event.command);
    }
  }

  private getExpiryOption(chatExpiry: number) {
    let text = "never"
    let value = "never"

    switch (chatExpiry) {
      case 0:
        text = "End of day"
        value = "0"
        break;
      case 7:
        text = "End of the week"
        value = "7"
        break;
      default:
        break;
    }

    return {
      text: {
        type: "plain_text",
        text
      },
      value
    }
  }

  async handle(): Promise<boolean> {
    try {
      if (this.type === SlackEventType.SettingsCommand) {
        const user = await User.findUnique({
          where: {
            slackId: this.user
          }
        })// @ts-ignore
        settingsModel.blocks[0].accessory.initial_option = this.getExpiryOption(user.chatExpiry)
        const view = new SlackView(settingsModel, this.team);
        await view.open(this.triggerId);
      }
      if (this.type === SlackEventType.SettingsSubmit) {
        await User.update({
          where: {
            slackId: this.user
          },
          data: {
            chatExpiry: this.chatExpiry
          }
        })
      }
      return true
    } catch (err: any) {
      console.log(err.stack)
      return false
    }
  }
}

export default SettingsEvent;
