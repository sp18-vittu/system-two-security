-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "channelId" TEXT,
ADD COLUMN     "timestamp" TEXT;
