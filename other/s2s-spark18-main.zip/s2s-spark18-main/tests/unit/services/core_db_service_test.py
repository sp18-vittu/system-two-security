import threading
from typing import Any, List

import pytest
from pytest_mock import MockerFixture

from constants import SIGMAHQ_ID
from database import AsyncOpenSearchClient
from services import CoreDbClient


def instantiate_core_db_client(instances: List[CoreDbClient]) -> None:
    """Function for testing multiple threads. Appends new instances to list."""
    try:
        instance = CoreDbClient()
        instances.append(instance)
    except Exception:
        pass


def test_core_db_client_multithread_one_init(mocker: MockerFixture) -> None:
    """
    Tests CoreDbClient() inits AsyncOpenSearchClient only once across multiple threads
    """
    mocker.patch.object(AsyncOpenSearchClient, "info", return_value="")
    init_mock = mocker.patch.object(
        AsyncOpenSearchClient, "__init__", return_value=None
    )

    instances: List[CoreDbClient] = []
    num_threads = 10
    threads: List[threading.Thread] = []

    for _ in range(num_threads):
        thread = threading.Thread(
            target=instantiate_core_db_client,
            args=[instances],
        )
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    init_mock.assert_called_once()


def test_core_db_client_multithread_one_instance(mocker: MockerFixture) -> None:
    """
    Tests CoreDbClient() maintains a single instance across multiple threads.
    If CoreDbClient was not thread safe, this test would only fail intermittently.
    Removing the locking mechanism and adding an artificial delay to __new__ would
    guarantee failure.
    """
    mocker.patch.object(AsyncOpenSearchClient, "info", return_value="")

    instances: List[CoreDbClient] = []
    num_threads = 10
    threads: List[threading.Thread] = []

    for _ in range(num_threads):
        thread = threading.Thread(
            target=instantiate_core_db_client,
            args=[instances],
        )
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    assert len(set(instances)) == 1, "Multiple instances were created"


@pytest.mark.asyncio
async def test_get_sigmahq_version_no_client(
    mocker: MockerFixture, enable_log_cap: Any, caplog: Any
) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns empty string when client has not
    been initialized.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=False)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(
        AsyncOpenSearchClient, "get_document", return_value={"version": "1"}
    )
    core_db = CoreDbClient()
    core_db._client = None
    version = await core_db.get_sigmahq_version()

    assert not version
    assert "Client is None, cannot get SigmaHQ version" in caplog.text


@pytest.mark.asyncio
async def test_get_sigmahq_version_no_index(mocker: MockerFixture) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns empty string when SigmaHQ
    index did not previously exist.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=False)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(
        AsyncOpenSearchClient, "get_document", return_value={"version": "1"}
    )
    core_db = CoreDbClient()
    version = await core_db.get_sigmahq_version()

    assert not version


@pytest.mark.asyncio
async def test_get_sigmahq_version_no_document(
    mocker: MockerFixture, enable_log_cap: Any, caplog: Any
) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns empty string when SigmaHQ
    version document is missing.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "get_document", return_value=None)
    core_db = CoreDbClient()
    version = await core_db.get_sigmahq_version()

    assert not version
    assert f"Could not find {SIGMAHQ_ID} doc" in caplog.text


@pytest.mark.asyncio
async def test_get_sigmahq_version_no_source_field(
    mocker: MockerFixture, enable_log_cap: Any, caplog: Any
) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns empty string when SigmaHQ
    version document is missing the `_source` field.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(
        AsyncOpenSearchClient, "get_document", return_value={"not_source": "1"}
    )
    core_db = CoreDbClient()
    version = await core_db.get_sigmahq_version()

    assert not version
    assert f"{SIGMAHQ_ID} doc is missing _source field" in caplog.text


@pytest.mark.asyncio
async def test_get_sigmahq_version_no_version_field(
    mocker: MockerFixture, enable_log_cap: Any, caplog: Any
) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns empty string when SigmaHQ
    version document is missing the `version` field.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(
        AsyncOpenSearchClient,
        "get_document",
        return_value={"_source": {"not_version": "1"}},
    )
    core_db = CoreDbClient()
    version = await core_db.get_sigmahq_version()

    assert not version
    assert f"{SIGMAHQ_ID} doc is missing version field" in caplog.text


@pytest.mark.asyncio
async def test_get_sigmahq_version_success(mocker: MockerFixture) -> None:
    """
    Tests `CoreDbClient.get_sigmahq_version` returns the last parsed SigmaHQ
    release version.
    """
    mocker.patch.object(AsyncOpenSearchClient, "index_exists", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(CoreDbClient, "update_sigmahq_version", return_value=True)
    mocker.patch.object(
        AsyncOpenSearchClient,
        "get_document",
        return_value={"_source": {"version": "1"}},
    )
    core_db = CoreDbClient()
    version = await core_db.get_sigmahq_version()

    assert version == "1"


@pytest.mark.asyncio
async def test_update_sigmahq_version_no_client(mocker: MockerFixture) -> None:
    """
    Tests `CoreDbClient.update_sigmahq_version` returns False if client has not been
    initialized.
    """
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "index", return_value=True)
    core_db = CoreDbClient()
    core_db._client = None
    result = await core_db.update_sigmahq_version("1")

    assert result is False


@pytest.mark.asyncio
async def test_update_sigmahq_version_success(mocker: MockerFixture) -> None:
    """
    Tests `CoreDbClient.update_sigmahq_version` returns True if SigmaHQ version has been
    successfully updated.
    """
    mocker.patch.object(AsyncOpenSearchClient, "create_index", return_value=True)
    mocker.patch.object(AsyncOpenSearchClient, "index", return_value=True)
    core_db = CoreDbClient()
    result = await core_db.update_sigmahq_version("1")

    assert result is True
