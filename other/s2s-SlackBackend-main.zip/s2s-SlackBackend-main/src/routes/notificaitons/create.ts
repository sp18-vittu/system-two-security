import { Request, Response, Router } from "express";
import { ChatStatus, ReportStatus } from "@prisma/client";

import SomethingWentWrongError from "../../errors/somethingWentWrongError";
import { Chat, Url } from "../../models";
import { ReportMessageView, S2SChat } from "../../helpers";

const router = Router();

router.post('/', async (req: Request, res: Response) => {
  try {
    const body = JSON.parse(req.body)
    console.log(body)
    const data = JSON.parse(body.Message)

    await Url.updateMany({
      where: {
        s2sUrlId: data.urlId.toString(),
        domain: data.domain
      },
      data: { reportStatus: data.status === "SUCCESS" ? ReportStatus.Completed : ReportStatus.Failed }
    })

    const urls = await Url.findMany({
      where: {
        s2sUrlId: data.urlId.toString(),
        domain: data.domain
      },
      include: { user: { include: { team: true } } }
    })

    if (urls && urls.length > 0) {
      await Promise.all(urls.map(async (url): Promise<undefined> => {
        const insites = data.intelData?.data
        const reportMessage = new ReportMessageView()
        await reportMessage.send(url, url, url.user, url.user.team.slackId, insites)
        const chats = await Chat.findMany({
          where: { url: url.url, status: ChatStatus.PENDING }
        })
        chats.forEach(async chat => {
          await new S2SChat().startSession(chat)
        })
      }))
    }
    res.status(200).send();
  } catch (err: any) {
    console.log(err.stack);
    const error = new SomethingWentWrongError()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router