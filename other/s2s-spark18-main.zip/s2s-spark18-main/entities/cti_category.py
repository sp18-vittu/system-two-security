from enum import Enum
from typing import List

from pydantic import BaseModel


class CtiCategory(Enum):
    NON_CTI = "non_cti"
    THREAT_ACTOR = "threat_actor"
    MALWARE = "malware"
    VULNERABILITY = "vulnerability"


class CtiCategoryResponse(BaseModel):
    reasoning_steps: List[str]
    category: CtiCategory
    values: List[str]
