import io

from PIL import Image as PILImage

from entities import Image


def get_image_properties(image_bytes: bytes) -> Image:
    """
    Get image properties.

    Args:
    - image_bytes (bytes): The image data in bytes

    Returns:
    - Image: An Image class
    """
    with PILImage.open(io.BytesIO(image_bytes)) as img:
        return Image(img.format, img.size[0], img.size[1], len(image_bytes))
