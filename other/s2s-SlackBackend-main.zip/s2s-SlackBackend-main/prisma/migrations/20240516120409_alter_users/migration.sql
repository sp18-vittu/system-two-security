/*
  Warnings:

  - You are about to drop the column `requestDomain` on the `Team` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Team" DROP COLUMN "requestDomain";

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "requestDomain" TEXT;
