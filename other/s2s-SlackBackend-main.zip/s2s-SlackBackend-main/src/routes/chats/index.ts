import create from "./create";
import focus from "./focus";
import report from "./report";

export default [
  create,
  focus,
  report
];