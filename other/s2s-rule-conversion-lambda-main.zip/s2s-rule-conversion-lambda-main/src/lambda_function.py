import json
from services import SQSService
from utils import Config
from message_processor import MessageProcessor
from loguru import logger


class LambdaHandler:
    def handle_event(self, event, context):
        logger.info(f"Handling message: {event}")
        config = Config()
        sqs_service = SQSService(config)
        message_processor = MessageProcessor()
        try:
            for record in event["Records"]:
                logger.info("Processing record")
                message = json.loads(record["body"])
                logger.info(f"Received message: {message}")

                try:
                    message_processor.process_message(message)
                except Exception as e:
                    logger.error(f"Error processing message: {e}")
                    response_message = message.copy()
                    response_message["error_message"] = str(e)
                    sqs_service.send_message(config.response_queue_url,
                                             response_message)
                    logger.info(
                        f"Sent error message to response queue: {response_message}")
                    sqs_service.send_message(config.status_queue_url, response_message)
                    logger.info(
                        f"Sent error message to status queue: {response_message}")

        except Exception as e:
            logger.error(f"Error processing record: {e}")


def lambda_handler(event, context):
    handler = LambdaHandler()
    handler.handle_event(event, context)
