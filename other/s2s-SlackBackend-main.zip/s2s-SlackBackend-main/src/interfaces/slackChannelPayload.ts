interface SlackChannelCreatePayload {
  name: string;
  is_private?: boolean;
  team_id?: string;
}

interface SlackChannelInvitePayload {
  channel: string;
  users: string;
}

interface SlackChannelArchivePayload {
  channel: string;
}

export { SlackChannelCreatePayload, SlackChannelInvitePayload, SlackChannelArchivePayload };