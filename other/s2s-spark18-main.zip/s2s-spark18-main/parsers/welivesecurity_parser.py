from typing import Any

from .cti_parser import CtiParser


class WelivesecurityCtiParser(CtiParser):
    """
    A parser for Welivesecurity CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            header_level=3,
            ignore_tags=["header", "footer"],
            ignore_classes=[
                "form-wrapper",
                "articles-title-divider",
                "d-block",
                "sidebar",
            ],
            ignore_ids=["disqus_thread"],
            ocr=True,
        )
