-- AlterTable
ALTER TABLE "Message" ALTER COLUMN "lastSplitIndex" SET DEFAULT 0;
