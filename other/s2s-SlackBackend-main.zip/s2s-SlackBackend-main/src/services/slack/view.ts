import { AxiosResponse } from 'axios';
import AxiosConnection from '../connection';
import { Team } from '../../models';

class SlackView {
  private readonly view: string;
  private readonly teamId: string;

  constructor(view: any, teamId: string) {
    this.view = view;
    this.teamId = teamId;
  }

  private async sendRequest(method: string, payload: any): Promise<any> {
    try {
      payload.view = this.view;
      const token = await Team.getSlackAccessToken(this.teamId);
      const response: AxiosResponse = await new AxiosConnection(process.env.SLACK_URL!, token).connection().post(method, payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }

  async open(trigger_id: string): Promise<any> {
    return this.sendRequest('views.open', {
      trigger_id
    });
  }

  async update(view: string): Promise<any> {
    return this.sendRequest('views.update', {
      view_id: view,
    });
  }

  async publish(user_id: string): Promise<any> {
    return this.sendRequest('views.publish', {
      user_id
    });
  }
}

export default SlackView;
