import { ReportStatus, type Url } from "@prisma/client";
import { S2SUrl } from "../services/s2s";
import prisma from "./prismaClient";
import { UrlUpsertArgs } from "../interfaces";

const url = {
  async upsert({ args, query }: UrlUpsertArgs): Promise<Url> {
    const result = await query(args);
    const user = await prisma.user.findUnique({
      where: { id: result.userId },
      include: { team: true }
    })

    const url = new S2SUrl(result.url, result.title, user!.s2sToken!)
    const res = await url.create()
    return await prisma.url.update({
      where: { id: result.id },
      data: {
        s2sUrlId: res.id ? res.id.toString() : null,
        reportStatus: res.id ? ReportStatus.Started : ReportStatus.Failed
      }
    })
  }
}

export default url;