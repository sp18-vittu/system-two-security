import { WorkbenchEvent } from "..";
import { SlackView } from "../../services/slack";
import { categoryModel } from "../../views";
import CategoryManager from "./categoryManager";
import s2sCategory from "./s2sCategory";

class CategoryModel {
  private categoryManager = new CategoryManager();
  private s2sCategories = s2sCategory;

  private async handleView(event: WorkbenchEvent, categoryName?: string, update = false, question: string | null = null): Promise<void> {
    this.categoryManager.updateCategoryOptions(this.s2sCategories.categories.categories);

    const category = this.s2sCategories.categoryByName(categoryName!);
    if (category) {
      this.categoryManager.buildCategoryBlocks(category, question);
    } else {
      this.categoryManager.buildCategoryBlocks(this.s2sCategories.defaultCategory()!, question);
    }// @ts-ignore

    const view = new SlackView(categoryModel, event.team);
    if (update) {
      await view.update(event.view);
    } else {
      await view.open(event.triggerId);
    }
  }

  async open(event: WorkbenchEvent): Promise<void> {
    await this.handleView(event);
  }

  async update(event: WorkbenchEvent, categoryName: string, question: string | null = null): Promise<void> {
    await this.handleView(event, categoryName, true, question);
  }
}

export default CategoryModel;
