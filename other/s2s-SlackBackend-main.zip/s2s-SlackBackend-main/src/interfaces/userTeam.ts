import { Prisma } from "@prisma/client";

type UserTeam = Prisma.UserGetPayload<{ include: { team: true } }> | null

export default UserTeam;