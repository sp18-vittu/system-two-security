import json
from loguru import logger

import lambda_function

if __name__ == "__main__":
    # Test the lambda handler with a sample event
    logger.info(f"Starting test")
    sample_event = {
        "Records": [
            {
                "body": json.dumps(
                    {
                        "request_id": "abc123",
                        "tenant_id": "tenant-123",
                        "target": "splunk",
                        "caller": "api",
                        "scope": "hunt",
                        "config": "eyJ1cmwiOiJodHRwczovLzQ0LjE5Ni4yMDIuMTIxOjgwODkiLCJhdXRoX3Rva2VuIjoiZXlKcmFXUWlPaUp6Y0d4MWJtc3VjMlZqY21WMElpd2lZV3huSWpvaVNGTTFNVElpTENKMlpYSWlPaUoyTWlJc0luUjBlWEFpT2lKemRHRjBhV01pZlEuZXlKcGMzTWlPaUp6Y0d4MWJtc3RZV1J0YVc0Z1puSnZiU0JwY0MweE1DMHdMVEF0TVRNeUxtVmpNaTVwYm5SbGNtNWhiQ0lzSW5OMVlpSTZJbk53YkhWdWF5MWhaRzFwYmlJc0ltRjFaQ0k2SW5KMWJHVXRaWGhsWTNWMGFXOXVMV3hoYldKa1lTSXNJbWxrY0NJNklsTndiSFZ1YXlJc0ltcDBhU0k2SWpZM05XTXlPV1l3TURVM09URmtaakU0TW1Fd01UazBaakE0TVdZNVl6VmlZbVl6T1RBd1pXVTRNREpsT1dFeE9EbGxNV00xTURKa056WmpOekZqTlRBaUxDSnBZWFFpT2pFM01qQXpPVFUyT1RVc0ltVjRjQ0k2TVRjeU9ERTNNVFk1TlN3aWJtSnlJam94TnpJd016azFOamsxZlEub2NUb1dUSFpCSG5NQkdyQzFuMGI5N0g3TmVHajJvdUpoR2tBaUFBTzVkWGhwdXhvSU51aWVhcEFsT1l4aXIwR0VCUmQ0STQxS2tsUFRVOTBlMHJOS3cifQ",
                        "created": "2024-07-02T12:00:00Z",
                        "updated": "2024-07-02T12:00:00Z",
                        "location": "s3://s2s-env-dev/tenant-123/hunt/20240702/abc123/q001",
                        "data": {
                            "type": "rule",
                            "queries": [
                                {
                                    "query_id": "q002",
                                    "log_sources": ["AWS"],
                                    "parent_query_id": "q001",
                                    "query_state": "initialized",
                                    "path": "s3://s2s-env-dev/tenant-123/hunt/20240702/abc123/q001/q002/initial-rules/test_rule.yml",
                                    "description": "Query for successful access logs"
                                },
                                {
                                    "query_id": "q003",
                                    "log_sources": ["Windows Audit"],
                                    "parent_query_id": "q001",
                                    "query_state": "initialized",
                                    "path": "s3://s2s-env-dev/tenant-123/hunt/20240702/abc123/q001/q003/initial-rules/test_rule.yml",
                                    "description": "Query for successful access logs"
                                }
                            ]
                        }
                    }
                )
            }
        ]
    }
    lambda_function.lambda_handler(sample_event, None)
