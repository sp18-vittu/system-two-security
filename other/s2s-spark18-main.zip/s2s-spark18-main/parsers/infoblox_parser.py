from typing import Any

from .cti_parser import CtiParser


class InfobloxCtiParser(CtiParser):
    """
    A parser for Infoblox CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            header_level=3,
            # Do NOT ignore "header"
            # https://systemtwosecurity.atlassian.net/browse/TH-701
            ignore_tags=["head", "aside", "footer"],
            ignore_classes=[
                "logo_container",
                "genesis-skip-link",
                "post-tags",
                "author-posts",
                "carouselwrapper",
                "social-widget",
            ],
            ignore_ids=["et-top-navigation", "mobile-menu", "category-menu"],
            ocr=True,
        )
