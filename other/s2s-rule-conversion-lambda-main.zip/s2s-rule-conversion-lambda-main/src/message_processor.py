import json
import os
import tempfile
from datetime import datetime, timezone
from services import S3Service, SQSService, RuleConversionService
from utils import Config
from loguru import logger
import copy


class MessageProcessor:
    def __init__(self):
        self.config = Config()
        self.s3_service = S3Service(self.config)
        self.sqs_service = SQSService(self.config)
        self.rule_conversion_service = RuleConversionService(self.config)
        self.query_stage = "converted-queries"
        self.query_state = "converted"
        self.query_error_state = "conversion_error"

    def process_message(self, message):
        logger.info("Starting to process message")

        for query in message["data"]["queries"]:
            try:
                logger.info(f"Processing value: {query}")

                rules_content = self._get_rules_content(query["path"])
                logger.info(f"Retrieved rules content from {query['path']}")

                temp_file_path = self._save_to_temp_file(rules_content)
                logger.info(f"Saved rules content to temporary file at {temp_file_path}")

                response_message = self._convert_rule(message, query, temp_file_path)
                logger.info("Converted rule successfully")

                self._upload_to_s3(response_message, query)
                logger.info("Uploaded converted rule to S3")

                self._send_messages(response_message)
                logger.info("Sent response and status messages")

                os.remove(temp_file_path)
                logger.info(f"Removed temporary file {temp_file_path}")

            except Exception as e:
                logger.error(f"Error processing query {query['query_id']}: {str(e)}")
                self._handle_error(e, message, query)

        logger.info("Message processing complete")

    def _get_rules_content(self, rules_path):
        bucket_name = rules_path.split('/')[2]
        object_key = '/'.join(rules_path.split('/')[3:])
        return self.s3_service.get_object(bucket_name, object_key)

    def _save_to_temp_file(self, rules_content):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".yml") as temp_file:
            temp_file.write(rules_content)
            return temp_file.name

    def _convert_rule(self, message, value, temp_file_path):
        query = self.rule_conversion_service.convert_rule(temp_file_path)
        current_time = datetime.now(timezone.utc)
        updated = current_time.strftime('%Y-%m-%dT%H:%M:%SZ')
        s3_key = self._get_s3_key(message["location"], value["query_id"])
        path = f"Upload path s3://{self.config.s3_bucket}/{s3_key}"
        response_message = {
            "request_id": message["request_id"],
            "tenant_id": message["tenant_id"],
            "scope": message["scope"],
            "target": message["target"],
            "caller": message["caller"],
            "config": message["config"],
            "created": message["created"],
            "updated": updated,
            "location": message["location"],
            "data": {
                "description": value["description"],
                "log_sources": value["log_sources"],
                "query": query,
                "query_id": value["query_id"],
                "query_state": self.query_state,
                "path": path,
                "type": "queries"
            }
        }

        if "parent_query_id" in value:
            response_message["data"]["parent_query_id"] = value["parent_query_id"]

        return response_message

    def _upload_to_s3(self, response_message, value):
        s3_key = self._get_s3_key(response_message["location"], value["query_id"])
        logger.info(f"Upload path s3://{self.config.s3_bucket}/{s3_key}")
        self.s3_service.upload_object(self.config.s3_bucket, s3_key,
                                      json.dumps(response_message))

    def _send_messages(self, response_message):
        logger.info(f"Sending Converted Query Message to SQS"
                    f" {self.config.response_queue_url}")
        logger.info(f"Message {response_message}")
        self.sqs_service.send_message(self.config.response_queue_url, response_message)
        status_message = self._create_status_message(response_message)
        logger.info(f"Sending Status Message to SQS {self.config.status_queue_url}")
        logger.info(f"Message {status_message}")
        self.sqs_service.send_message(self.config.status_queue_url, status_message)

    def _create_status_message(self, response_message):
        status_message = copy.deepcopy(response_message)
        s3_key = self._get_s3_key(response_message["location"],
                                  response_message["data"]["query_id"])
        status_message["data"]["path"] = f"s3://{self.config.s3_bucket}/{s3_key}"

        return status_message

    def _get_s3_key(self, location, query_id):
        # Extract the root path from the location
        root_path = "/".join(location.split('/')[3:])
        # Construct the full S3 key
        s3_key = f"{root_path}/{query_id}/converted-queries/{query_id}.json"
        return s3_key

    def _handle_error(self, error, message, query):
        logger.error(f"Handling error for query {query['query_id']}: {str(error)}")
        error_response = self._create_error_response_message(message, query, str(error))
        self._upload_error_to_s3(error_response, query)
        self._send_error_message(error_response)

    def _create_error_response_message(self, message, query, error_message):
        current_time = datetime.now(timezone.utc)
        updated = current_time.strftime('%Y-%m-%dT%H:%M:%SZ')
        key = self._get_s3_key(message["location"], query["query_id"])
        path = f"s3://{self.config.s3_bucket}/{key}"
        error_response = {
            "request_id": message["request_id"],
            "tenant_id": message["tenant_id"],
            "scope": message["scope"],
            "target": message["target"],
            "caller": message["caller"],
            "config": message["config"],
            "created": message["created"],
            "updated": updated,
            "location": message["location"],
            "data": {
                "description": query.get("description", ""),
                "log_sources": query.get("log_sources", []),
                "query_id": query["query_id"],
                "query_state": self.query_error_state,
                "error": error_message,
                "path": path,
                "type": "queries"
            }
        }

        if "parent_query_id" in query:
            error_response["data"]["parent_query_id"] = query["parent_query_id"]

        return error_response

    def _upload_error_to_s3(self, error_response, query):
        s3_key = self._get_s3_key(error_response["location"], query["query_id"])
        logger.info(f"Uploading error response to s3://{self.config.s3_bucket}/{s3_key}")
        self.s3_service.upload_object(self.config.s3_bucket, s3_key, json.dumps(error_response))

    def _send_error_message(self, error_response):
        logger.info(f"Sending Error Message to SQS {self.config.response_queue_url}")
        logger.info(f"Error Message {error_response}")
        self.sqs_service.send_message(self.config.response_queue_url, error_response)
        status_message = self._create_status_message(error_response)
        logger.info(f"Sending Error Status Message to SQS {self.config.status_queue_url}")
        logger.info(f"Status Message {status_message}")
        self.sqs_service.send_message(self.config.status_queue_url, status_message)
