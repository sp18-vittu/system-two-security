from __future__ import annotations

import inspect
import os
import threading
from typing import Any, Dict, List, Set, cast

from dotenv import load_dotenv
from loguru import logger

from constants import (
    CHAT_INDEX,
    CTI_SECTION_INDEX,
    DB_SEARCH_SIZE,
    EMBEDDING_MODEL,
    KNN_K,
    MITRE_ID,
    MITRE_INDEX,
    SIGMA_INDEX,
    SIGMAHQ_ID,
)
from database import AsyncOpenSearchClient
from utils import retry_backoff


class CoreDbClient(AsyncOpenSearchClient):
    """
    A thread-safe, singleton client for interacting with the core OpenSearch database.
    It uses environment variables to configure the connection to the core database.
    """

    _client = None
    _lock = threading.Lock()
    _initialized = False

    def __new__(cls) -> CoreDbClient:
        with cls._lock:
            if cls._client is None:
                cls._client = super(CoreDbClient, cls).__new__(cls)
        return cls._client

    def __init__(self) -> None:
        with self._lock:
            if self._initialized:
                return

            logger.debug("Initializing CoreDbClient")
            load_dotenv()
            host = cast(str, os.getenv("CORE_DB_HOST"))
            port = cast(str, os.getenv("CORE_DB_PORT"))
            use_ssl = cast(str, os.getenv("CORE_DB_USE_SSL", "")).lower() == "true"
            username = cast(str, os.getenv("CORE_DB_USERNAME", ""))
            password = cast(str, os.getenv("CORE_DB_PASSWORD", ""))

            super().__init__(host, port, use_ssl, username, password)

            self._add_retry_to_opensearch_calls(max_tries=4, start_wait=5)
            self._initialized = True
            logger.debug("Successfully initialized CoreDbClient")

    async def update_sigmahq_version(self, version: str) -> bool:
        """
        Updates the parsed SigmaHQ release version.

        Returns:
        - bool: Whether the SigmaHQ version was successfully updated
        """
        logger.debug(f"Updating SigmaHQ database version with latest: {version}")
        if self._client is None:
            logger.error("Client is None, cannot update SigmaHQ version")
            return False

        try:
            return await self.index(SIGMA_INDEX, SIGMAHQ_ID, {"version": version})
        except Exception as e:
            logger.error(f"Error updating SigmaHQ version: {e}")
            return False

    async def get_sigmahq_version(self) -> str:
        """
        Gets the last SigmaHQ release version that was parsed.

        Returns:
        - str: The last SigmaHQ release parsed
        """
        logger.debug("Getting last SigmaHQ version that was parsed")
        if self._client is None:
            logger.error("Client is None, cannot get SigmaHQ version")
            return ""

        sigmahq_version_doc: dict | None = None
        try:
            sigmahq_version_doc = await self.get_document(SIGMA_INDEX, SIGMAHQ_ID)
        except Exception as e:
            logger.error(f"Error checking database for SigmaHQ: {e}")
            return ""

        if sigmahq_version_doc is None:
            logger.info(f"Could not find {SIGMAHQ_ID} doc in {SIGMA_INDEX}")
            return ""

        source = sigmahq_version_doc.get("_source")
        if source is None:
            logger.error(f"{SIGMAHQ_ID} doc is missing _source field")
            return ""

        version = cast(dict, source).get("version")
        if version is None:
            logger.error(f"{SIGMAHQ_ID} doc is missing version field")
            return ""

        logger.info(f"Last SigmaHQ release parsed was {version}")
        return str(version)

    async def get_sigma_factory_ids(self, source: str) -> Set[str]:
        """
        Gets the ids of all Sigma factory rules from the core database for the given
        source.

        Args:
        - source - Original source where the sigma file was retrieved

        Returns:
        - set: The set of all Sigma factory rules for the give source
        """
        logger.debug(f"Getting all Sigma rule ids for source: {source}")
        ids: Set[str] = set()
        if self._client is None:
            logger.error("Client is None, cannot get Sigma factory rules")
            return ids

        try:
            body = {"query": {"term": {"source": source}}, "_source": False}
            response = await self.search(SIGMA_INDEX, body, 100_000)
            if not response["hits"]["hits"]:
                logger.warning("No sigma factory rules found")
                return ids

            ids = {hit["_id"] for hit in response["hits"]["hits"]}
            logger.debug(f"Found {len(ids)} document ids for source: {source}")
            return ids
        except Exception as e:
            logger.error(f"Error getting sigma factory rule ids: {e}")
            return ids

    async def get_knn_matches(
        self,
        index: str,
        embedding: List[float],
        must_filters: List[dict] = [],
        must_not_filters: List[dict] = [],
        should_filters: List[dict] = [],
        nested_filters: List[dict] = [],
        model: str = EMBEDDING_MODEL,
        k: int = KNN_K,
        size: int = DB_SEARCH_SIZE,
    ) -> List[Any]:
        filter: List[Dict[str, Any]] = []
        bool_clause: Dict[str, Any] = {}
        if must_filters:
            bool_clause["must"] = [filter for filter in must_filters]
        if must_not_filters:
            bool_clause["must_not"] = [filter for filter in must_not_filters]
        if should_filters:
            bool_clause["should"] = [filter for filter in should_filters]
            bool_clause["minimum_should_match"] = 1
        if bool_clause:
            filter.append({"bool": bool_clause})
        for nested_filter in nested_filters:
            nested_clause: Dict[str, Any] = nested_filter
            filter.append({"nested": nested_clause})

        try:
            response = await self.knn_search(index, filter, embedding, model, k, size)
        except Exception as e:
            logger.error(f"Error getting knn matches: {e}")
            return []

        results = [hit for hit in response["hits"]["hits"]]

        return results

    async def get_cti_sections(
        self, cti_id: str | None = None, cti_url: str | None = None
    ) -> List[dict]:
        sections: List[dict] = []
        if self._client is None:
            logger.error("Client is None, cannot get CTI sections")
            return sections
        if not cti_id and not cti_url:
            logger.error("Either cti_id or cti_url is required to retrieve sections")
            return sections

        term = "cti_id" if cti_id else "cti_url"
        value = cti_id if cti_id else cti_url
        body = {
            "query": {"term": {term: value}},
            "sort": [{"section_num": {"order": "asc"}}],
        }
        logger.debug(f"Getting sections for CTI {value}")

        try:
            response = await self.search(CTI_SECTION_INDEX, body, 1_000)
            if not response["hits"]["hits"]:
                logger.info(f"No sections found for CTI {value}")
                return sections

            sections = response["hits"]["hits"]
            logger.debug(f"Found {len(sections)} sections for CTI {value}")
            return sections
        except Exception as e:
            logger.error(f"Error getting sections for CTI {value}: {e}")
            return sections

    async def get_chat_history(self, session_id: str, latest_n: int) -> List[Any]:
        """
        Gets the list of chat history messages for the given session_id.

        Args:
        - session_id (str): The session id to get chat history for
        - latest_n (int): The number of chat messages to retrieve in desc order

        Returns:
        - List[Any]: The list of chat history messages
        """
        logger.debug(f"Getting chat history for session {session_id}")
        messages: List[Any] = []
        if self._client is None:
            logger.error("Client is None, cannot get chat history")
            return messages

        try:
            body = {
                "query": {"term": {"session_id": session_id}},
                "sort": [{"created": {"order": "desc"}}],
            }
            response = await self.search(CHAT_INDEX, body, latest_n)
            if not response["hits"]["hits"]:
                logger.info(f"No chat history found for session {session_id}")
                return messages

            messages = response["hits"]["hits"]
            logger.debug(f"Found {len(messages)} chat messages for {session_id}")
            messages.sort(key=lambda x: cast(str, x["_source"]["created"]))
            return messages
        except Exception as e:
            logger.error(f"Error getting chat history for {session_id}: {e}")
            return messages

    async def get_mitre_techniques(self, embeddings: bool = False) -> List[Any]:
        """
        Gets the list of MITRE techniques from the Core database.

        Args:
        - embeddings (bool): Whether to include embeddings (defaults to False)

        Returns:
        - List[Any]: The list of hits corresponding to MITRE techniques
        """
        logger.debug(f"Getting MITRE techniques from db (embeddings={embeddings})")
        hits: List[Any] = []
        if self._client is None:
            logger.error("Client is None, cannot get MITRE techniques")
            return hits

        try:
            body: Dict[str, Any] = {
                "query": {"bool": {"must": [{"term": {"type": "attack-pattern"}}]}}
            }
            if not embeddings:
                body["_source"] = {"excludes": [EMBEDDING_MODEL]}
            response = await self.search(MITRE_INDEX, body, 1_000)
            hits = response["hits"]["hits"]
            if not hits:
                logger.info("No MITRE techniques found in database")
                return hits

            logger.debug(f"Found {len(hits)} MITRE techniques")
            return hits
        except Exception as e:
            logger.error(f"Error getting MITRE techniques from database: {e}")
            return hits

    async def get_mitre_tactics(self, embeddings: bool = False) -> List[Any]:
        """
        Gets the list of MITRE tactics from the Core database.

        Args:
        - embeddings (bool): Whether to include embeddings (defaults to False)

        Returns:
        - List[Any]: The list of hits corresponding to MITRE tactics
        """
        logger.debug(f"Getting MITRE tactics from database (embeddings={embeddings})")
        hits: List[Any] = []
        if self._client is None:
            logger.error("Client is None, cannot get MITRE tactics")
            return hits

        try:
            body: Dict[str, Any] = {
                "query": {"bool": {"must": [{"term": {"type": "x-mitre-tactic"}}]}}
            }
            if not embeddings:
                body["_source"] = {"excludes": [EMBEDDING_MODEL]}
            response = await self.search(MITRE_INDEX, body, 1_000)
            hits = response["hits"]["hits"]
            if not hits:
                logger.info("No MITRE tactics found in database")
                return hits

            logger.debug(f"Found {len(hits)} MITRE tactics")
            return hits
        except Exception as e:
            logger.error(f"Error getting MITRE tactics from database: {e}")
            return hits

    async def update_mitre_version(self, version: str) -> bool:
        """
        Updates the parsed MITRE release version.

        Returns:
        - bool: Whether the MITRE version was successfully updated
        """
        logger.debug(f"Updating MITRE database version with latest: {version}")
        if self._client is None:
            logger.error("Client is None, cannot update MITRE version")
            return False

        try:
            return await self.index(MITRE_INDEX, MITRE_ID, {"version": version})
        except Exception as e:
            logger.error(f"Error updating MITRE version: {e}")
            return False

    @classmethod
    def reset_instance(cls) -> None:
        """
        Resets the singleton instance of the CoreDbClient.

        This method is useful for testing or reinitializing the client with new
        environment variables.
        """
        with cls._lock:
            if cls._client is not None:
                cls._client.__del__()
            cls._client = None
            cls._initialized = False

    def _add_retry_to_opensearch_calls(self, max_tries: int, start_wait: int) -> None:
        """Adds retry to all AsyncOpenSearchClient public methods"""
        opensearch_methods = {
            name: method
            for name, method in inspect.getmembers(
                AsyncOpenSearchClient, predicate=inspect.isfunction
            )
        }
        core_db_methods = {
            name: method
            for name, method in inspect.getmembers(
                self.__class__, predicate=inspect.isfunction
            )
        }

        for method_name, method in core_db_methods.items():
            # Ignore private/protected methods
            if method_name.startswith("_"):
                continue
            # Add retry if the method is in AsyncOpenSearchClient or overridden
            if method_name in opensearch_methods:
                setattr(
                    self,
                    method_name,
                    retry_backoff(max_tries, start_wait)(
                        method.__get__(self, self.__class__)
                    ),
                )

    async def __aenter__(self) -> CoreDbClient:
        return self
