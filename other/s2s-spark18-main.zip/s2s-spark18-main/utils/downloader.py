import os
from typing import cast

from aiohttp import ClientSession
from loguru import logger

MAX_REDIRECTS = 5
USER_AGENT = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, "
        "like Gecko) Chrome/127.0.0.0 Safari/537.36"
    )
}


async def download_github_asset(
    session: ClientSession, release_url: str, filename: str, output_dir: str
) -> bool:
    """
    Download an asset from a github release. The release url may be a redirect.

    Args:
    - session (ClientSession): aiohttp.ClientSession object
    - release_url (str): The release URL, which may be a redirect
    - filename (str): The name of the file to download
    - output_dir (str): Directory to save the downloaded file

    Returns:
    - bool: Whether the download succeeded or failed
    """
    logger.debug(f"Getting github asset {filename} from {release_url}")
    try:
        redirect_url = await get_final_redirect(session, release_url)

        file_url = redirect_url.replace("/tag/", "/download/").rstrip("/")
        file_url = f"{file_url}/{filename}"

        async with session.get(file_url, headers=USER_AGENT) as response:
            if response.status == 200:
                # Ensure the output directory exists
                os.makedirs(output_dir, exist_ok=True)
                file_path = os.path.join(output_dir, filename)

                # Write the file
                with open(file_path, "wb") as file:
                    while True:
                        chunk = await response.content.read(1024)
                        if not chunk:
                            break
                        file.write(chunk)
                return True
            else:
                logger.error(f"Failed to download {file_url} ({response.status})")
                return False
    except Exception as e:
        logger.error(f"Failed to download {filename} from {release_url}: {e}")
        return False


async def get_final_redirect(session: ClientSession, url: str) -> str:
    """
    Follows redirects up to `MAX_REDIRECTS` times and returns the final url.

    Args:
    - session (ClientSession): aiohttp.ClientSession object
    - url (str): The URL, which may be a redirect

    Returns:
    - str: The final redirect url
    """
    redirect_url = url
    redirect_count = 0
    visited_urls = set()
    while True:
        async with session.get(
            redirect_url, headers=USER_AGENT, allow_redirects=False
        ) as response:
            if response.status in (301, 302, 303, 307, 308):
                redirect_count += 1
                if redirect_count > MAX_REDIRECTS:
                    logger.error(f"Too many redirects ({redirect_count}), stopping")
                    break
                location = response.headers.get("Location")
                if not location:
                    logger.error("Redirect location header missing, stopping")
                    break
                if location in visited_urls:
                    logger.error("Redirect loop detected, stopping")
                    break
                visited_urls.add(location)
                redirect_url = location
            else:
                break
    return redirect_url


async def download_image(session: ClientSession, url: str) -> bytes | int:
    """
    Downloads the image from the specified url.

    Args:
    - session (ClientSession): aiohttp.ClientSession object
    - url (str): The image URL

    Returns:
    - bytes | int: The downloaded image in bytes, or the error status code
    """
    logger.debug(f"Downloading image: {url}")
    async with session.get(url) as response:
        if response.status != 200:
            logger.error(f"Error downloading image {url}: {response.status}")
            return cast(int, response.status)
        img_bytes = await response.read()
        logger.debug(f"Finished downloading image: {url}")
        return cast(bytes, img_bytes)
