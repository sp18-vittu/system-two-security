export interface SlackOAuthResponse {
  ok: boolean;
  app_id: string;
  authed_user: {
    id: string;
    scope: string;
    access_token: string;
    token_type: string;
    refresh_token: string;
    expires_in: number;
  };
  scope: string;
  token_type: string;
  access_token: string;
  bot_user_id: string;
  refresh_token: string;
  expires_in: number;
  team: { id: string; name: string };
  enterprise: null;
  is_enterprise_install: boolean;
  incoming_webhook: {
    channel: string;
    channel_id: string;
    configuration_url: string;
    url: string;
  };
}

export enum GrantType {
  Code,
  RefreshToken,
}