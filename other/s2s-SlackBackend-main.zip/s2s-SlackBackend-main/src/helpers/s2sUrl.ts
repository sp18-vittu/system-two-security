import { Url as UrlI, ReportStatus } from "@prisma/client";
import { ReportMessageView, SlackUser } from ".";
import { Url } from "../models";
import { ReportEvent } from ".";

class S2SUrl {
  async create(event: ReportEvent): Promise<UrlI | null> {
    const slackUser = new SlackUser()
    const user = await slackUser.create(event.user, event.team)

    const oldUrl = await Url.findUnique({
      where: {
        userId_domain_url: {
          url: event.url,
          domain: user!.requestDomain!,
          userId: user!.id
        }
      }
    })

    let url = await Url.upsert({
      where: {
        userId_domain_url: {
          url: event.url,
          domain: user!.requestDomain!,
          userId: user!.id
        }
      },
      update: { reportStatus: ReportStatus.Started },
      create: {
        url: event.url,
        title: event.urlTitle,
        domain: user!.requestDomain!,
        userId: user!.id,
      }
    })

    const reportMessage = new ReportMessageView()
    await reportMessage.send(url, oldUrl, user!, event.team)

    return url;
  }
}

export default S2SUrl;