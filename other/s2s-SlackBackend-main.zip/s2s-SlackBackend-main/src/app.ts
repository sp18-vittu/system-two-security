import cors from "cors";
import morgan from "morgan";
import helmet from "helmet";
import express from "express";
import cron from "node-cron";
import router from "./routes";
import './models'
import s2sCategory from "./helpers/s2sChat/s2sCategory";
import { S2SChat } from "./helpers";
const app = express();

app.use(express.text())
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan("dev", {
  skip(req) {
    return req.baseUrl.includes('health-check') || req.baseUrl === '/'
  },
}));
app.use(helmet());
app.use(cors());

s2sCategory.getCategories(true)
cron.schedule('0 0 6 * * *', () => s2sCategory.getCategories(true))
cron.schedule('0 0 0 * * *', () => S2SChat.archiveExpiredChat())

router(app);

export default app;