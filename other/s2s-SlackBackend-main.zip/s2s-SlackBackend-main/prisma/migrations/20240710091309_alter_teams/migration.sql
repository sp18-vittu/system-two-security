/*
  Warnings:

  - You are about to drop the column `bot_user_id` on the `Team` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Team" DROP COLUMN "bot_user_id",
ADD COLUMN     "botId" TEXT;
