import { User } from "../../../models";
import { SlackEventType } from "../../../interfaces";
import HomeView from "../../homeView";
import SlackEvent from "../../../abstracts/slackEvent";
import AppActionHandler from "./appActionHandler";

class AppEvent extends SlackEvent {
  constructor(event: any) {
    super(event);
    this.type = this.determineEventType();
  }

  determineEventType(): SlackEventType {
    switch (this._event.type) {
      case 'block_actions':
        return new AppActionHandler(this._event).handle();
      default:
        return SlackEventType.Other;
    }
  }

  async handle(): Promise<boolean> {
    try {
      const user = await User.update({
        where: { slackId: this.user },
        data: {
          email: null,
          requestDomain: null,
          s2sToken: null,
          s2sTokenExp: null
        }
      })

      const homeView = new HomeView()
      await homeView.publish(user.slackId)

      return true
    } catch (err: any) {
      console.log(err.stack)
      return false
    }
  }
}

export default AppEvent;
