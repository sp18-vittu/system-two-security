enum QuestionType {
  CustomQuestion,
  CategoryQuestion
}

export default QuestionType;