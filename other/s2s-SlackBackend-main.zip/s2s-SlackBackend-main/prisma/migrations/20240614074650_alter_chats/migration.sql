/*
  Warnings:

  - Added the required column `url` to the `Chat` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "url" TEXT NOT NULL;
