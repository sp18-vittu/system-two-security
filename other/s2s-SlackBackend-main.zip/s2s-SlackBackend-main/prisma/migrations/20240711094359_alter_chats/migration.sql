-- AlterEnum
ALTER TYPE "ChatStatus" ADD VALUE 'PENDING';
