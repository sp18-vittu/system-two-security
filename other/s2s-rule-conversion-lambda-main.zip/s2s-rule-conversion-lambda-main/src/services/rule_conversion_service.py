import logging
import requests

from loguru import logger


class RuleConversionService:
    def __init__(self, config):
        self.rule_conversion_endpoint = config.rule_conversion_endpoint

    def convert_rule(self, temp_file_path):
        with open(temp_file_path, 'rb') as file_stream:
            files = {'file': file_stream}
            url = (f"{self.rule_conversion_endpoint}/api/v1/sigma?target=splunk&pipeline=sysmon&tenant_id=tenant-123")
            headers = {'accept': 'application/json'}

            logger.info(f"Making HTTP POST request to {url} with headers {headers}")
            response = requests.post(url, headers=headers, files=files)
            response.raise_for_status()
            conversion_result = response.json()
            logger.info(f"Converted rule: {conversion_result}")

            # Check if the status is "error" and raise an exception if it is
            if conversion_result["result"][0]["status"] == "error":
                error_message = conversion_result["result"][0]["result"]
                raise Exception(f"Error converting rule: {error_message}")

            # Extract the query from the conversion result
            query = conversion_result["result"][0]["result"]
            return query
