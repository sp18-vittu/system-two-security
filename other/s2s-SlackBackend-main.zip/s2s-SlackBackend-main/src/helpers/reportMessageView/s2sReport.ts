import { S2sInsites } from "../../interfaces";

class S2SReport {

  static reportSummary(insites: S2sInsites): string {
    let text = 'Summary: '
    text += `The report includes `
    if (insites.TTPs)
      text += `${insites.TTPs} TTP, `
    if (insites.CVEs)
      text += `${insites.CVEs} CVE, `
    if (insites.IOC)
      text += `${insites.IOC} IOC, `
    if ((insites.TTPs || insites.CVEs || insites.IOC) && insites.SIGMA) {
      text += `and we've generated ${insites.SIGMA} Sigma rules based on this report.`
    }
    else if ((insites.TTPs || insites.CVEs || insites.IOC) && !insites.SIGMA) {
      text = text.slice(0, -2) + '.'
    }
    else if (!(insites.TTPs || insites.CVEs || insites.IOC) && insites.SIGMA) {
      text = `Summary: We've generated ${insites.SIGMA} Sigma rules based on this report.`
    }
    else {
      text = "Summary: No suitable sigma rules could be generated from this report."
    }
    return text;
  }
}

export default S2SReport;