enum SlackEventType {
  ReportCommand,
  WorkbenchCommand,
  MenuAction,
  Disconnect,
  CategorySelect,
  QuestionSelect,
  QuestionSubmission,
  OpenFocus,
  FocusSelect,
  ChangeFocus,
  ChangeReport,
  SettingsCommand,
  SettingsSubmit,
  Other
}

export default SlackEventType;