import axios from "axios";

class UrlTitle {
  constructor(private url: string) { }

  private formatTitle(): string {
    try {
      const { pathname, hostname } = new URL(this.url);
      const path = pathname !== '/' ? pathname : hostname;
      const title = path.split('/').pop()?.split('.').slice(-2, -1)[0] ?? '';
      return title.replace(/-/g, ' ').replace(/\b\w/g, char => char.toUpperCase());
    } catch {
      return this.url;
    }
  }

  async fetch(): Promise<string> {
    try {
      const { data } = await axios.get(this.url);
      const match = data.match(/<title[^>]*>([^<]+)<\/title>/i);
      return match ? match[1] : this.formatTitle();
    } catch {
      return this.formatTitle();
    }
  }
}

export default UrlTitle;
