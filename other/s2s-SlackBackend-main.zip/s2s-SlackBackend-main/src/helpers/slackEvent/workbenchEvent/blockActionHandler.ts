import { SlackEventType } from "../../../interfaces";
import WorkbenchEvent from ".";

class BlockActionHandler {
  private _event: any;

  constructor(event: any) {
    this._event = event;
  }

  handle(event: WorkbenchEvent): SlackEventType {
    const action = this._event.actions[0];
    switch (action.action_id) {
      case 'category_select':
        event.category = action.selected_option.value;
        event.question = this._event.view.state?.values?.questions?.question_select?.selected_option?.value;
        return SlackEventType.CategorySelect;
      case 'question_select':
        event.category = this._event.view.state.values.category.category_select.selected_option.value;
        event.question = action.selected_option.value;
        return SlackEventType.QuestionSelect;
      case 'focus_select':
        event.focus = action.selected_option.value;
        return SlackEventType.FocusSelect;
      default:
        return SlackEventType.Other;
    }
  }
}

export default BlockActionHandler;
