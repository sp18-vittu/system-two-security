import { Request, Response, Router } from "express";
import { WorkbenchEvent } from "../../helpers";
import CatchError from "../../errors/catchError";

const router = Router();

router.post('/report', async (req: Request, res: Response) => {
  const event = new WorkbenchEvent(req.body);

  try {
    event.handle()
    res.send()
  } catch (err: any) {
    console.log(err.stack);
    const catchErr = new CatchError(event.team, event.user)
    const error = await catchErr.handle()
    res.status(error.statusCode).send(error.toJson());

  }
})

export default router