import { Response, Application } from "express";
import apiRoutes from "./api.routes";
import ApiRouteNotFoundError from "../errors/apiNotFoundError";

const router = function (app: Application) {
  app.use("/slack", apiRoutes);

  //health-checkup
  app.get("/health-check", (_, res: Response) => {
    res.status(200).send({ message: "APIs are working fine" });
  });

  //API Error Routes
  app.use((_, res: Response) => {
    const error = new ApiRouteNotFoundError()
    res.status(error.statusCode).send(error.toJson());
  });
}

export default router;