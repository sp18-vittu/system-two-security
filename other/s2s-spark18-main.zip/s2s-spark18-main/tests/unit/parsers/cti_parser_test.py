import pytest
from pytest_mock import MockerFixture

from parsers import CtiParser
from processing.html import HtmlParser
from services import CoreDbClient


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "url, base_url",
    [
        (None, "https://www.google.com"),
        ("https://www.google.com", None),
    ],
)
async def test_ctiparser_parse_missing_url(
    mocker: MockerFixture,
    url: str,
    base_url: str,
) -> None:
    """Tests `CtiParser` returns None when URL is missing"""
    mocker.patch.object(HtmlParser, "fetch_html_content")
    mocker.patch.object(HtmlParser, "parse")
    mocker.patch.object(HtmlParser, "get_url", return_value=url)
    mocker.patch.object(HtmlParser, "get_base_url", return_value=base_url)
    mocker.patch.object(CoreDbClient, "get_document", return_value={})
    mocker.patch.object(CoreDbClient, "upsert", return_value=True)

    parser = CtiParser("")
    cti_doc = await parser.parse()

    assert cti_doc.error is not None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "use_db",
    [True, False],
)
async def test_ctiparser_parse_database(
    mocker: MockerFixture,
    use_db: bool,
) -> None:
    """
    Tests `CtiParser` calls `CoreDbClient.get_document` and `CoreDbClient.upsert` when
    `use_db` is True
    """
    mocker.patch.object(HtmlParser, "fetch_html_content")
    mocker.patch.object(HtmlParser, "parse")
    mocker.patch.object(HtmlParser, "get_url", return_value="")
    mocker.patch.object(HtmlParser, "get_base_url", return_value="")
    mocker.patch.object(HtmlParser, "get_content", return_value="test")
    mock_get_document = mocker.patch.object(
        CoreDbClient, "get_document", return_value={}
    )
    mock_upsert = mocker.patch.object(CoreDbClient, "upsert", return_value=True)

    parser = CtiParser("")
    await parser.parse(use_db=use_db)

    if use_db:
        mock_get_document.assert_called_once()
        mock_upsert.assert_called_once()
    else:
        assert mock_get_document.called is False


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "force",
    [True, False],
)
async def test_ctiparser_parse_force(
    mocker: MockerFixture,
    force: bool,
) -> None:
    """
    Tests `CtiParser` does NOT call `CoreDbClient.get_document` when `force` is True
    """
    mocker.patch.object(HtmlParser, "fetch_html_content")
    mocker.patch.object(HtmlParser, "parse")
    mocker.patch.object(HtmlParser, "get_url", return_value="")
    mocker.patch.object(HtmlParser, "get_base_url", return_value="")
    mock_get_document = mocker.patch.object(
        CoreDbClient, "get_document", return_value={}
    )
    mocker.patch.object(CoreDbClient, "upsert", return_value=True)

    parser = CtiParser("")
    await parser.parse(force=force)

    if force:
        assert mock_get_document.called is False
    else:
        mock_get_document.assert_called_once()
