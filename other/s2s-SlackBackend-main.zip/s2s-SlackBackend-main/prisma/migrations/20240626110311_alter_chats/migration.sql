/*
  Warnings:

  - You are about to drop the column `sessionName` on the `Chat` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Chat" DROP COLUMN "sessionName";
