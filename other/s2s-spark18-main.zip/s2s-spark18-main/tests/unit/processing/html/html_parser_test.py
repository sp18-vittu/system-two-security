from typing import Awaitable, List, Optional

import pytest
from pytest_mock import MockerFixture

from entities import Image
from processing.html import HtmlParser

TEST_HTML = """
<HTML>

<HEAD>
    <TITLE>Your Title Here</TITLE>
</HEAD>

<BODY BGCOLOR="FFFFFF">
    <header>Test header tag</header>
    <CENTER><IMG SRC="clouds.jpg" ALIGN="BOTTOM" alt="Clouds"></CENTER>
    <HR>
    <a href="http://somegreatsite.com">This</a> is a link to another nifty site
    <H1>This is a Header</H1>
    <H2>This is a Medium Header</H2>
    Email me at <a href="mailto:support@yourcompany.com">support@yourcompany.com</a>.
    <P>This is a new paragraph!</P>
    <P>This is another new paragraph with some <code>inline code</code></P>
    <pre class="wp-block-preformatted">from python import code</pre>
    <li>First list item</li>
    <li>Second list item
    <li>First nested list item</li>
    <li>Second nested list item</li>
    </li>
    <p class="test">Test ignore class</p>
    <img src="data:image/svg+xml;base64,abc123" alt="image with embedded data">
    <HR>
    <footer>
        <div>
            <form>
                <input type="hidden" name="a" value="1" hidden>
                <input type="hidden" name="b" value="2" hidden>
                <input type="hidden" name="c" value="3" hidden>
                <input type="hidden" name="d" value="4" hidden>
            </form>
            <area><area><base><base><br><br><col><col><embed><embed><hr><hr><img><img>
            <link><link><meta><meta><source><source><track><track><wbr><wbr>
            <p>Footer paragraph after void elements</p>
        </div>
    </footer>
    <p>Paragraph after footer</p>
</BODY>

</HTML>
"""


@pytest.fixture()
async def parsed_html_path() -> str:
    html_parser = HtmlParser()
    await html_parser.parse(TEST_HTML, use_db=False)
    return html_parser.get_parsed_content()


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    ["Your Title Here\n"],
)
async def test_htmlparser_title(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """Tests that HtmlParser().get_parsed_content() returns the correct title format"""
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        "[This](http://somegreatsite.com)",
        "[support@yourcompany.com](mailto:support@yourcompany.com)",
    ],
)
async def test_htmlparser_link(expected_content: str) -> None:
    """Tests that HtmlParser().get_parsed_content() returns the correct link format"""
    html_parser = HtmlParser(include_links=True)
    await html_parser.parse(TEST_HTML)
    plaintext = html_parser.get_parsed_content()
    assert expected_content in plaintext


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        "This is a Header\nThis is a Medium Header\n",
    ],
)
async def test_htmlparser_header(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """Tests that HtmlParser().get_parsed_content() returns the correct header format"""
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        "(Image: Clouds)",
    ],
)
async def test_htmlparser_img_alt_text(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """
    Tests that HtmlParser().get_parsed_content() returns the correct img alt text format
    """
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
async def test_htmlparser_img_ocr_ignores_data(mocker: MockerFixture) -> None:
    """Tests that HtmlParser.parse skips OCR for embedded image data"""
    html_parser = HtmlParser(ocr=True)
    html_parser.base_url = "baseurl"
    mock_download = mocker.patch(
        "processing.html.html_parser.utils.download_image", return_value=b"test"
    )
    mock_img_props = mocker.patch(
        "processing.image.get_image_properties", return_value=Image("jpg", 0, 0, 0)
    )
    mock_ocr = mocker.patch("processing.image.img_to_text", return_value="")
    await html_parser.parse(TEST_HTML, use_db=False)

    assert mock_download.call_count == 1
    assert mock_img_props.call_count == 1
    assert mock_ocr.call_count == 1

    parsed_content = html_parser.get_parsed_content()

    assert "image with embedded data" in parsed_content


@pytest.mark.asyncio
async def test_htmlparser_img_ocr_adds_start_end_labels(mocker: MockerFixture) -> None:
    """
    Tests that HtmlParser.parse adds start and end labels around extracted image text
    """
    html_parser = HtmlParser(ocr=True)
    html_parser.base_url = "baseurl"
    mock_download = mocker.patch(
        "processing.html.html_parser.utils.download_image", return_value=b"test"
    )
    mock_img_props = mocker.patch(
        "processing.image.get_image_properties", return_value=Image("jpg", 0, 0, 0)
    )
    img_text = "test text"
    mock_ocr = mocker.patch("processing.image.img_to_text", return_value=img_text)
    await html_parser.parse(TEST_HTML, use_db=False)

    assert mock_download.call_count == 1
    assert mock_img_props.call_count == 1
    assert mock_ocr.call_count == 1

    parsed_content = html_parser.get_parsed_content()

    assert f"[Image Transcript]\n{img_text}\n[/Image Transcript]" in parsed_content


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        " `inline code`\n",
    ],
)
async def test_htmlparser_code_inline(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """
    Tests that HtmlParser().get_parsed_content() returns the correct inline code format
    """
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        "```\nfrom python import code\n```\n",
    ],
)
async def test_htmlparser_code_block(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """
    Tests that HtmlParser().get_parsed_content() returns the correct code block format
    """
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "expected_content",
    [
        "\n- First list item\n",
        "\n- Second list item\n",
        "\n-- First nested list item\n",
        "\n-- Second nested list item",
    ],
)
async def test_htmlparser_list(
    parsed_html_path: Awaitable[str], expected_content: str
) -> None:
    """Tests that HtmlParser().get_parsed_content() returns the correct list format"""
    assert expected_content in await parsed_html_path


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "ignore_tags, content, expect_exist",
    [
        (["header"], "Test header tag", False),
        (None, "Test header tag", True),
    ],
)
async def test_htmlparser_ignore_tags(
    ignore_tags: Optional[List[str]], content: str, expect_exist: bool
) -> None:
    """Tests that HtmlParser() ignores tags if specified"""
    parser = HtmlParser(TEST_HTML, ignore_tags=ignore_tags)
    await parser.parse()
    parsed_content = parser.get_parsed_content()
    if expect_exist:
        assert content in parsed_content
    else:
        assert content not in parsed_content


@pytest.mark.asyncio
async def test_htmlparser_ignores_nested_tags_with_void() -> None:
    """Tests that HtmlParser() ignores nested void tags if specified"""
    parser = HtmlParser(TEST_HTML, ignore_tags=["footer"])
    await parser.parse()
    parsed_content = parser.get_parsed_content()
    assert "Footer paragraph after void elements" not in parsed_content
    assert "Paragraph after footer" in parsed_content


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "ignore_classes, content, expect_exist",
    [
        (["test"], "Test ignore class", False),
        (None, "Test ignore class", True),
    ],
)
async def test_htmlparser_ignore_classes(
    ignore_classes: Optional[List[str]], content: str, expect_exist: bool
) -> None:
    """Tests that HtmlParser() ignores classes if specified"""
    parser = HtmlParser(TEST_HTML, ignore_classes=ignore_classes)
    await parser.parse()
    parsed_content = parser.get_parsed_content()
    if expect_exist:
        assert content in parsed_content
    else:
        assert content not in parsed_content


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "delimiter, expect_count",
    [("<-|->", 2), ("###", 2), (None, 0), ("", 0)],
)
async def test_htmlparser_header_delimiter(
    delimiter: Optional[str], expect_count: int
) -> None:
    """Tests that HtmlParser() adds delimiters at each header if specified"""
    parser = HtmlParser(TEST_HTML, header_delimiter=delimiter)
    await parser.parse()
    parsed_content = parser.get_parsed_content()
    if delimiter:
        assert parsed_content.count(delimiter) == expect_count


@pytest.mark.parametrize(
    "content, expect",
    [("https://www.google.com", True), ("This is not a URL", False)],
)
def test_htmlparser_not_fetches_url_content(
    mocker: MockerFixture, content: str, expect: bool
) -> None:
    """
    Tests HtmlParser(url) does not fetch html content from URL during initialization
    """
    mock_fetch_html_content = mocker.patch.object(
        HtmlParser, "fetch_html_content", return_value=""
    )

    parser = HtmlParser(content)

    if expect:
        mock_fetch_html_content.assert_not_called()
        assert parser.url == content
        assert parser.base_url != ""
        assert parser.content is None
    else:
        mock_fetch_html_content.assert_not_called()
        assert hasattr(parser, "url") is False
        assert hasattr(parser, "base_url") is False
        assert parser.content is not None


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "content, data, expect",
    [
        (None, "https://www.google.com", True),
        (None, "asdf", False),
        ("https://www.google.com", None, True),
        ("asdf", None, False),
        ("https://www.google.com", "https://www.google.com", True),
        ("https://www.google.com", "asdf", False),
        ("asdf", "https://www.google.com", True),
        ("asdf", "asdf", False),
    ],
)
async def test_htmlparser_parse_calls_fetch_html_content(
    content: str | None, data: str | None, expect: bool, mocker: MockerFixture
) -> None:
    mocker.patch.object(HtmlParser, "feed")
    mocker.patch.object(HtmlParser, "execute_image_text_extraction")
    mock_fetch_html_content = mocker.patch.object(HtmlParser, "fetch_html_content")

    parser = HtmlParser(content)
    await parser.parse(data)

    if expect:
        mock_fetch_html_content.assert_called_once()
    else:
        mock_fetch_html_content.assert_not_called()
