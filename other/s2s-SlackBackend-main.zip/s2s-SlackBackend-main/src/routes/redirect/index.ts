import slackOauth from "./slackOauth";

export default [
  slackOauth
];