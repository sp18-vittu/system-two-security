import { AxiosInstance, AxiosResponse } from 'axios';
import { S2SLoginResponse } from '../../interfaces';
import AxiosConnection from '../connection';

class S2SLogin {
  private readonly email: string;
  private readonly password: string;
  private readonly domain: string;
  private readonly connection: AxiosInstance;

  constructor(email: string, password: string, domain: string) {
    this.email = email;
    this.password = password;
    this.domain = domain;
    const axiosConnection = new AxiosConnection(process.env.S2S_URL!);
    this.connection = axiosConnection.connection();
  }

  async login(): Promise<S2SLoginResponse> {
    const payload = {
      email: this.email,
      password: this.password,
      requestDomain: `${this.domain}.systemtwosecurity.com`
    }

    try {
      const response: AxiosResponse = await this.connection.post('auth/secure-login', payload);
      return response.data;
    } catch (error: any) {
      console.error('Error:', error.response ? error.response.data : error.message);
      return error.response ? error.response.data : error.message;
    }
  }
}

export default S2SLogin;
