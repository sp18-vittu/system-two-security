/*
  Warnings:

  - You are about to drop the column `email` on the `Team` table. All the data in the column will be lost.
  - You are about to drop the column `s2sToken` on the `Team` table. All the data in the column will be lost.
  - You are about to drop the column `s2sTokenExp` on the `Team` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[email]` on the table `User` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "Team_email_key";

-- AlterTable
ALTER TABLE "Team" DROP COLUMN "email",
DROP COLUMN "s2sToken",
DROP COLUMN "s2sTokenExp";

-- AlterTable
ALTER TABLE "User" ADD COLUMN     "email" TEXT,
ADD COLUMN     "s2sToken" TEXT,
ADD COLUMN     "s2sTokenExp" TIMESTAMP(3);

-- CreateIndex
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");
