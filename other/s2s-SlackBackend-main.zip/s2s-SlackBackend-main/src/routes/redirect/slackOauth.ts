import { Request, Response, Router } from "express";
import SomethingWentWrongError from "../../errors/somethingWentWrongError";

const router = Router();

router.get('/slack-oauth', async (_req: Request, res: Response) => {
  try {
    res.redirect(process.env.SLACK_OAUTH_URL!)
  } catch (err: any) {
    console.log(err.stack);
    const error = new SomethingWentWrongError()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router