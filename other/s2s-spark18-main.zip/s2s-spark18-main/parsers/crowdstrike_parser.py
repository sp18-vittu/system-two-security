from typing import Any

from .cti_parser import CtiParser


class CrowdstrikeCtiParser(CtiParser):
    """
    A parser for Crowdstrike CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            ignore_tags=["footer"],
            ignore_classes=[
                "list-share-buttons",
                "recent_articles",
                "sidebar",
                "post_nav",
            ],
            ocr=True,
        )
