from typing import Any, cast

import pytest
from pytest_mock import MockerFixture

from parsers import (
    CisaCtiParser,
    CrowdstrikeCtiParser,
    CtiParserFactory,
    DefaultCtiParser,
    DfirCtiParser,
    InfobloxCtiParser,
    MandiantCtiParser,
    MicrosoftCtiParser,
    SecuronixCtiParser,
    SplunkCtiParser,
    Unit42CtiParser,
    WelivesecurityCtiParser,
)


@pytest.fixture
def mock_llm_client(mocker: MockerFixture) -> Any:
    return cast(Any, mocker.Mock(spec=Any))


def test_create_parser_microsoft(mock_llm_client: Any) -> None:
    url = "https://www.microsoft.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, MicrosoftCtiParser)


def test_create_parser_cisa(mock_llm_client: Any) -> None:
    url = "https://www.cisa.gov/another/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, CisaCtiParser)


def test_create_parser_securonix(mock_llm_client: Any) -> None:
    url = "https://www.securonix.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, SecuronixCtiParser)


def test_create_parser_dfir(mock_llm_client: Any) -> None:
    url = "https://thedfirreport.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, DfirCtiParser)


def test_create_parser_infoblox(mock_llm_client: Any) -> None:
    url = "https://blogs.infoblox.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, InfobloxCtiParser)


def test_create_parser_crowdstrike(mock_llm_client: Any) -> None:
    url = "https://www.crowdstrike.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, CrowdstrikeCtiParser)


def test_create_parser_mandiant(mock_llm_client: Any) -> None:
    url = "https://cloud.google.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, MandiantCtiParser)


def test_create_parser_welivesecurity(mock_llm_client: Any) -> None:
    url = "https://www.welivesecurity.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, WelivesecurityCtiParser)


def test_create_parser_unit42(mock_llm_client: Any) -> None:
    url = "https://unit42.paloaltonetworks.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, Unit42CtiParser)


def test_create_parser_splunk(mock_llm_client: Any) -> None:
    url = "https://www.splunk.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, SplunkCtiParser)


def test_create_parser_default(mock_llm_client: Any) -> None:
    url = "https://www.unknown.com/some/path"
    parser = CtiParserFactory.create_parser(url, mock_llm_client)
    assert isinstance(parser, DefaultCtiParser)
