from __future__ import annotations

from typing import Optional, cast


class ImageDocument:
    def __init__(
        self,
        id: str,
        url: str,
        base_url: str,
        type: str,
        alt: str,
        text: str = "",
        hash: str = "",
        created: Optional[str] = None,
        modified: Optional[str] = None,
        last_check: Optional[str] = None,
    ) -> None:
        self.id = id
        self.url = url
        self.base_url = base_url
        self.type = type
        self.alt = alt
        self.text = text
        self.hash = hash
        self.created = created
        self.modified = modified
        self.last_check = last_check

    @classmethod
    def from_dict(cls, data: dict) -> ImageDocument:
        id = cast(str, data.get("_id"))
        source = cast(dict, data.get("_source"))
        return cls(
            id=id,
            url=cast(str, source.get("url")),
            base_url=cast(str, source.get("base_url")),
            type=cast(str, source.get("type")),
            alt=cast(str, source.get("alt")),
            text=source.get("text", ""),
            hash=source.get("hash", ""),
            created=source.get("created", None),
            modified=source.get("modified", None),
            last_check=source.get("last_check", None),
        )

    def to_dict(self) -> dict:
        source = {key: value for key, value in vars(self).items() if value is not None}
        del source["id"]
        return source
