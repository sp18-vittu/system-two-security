from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Tuple, Union, cast

from loguru import logger
from opensearchpy import AsyncOpenSearch, NotFoundError, RequestError
from opensearchpy.helpers import async_bulk

from constants import DB_SEARCH_SIZE, EMBEDDING_MODEL, KNN_K


class AsyncOpenSearchClient:
    """A client for interacting with an OpenSearch/ElasticSearch instance"""

    def __init__(
        self, host: str, port: str, use_ssl: bool, username: str, password: str
    ) -> None:
        self.client = AsyncOpenSearch(
            hosts=[{"host": host, "port": int(port)}],
            http_compress=True,
            http_auth=(username, password),
            use_ssl=use_ssl,
            verify_certs=False,
            ssl_show_warn=False,
        )

    async def info(self) -> Any:
        """Retrieves basic information about the OpenSearch cluster"""
        return await self.client.info()

    async def index_exists(self, index: str) -> bool:
        """
        Returns information about whether a particular index exists.

        Args:
        - index (str): Name of index.

        Returns:
        - bool: Whether index exists.
        """
        return cast(bool, await self.client.indices.exists(index=index))

    async def create_index(self, index: str, schema: dict | None = None) -> bool:
        """
        Creates an index with optional schema (`settings` and `mappings`).

        Args:
        - index (str): Name of index.
        - schema (dict): The configuration for the index (`settings` and `mappings`)

        Returns:
        - bool: Whether index was successfully created.
        """
        logger.debug(f"Creating index: {index}")
        try:
            response = await self.client.indices.create(index=index, body=schema)
            if "error" in response:
                if response["error"]["type"] == "resource_already_exists_exception":
                    logger.info(f"Index {index} already exists")
                else:
                    msg = (
                        f"Failed to create index {index}: {response['error']['type']}: "
                        f"{response['error']['reason']}"
                    )
                    logger.error(msg)
                    raise Exception(msg)
            else:
                logger.info(f"Successfully created index {index}")
        except RequestError as e:
            if e.error == "resource_already_exists_exception":
                logger.info(f"Index {index} already exists")
            else:
                raise
        return True

    async def delete_index(self, index: str) -> bool:
        """
        Deletes an index.

        Args:
        - index (str): Name of index.

        Returns:
        - bool: Whether index was successfully deleted.
        """
        logger.debug(f"Deleting index {index}")
        response = await self.client.indices.delete(index=index)
        if "error" in response:
            msg = (
                f"Failed to delete index {index}: {response['error']['type']}: "
                f"{response['error']['reason']}"
            )
            logger.error(msg)
            raise Exception(msg)

        logger.info(f"Successfully deleted index {index}")
        return True

    async def get_index_settings(self, index: str) -> dict:
        """
        Returns the settings of a specified index.

        Args:
        - index (str): The name of the index.

        Returns:
        - dict: The index settings
        """
        response = await self.client.indices.get_settings(index=index)
        response_index = cast(dict, response).get(index)
        settings = cast(dict, response_index).get("settings")
        index_settings = cast(dict, settings).get("index")
        return cast(dict, index_settings)

    async def document_exists(self, index: str, doc_id: str) -> bool:
        """
        Returns information about whether a document exists in an index.

        Args:
        - index (str): The name of the index to search.
        - doc_id (str): The document id.

        Returns:
        - bool: Whether the document exists in the specified index.
        """
        return cast(bool, await self.client.exists(index=index, id=doc_id))

    async def index(self, index: str, doc_id: str, document: dict) -> bool:
        """
        Creates or replaces a document in an index.

        Args:
        - index (str): The name of the index where the document will be indexed.
        - doc_id (str): The unique identifier for the document.
        - document (dict): The document data to be indexed as a dictionary.

        Returns:
        - bool: True if the indexing operation was successful, False otherwise.
        """
        await self.client.index(index=index, id=doc_id, body=document)
        logger.debug(f"Successfully indexed document with ID {doc_id} to index {index}")
        return True

    async def upsert(self, index: str, doc_id: str, document: dict) -> None:
        """
        Upserts a document in the specified index.

        This method updates an existing document with the given ID if it exists,
        or inserts a new document if the ID does not exist in the index.

        Args:
        - index (str): The name of the index where the document will be upserted.
        - doc_id (str): The unique identifier for the document.
        - document (dict): The document data to be upserted as a dictionary.
        """
        await self.client.update(
            index=index, id=doc_id, body={"doc": document, "doc_as_upsert": True}
        )
        logger.debug(
            f"Successfully upserted document with ID {doc_id} to index {index}"
        )

    async def update_by_query_script(
        self, index: str, query: dict, script: dict
    ) -> None:
        """
        Upserts all documents matching the condition given in the query.
        """
        body = {"script": script, "query": query}

        res = await self.client.update_by_query(index, body=body)
        logger.debug(
            f"Successfully updated documents for given query, total: {res['total']},"
            f" updated: {res['updated']}"
        )

    async def bulk_upsert(
        self, index: str, documents: List[Tuple[str, dict]]
    ) -> Tuple[int, int]:
        """
        Bulk upserts a batch of documents into an OpenSearch index.

        Args:
        - index (str): The name of the index where the documents will be upserted.
        - documents (List[Tuple[str, dict]]): A list of tuples, where each tuple
            contains a document ID and the document data as a dictionary.

        Returns:
        - Tuple[int, int]: A tuple containing the number of successful operations
            and the number of failed operations.
        """
        actions = []
        for doc_id, document in documents:
            action = {
                "_op_type": "update",
                "_index": index,
                "_id": doc_id,
                "doc": document,
                "doc_as_upsert": True,
            }
            actions.append(action)

        # Perform the bulk upsert operation
        logger.debug(f"Upserting {len(documents)} documents to index {index}")
        success, errors = await async_bulk(self.client, actions)
        errors = cast(list, errors)

        if errors:
            logger.error(f"Encountered {len(errors)} errors: {errors}")

        logger.debug(f"Successful upserted {success} documents to index {index}")
        return success, len(errors)

    async def bulk_delete(self, index: str, document_ids: List[str]) -> Tuple[int, int]:
        """
        Bulk delete a batch of document ids from an OpenSearch index.

        Args:
        - index (str): The name of the index to delete the documents
        - document_ids (List[str]): A list of document ids to delete

        Returns:
        - Tuple[int, int]: A tuple containing the number of successful operations
            and the number of failed operations.
        """
        actions = []
        for doc_id in document_ids:
            action = {
                "_op_type": "delete",
                "_index": index,
                "_id": doc_id,
            }
            actions.append(action)

        # Perform the bulk delete operation
        logger.debug(f"Deleting {len(document_ids)} documents from index {index}")
        success, errors = await async_bulk(self.client, actions)
        errors = cast(list, errors)

        if errors:
            logger.error(f"Encountered {len(errors)}: {errors}")

        logger.debug(f"Successful deleted {success} documents from index {index}")
        return success, len(errors)

    async def get_document(self, index: str, doc_id: str) -> dict | None:
        """
        Returns a document.

        Args:
        - index (str): The name of the index to search.
        - doc_id (str): The unique identifier for the document.

        Returns:
        - dict | None: The document as returned by the OpenSearch cluster, or None
        """
        try:
            response = cast(dict, await self.client.get(index=index, id=doc_id))
            if response.get("found") is True:
                return response
        except NotFoundError as e:
            if e.status_code != 404:
                raise
        logger.debug(f"Document {doc_id} was not found in index {index}")
        return None

    async def get_documents(self, index: str, doc_ids: List[str]) -> Any:
        """
        Returns a list of documents.

        Args:
        - index (str): The name of the index to search.
        - doc_ids (List[str]): The list of unique identifiers for each document.

        Returns:
        - Any: The list of documents as returned by the OpenSearch cluster, or None
        """
        try:
            if not doc_ids:
                logger.info("Nothing to get")
                return None
            body = {"ids": doc_ids}
            response = cast(dict, await self.client.mget(body=body, index=index))
            return response.get("docs")
        except NotFoundError as e:
            if e.status_code != 404:
                raise
            return None

    async def count(self, index: str, body: Any) -> int:
        """
        Counts the number of documents that match the query.

        Args:
        - index (str): The name of the index to search.
        - body: The search query body.

        Returns:
        - int: The count of documents that match the query
        """
        response = await self.client.count(index=index, body=body)
        response = cast(dict, response)
        return cast(int, response.get("count", 0))

    async def search(self, index: str, body: Any, size: int = DB_SEARCH_SIZE) -> Any:
        """
        Executes a search query against the specified index in the OpenSearch cluster.

        Args:
        - index (str): The name of the index to search.
        - body: The search query body.
        - size (int): The number of results to return (defaults to 10)

        Returns:
        - The search results as returned by the OpenSearch cluster.
        """
        return await self.client.search(index=index, body=body, size=size)

    async def knn_search(
        self,
        index: str,
        filter: List[Dict[str, Any]],
        embedding: List[float],
        model: str = EMBEDDING_MODEL,
        k: int = KNN_K,
        size: int = DB_SEARCH_SIZE,
    ) -> Any:
        """
        Executes a k-NN search against the specified index in the OpenSearch cluster.

        Args:
        - index (str): The name of the index to search.
        - filter (List[Dict[str, Any]]): Any filters to apply (ran separately then
            combined)
        - embedding (List[float]): The embedding to search with
        - model (str): The name of the vector to search (defaults to `EMBEDDING_MODEL`)
        - k (int): Number of nearest neighbors to retrieve (defaults to `KNN_K`)
        - size (int): The number of results to return (defaults to `DB_SEARCH_SIZE`)

        Returns:
        - The search results as returned by the OpenSearch cluster.
        """
        logger.debug(
            f"Searching index {index} vector {model} for {k} nearest neighbors"
        )
        body = {
            "query": {
                "bool": {
                    "filter": filter,
                    "must": [{"knn": {model: {"vector": embedding, "k": k}}}],
                }
            }
        }
        logger.trace(body)
        return await self.client.search(index=index, body=body, size=size)

    async def msearch(self, indices: Union[str, List[str]], bodies: List[Any]) -> Any:
        """
        Executes a multi-search query across one or more indices.

        Args:
        - indices (Union[str, List[str]]): A single index or a list of indices to search
        - bodies (List[Any]): The search query bodies

        Returns:
        - The search results as returned by the OpenSearch cluster.
        """
        if isinstance(indices, list) and len(indices) != len(bodies):
            logger.error(
                "Number of indices does not match number of queries "
                f"({len(indices)} != {len(bodies)})"
            )
            return None
        elif isinstance(indices, str):
            indices = [indices] * len(bodies)

        requests = []
        for i in range(len(bodies)):
            requests.append({"index": indices[i]})
            requests.append(bodies[i])

        return await self.client.msearch(body=requests)

    async def close(self) -> None:
        if hasattr(self, "client") and self.client is not None:
            await self.client.close()
            self.client = None

    async def __aenter__(self) -> AsyncOpenSearchClient:
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    def __del__(self) -> None:
        if not hasattr(self, "client") or self.client is None:
            return
        loop: asyncio.AbstractEventLoop | None = None
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        if loop and loop.is_running():
            task = loop.create_task(self.close())
            task.add_done_callback(
                lambda future: logger.debug(
                    "Completed AsyncOpenSearchClient close (running loop)"
                )
            )
        else:
            asyncio.run(self.close())
            logger.debug("Completed AsyncOpenSearchClient close")
