import asyncio
import os
import sys
from typing import List

parent_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.append(parent_dir)

from processing.html import HtmlParser  # noqa: E402


async def main(
    url: str,
    txt_path: str,
    links: bool,
    template: str,
    tags: List[str] | None,
    classes: List[str] | None,
    ocr: bool,
) -> None:
    parser = HtmlParser(
        content=url,
        include_links=links,
        header_delimiter=template,
        ignore_tags=tags,
        ignore_classes=classes,
        ocr=ocr,
    )
    await parser.parse(use_db=False, force=False)
    plaintext = parser.get_parsed_content()

    with open(txt_path, "w", encoding="utf-8") as file:
        file.write(plaintext)


if __name__ == "__main__":
    os.makedirs("output", exist_ok=True)
    url = input("Enter the url: ")
    filename = input("Enter the output filename: ")
    links = input("Include links? (y/n): ")
    use_links = links.lower() == "y"
    template = input("Enter pattern for header dividers (eg. <-|->): ")
    # header,footer
    tags = input("Enter comma-separated tags to ignore: ")
    tags_list: List[str] | None = None
    if tags:
        tags_list = [x.strip() for x in tags.split(",")]
    # header,footer,menu,related
    classes = input("Enter comma-separated classes to ignore: ")
    classes_list: List[str] | None = None
    if classes:
        classes_list = [x.strip() for x in classes.split(",")]
    ocr = input("Perform OCR on images? (y/n): ")
    use_ocr = ocr.lower() == "y"

    asyncio.run(
        main(
            url,
            os.path.join("output", filename),
            use_links,
            template,
            tags_list,
            classes_list,
            use_ocr,
        )
    )
