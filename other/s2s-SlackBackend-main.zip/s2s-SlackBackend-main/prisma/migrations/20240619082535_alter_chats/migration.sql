/*
  Warnings:

  - You are about to drop the column `channelId` on the `Chat` table. All the data in the column will be lost.
  - The `vaultId` column on the `Chat` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `reportId` column on the `Chat` table would be dropped and recreated. This will lead to data loss if there is data in the column.
  - The `sessionId` column on the `Chat` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "Chat" DROP COLUMN "channelId",
DROP COLUMN "vaultId",
ADD COLUMN     "vaultId" INTEGER,
DROP COLUMN "reportId",
ADD COLUMN     "reportId" INTEGER,
DROP COLUMN "sessionId",
ADD COLUMN     "sessionId" INTEGER;
