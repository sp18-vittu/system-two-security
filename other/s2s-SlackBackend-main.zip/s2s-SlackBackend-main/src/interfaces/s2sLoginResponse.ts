interface S2SLoginResponse {
  bearerToken: string;
  responseMessage: string;
  description: string;
  error: string;
  errorDescription: string;
  firstLoginSession: string;
}

export default S2SLoginResponse;