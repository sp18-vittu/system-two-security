interface S2SSessionResponse {
  id: number;
  sessionName: string,
  modifiedDateTime: string,
  createdDateTime: string
}

export default S2SSessionResponse;