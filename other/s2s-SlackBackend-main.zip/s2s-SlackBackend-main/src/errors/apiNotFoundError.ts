import CustomError from "./customError";

class ApiRouteNotFoundError extends CustomError {
  statusCode = 422;

  constructor(message: string = "API Route does not found.") {
    super(message);
  }

  toJson = () => {
    return { status: 'error', errors: [{ message: this.message }] };
  }
}

export default ApiRouteNotFoundError;