import { Prisma } from "@prisma/client";

type urlArgs = Prisma.UrlUpsertArgs;

interface UrlUpsertArgs {
  model: string;
  operation: string;
  args: urlArgs;
  query: Function;
}

export default UrlUpsertArgs;
