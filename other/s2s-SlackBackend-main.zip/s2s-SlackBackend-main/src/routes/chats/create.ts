import { Request, Response, Router } from "express";
import { S2SChat, WorkbenchEvent } from "../../helpers";
import CatchError from "../../errors/catchError";

const router = Router();

router.post('/', async (req: Request, res: Response) => {
  const event = new WorkbenchEvent(req.body);

  try {
    const chat = new S2SChat()
    chat.start(event)
    res.send()
  } catch (err: any) {
    console.log(err.stack);
    const catchErr = new CatchError(event.team, event.user)
    const error = await catchErr.handle()
    res.status(error.statusCode).send(error.toJson());

  }
})

export default router