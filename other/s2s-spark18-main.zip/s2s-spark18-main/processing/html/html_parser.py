import asyncio
import os
import re
from html.parser import HTMLParser
from itertools import zip_longest
from typing import Any, Dict, List, Tuple, cast
from urllib.parse import urljoin, urlparse

import aiohttp
from aiohttp import ClientSession, ClientTimeout
from loguru import logger

import processing.html as ph
import processing.image as pi
import processing.text as pt
import utils
from constants import IMAGE_INDEX
from database.documents import ImageDocument
from services import CoreDbClient

SUPPORTED_IMG_TYPES = ["jpg", "jpeg", "png", "gif", "webp"]
VOID_TAGS = {
    "area",
    "base",
    "br",
    "col",
    "embed",
    "hr",
    "img",
    "input",
    "link",
    "meta",
    "source",
    "track",
    "wbr",
    "path",
    "use",
    "p",
}


class HtmlParser(HTMLParser):
    """
    Format html to plaintext.

    Usage:
        # from url
        parser = HtmlParser(url)
        await parser.parse()
        plaintext = parser.get_parsed_content()

        # from html content string
        parser = HtmlParser()
        await parser.parse(html_content_string)
        plaintext = parser.get_parsed_content()

    - Newlines from within the HTML are removed
    - Repeated newlines/spaces are removed
    - Table columns are separated by |
    - Nested list elements have an additional hyphen added for each nested level
    - Code blocks are wrapped with triple backticks ```
    - In-line code is wrapped with single backticks `
    - Images are either replaced with the alt text, or text extracted by OCR
    - Links are in markdown format [like this](https://www.google.com)

    Args:
    - content (str | None): HTML content string.
    - include_links (bool): Flag to include links in the output in markdown format.
    - header_delimiter (str | None): Delimiter that will be inserted before each
        header.
    - header_level (int | None): Maximum header level that will be used for splitting.
    - ignore_tags (List[str] | None): List of tags to ignore during parsing.
    - ignore_classes (List[str] | None): List of classes to ignore during parsing.
    - ignore_ids (List[str] | None): List of ids to ignore during parsing.
    - ocr (bool): Flag whether to attempt OCR on images.
    """

    def __init__(
        self,
        content: str | None = None,
        include_links: bool = False,
        header_delimiter: str | None = None,
        header_level: int = 9,
        ignore_tags: List[str] | None = None,
        ignore_classes: List[str] | None = None,
        ignore_ids: List[str] | None = None,
        ocr: bool = False,
    ):
        super().__init__()

        self.parsed_content: str = ""
        self.prev_tag: str = ""
        self.list_level: int = 0
        self.list_start: bool = False
        self.inline_code: bool = False
        self.code_block: bool = False
        self.table: bool = False
        self.ignore_data: bool = False
        self.text: str = ""
        self.text_list: List[str] = []
        self.code_list: List[str] = []
        self.link_url: str = ""
        self.link_collect: bool = False
        self.link_text: str = ""
        self.ignore_stack: List[str] = []
        self.img_map: Dict[str, ImageDocument] = {}
        self.use_db: bool = True
        self.force: bool = False
        self.content = content
        self.include_links = include_links
        self.header_delimiter = header_delimiter
        self.max_header_level = header_level
        self.ignore_tags = ["script", "style"]
        self.ignore_classes = ignore_classes
        self.ignore_ids = ignore_ids
        self.ocr = ocr
        self.header_map: Dict[int, str] = {}
        self.errors: List[str] = []

        if ignore_tags:
            self.ignore_tags.extend(ignore_tags)

        if self.content and ph.is_url(self.content):
            self.url = ph.get_clean_url(self.content)
            self.base_url = ph.get_base_url(self.url)
            self.content = None

        self.core_db = CoreDbClient()

    async def parse(
        self,
        data: str | None = None,
        llm_client: Any | None = None,
        use_db: bool = True,
        force: bool = False,
    ) -> None:
        """
        Parse the HTML content.

        If `data` is specified, will parse `data`. Otherwise, will parse the URL or HTML
        content passed to HtmlParser during initialization.

        Args:
        - data (str | None): The HTML content or URL to parse (defaults to None).
        - llm_client (Any | None): LLM client, or None
        - use_db (bool): Whether to use database for images (defaults to True).
        - force (bool): Flag to force processing of images even if they have previously
            been parsed (defaults to False).
        """
        self._reset()
        self.use_db = use_db
        self.force = force

        if data:
            if ph.is_url(data):
                self.url = data
                self.base_url = ph.get_base_url(data)
                await self.fetch_html_content(data)
            else:
                self.content = data
        else:
            url = self.get_url()
            if url:
                await self.fetch_html_content(url)

        if not self.content:
            logger.error(f"Failed to parse {self.get_url()}, no content retrieved")
            return

        self.feed(self.content)

        if self.ocr:
            await self.execute_image_text_extraction(llm_client)

    def handle_starttag(self, tag: str, attrs: List[Tuple[str, str | None]]) -> None:
        try:
            # If we're already ignoring content, increment depth counter
            if self.ignore_data:
                if tag not in VOID_TAGS:
                    self.ignore_stack.append(tag)
                return

            # Check if we want to ignore
            if self.ignore_classes:
                for class_content in self.ignore_classes:
                    for attr in attrs:
                        if (
                            attr[0] == "class"
                            and attr[1] is not None
                            and class_content in attr[1]
                        ):
                            self.ignore_data = True
                            return
            if self.ignore_ids:
                for id in self.ignore_ids:
                    for attr in attrs:
                        if attr[0] == "id" and attr[1] == id:
                            self.ignore_data = True
                            return

            if tag in self.ignore_tags:
                self.ignore_data = True
            elif tag == "table":
                self.text += "\n[TABLE]"
                self.table = True
            elif tag in ["li", "dt"]:
                if self.table:
                    return
                self.list_start = True
                self.list_level += 1
                self.text += "\n" + "-" * self.list_level + " "
            elif tag == "dd":
                if self.table:
                    return
                self.list_start = True
                self.list_level += 2
                self.text += "\n" + "-" * self.list_level + " "
            elif tag in ["p", "div"]:
                if self.list_start and not self.table:
                    return
                elif self.table:
                    if tag == self.prev_tag:
                        self.text += "\\n "
                else:
                    self.text += "\n"
            elif self._is_header(tag):  # header
                self.text += "\n"
                if self.header_delimiter:
                    header_level = self._get_header_level(tag)
                    if header_level and header_level <= self.max_header_level:
                        self.text += self.header_delimiter
                        cur_level = header_level - 1
                        while cur_level and cur_level not in self.header_map:
                            cur_level -= 1
                        if cur_level in self.header_map:
                            self.text += self.header_map[cur_level] + " > "
            elif tag in ["th", "td"] and self.table:
                self.text += " | "
            elif tag in ["br", "tr", "td", "figcaption"]:
                self.text += "\n"
            elif tag == "code":
                if self.code_block:
                    return
                self.inline_code = True
                self.text_list.append(self.text)
                self.text = "`"
            elif tag == "pre":
                self.code_block = True
                self.text_list.append(self.text)
                self.text = "\n```\n"
            elif tag == "img":
                src, alt = "", ""
                for attr in attrs:
                    if attr[0] == "src" and attr[1]:
                        src = attr[1]
                        src_obj = urlparse(src)
                        if src_obj.scheme and src_obj.netloc and src_obj.path:
                            # src contains full path to image
                            continue
                        if src_obj.path:
                            # src contains relative path to image
                            if hasattr(self, "base_url"):
                                src = urljoin(self.base_url, src)
                            else:
                                # will not be able to download image
                                src = ""
                    if attr[0] == "alt" and attr[1]:
                        alt = f"(Image: {attr[1]})"
                if src:
                    # We will enter hash into the text to be replaced later
                    hash = utils.calculate_sha256_string(src)
                    img_base_url = ph.get_base_url(src)
                    img_type = os.path.splitext(src)[-1][1:].lower()
                    self.img_map[hash] = ImageDocument(
                        hash, src, img_base_url, img_type, alt
                    )
                    self.text += hash
                elif alt:
                    # No source for image, next best thing is to use alt text
                    self.text += alt
            elif self.include_links and (tag == "a"):
                for attr in attrs:
                    if attr[0] == "href" and attr[1]:
                        self.link_url = attr[1]
                        self.link_collect = True
        finally:
            self.prev_tag = tag

    def handle_endtag(self, tag: str) -> None:
        if self.ignore_stack:
            if self.ignore_stack[-1] == tag:
                self.ignore_stack.pop()
            return

        self.ignore_data = False

        if tag == "title":
            self.text += "\n"
        elif tag == "tr" and self.table:
            self.text += " |"
        elif tag == "table":
            if self.table:
                self.text += "\n[/TABLE]"
            self.table = False
        elif tag in ["li", "dt"]:
            self.list_start = False
            if self.table:
                return
            self.list_level = max(self.list_level - 1, 0)
        elif tag == "dd":
            self.list_start = False
            if self.table:
                return
            self.list_level = max(self.list_level - 2, 0)
        elif self._is_header(tag) and self.header_delimiter:
            header_level = self._get_header_level(tag)
            if 0 < header_level <= self.max_header_level:
                header_string = self._get_header_string()
                self.header_map[header_level] = header_string
        elif tag in ["h1", "h2", "h3", "h4", "p"] and not self.table:
            self.text += "\n"
        elif tag == "code":
            self.inline_code = False
            if self.code_block:
                return
            self.text += "`"
            self.code_list.append(self.text)
            self.text = ""
        elif tag == "pre":
            self.code_block = False
            self.text += "\n```\n"
            self.code_list.append(self.text)
            self.text = ""
        elif self.include_links and tag == "a" and self.link_url:
            self.text += f"[{self.link_text}]({self.link_url})"
            self.link_text = ""
            self.link_url = ""
            self.link_collect = False
        elif tag == "html":
            # End of html parsing
            pass

    def handle_data(self, data: str) -> None:
        if self.ignore_data:
            return
        if self.inline_code or self.code_block:
            self.text += data
        elif self.link_collect:
            self.link_text += data
        else:
            self.text += self._convert_newlines_to_space(data)

    async def fetch_html_content(self, url: str) -> None:
        error = ""
        timeout = ClientTimeout(
            total=30,  # Total timeout for the request
            connect=5,  # Timeout for establishing a connection
            sock_connect=5,  # Timeout for connecting to the socket
        )
        async with ClientSession(timeout=timeout) as session:
            try:
                async with session.get(
                    url, headers=utils.downloader.USER_AGENT
                ) as response:
                    if response.status == 200:
                        self.content = await response.text()
                    else:
                        error = f"Failed to fetch content from {url}: {response.status}"
                        logger.error(error)
            except aiohttp.ClientConnectionError as cce:
                error = f"Connection error fetching content from {url}: {cce}"
                logger.error(error)
            except aiohttp.ClientResponseError as cre:
                error = f"HTTP error fetching content from {url}: {cre}"
                logger.error(error)
            except aiohttp.ClientPayloadError as cpe:
                error = f"Payload error fetching content from {url}: {cpe}"
                logger.error(error)
            except asyncio.TimeoutError:
                error = f"Request timed out fetching content from {url}"
                logger.error(error)
            except Exception as e:
                error = f"Unexpected error fetching content from {url}: {e}"
                logger.error(error)
        if error:
            self.errors.append(error)

    def get_url(self) -> str | None:
        return self.url if hasattr(self, "url") else None

    def get_base_url(self) -> str | None:
        return self.base_url if hasattr(self, "base_url") else None

    def get_content(self) -> str | None:
        return self.content

    def get_parsed_content(self) -> str:
        if self.parsed_content:
            return self.parsed_content

        if self.text:
            self.text_list.append(self.text)

        for text, code in zip_longest(self.text_list, self.code_list):
            if text:
                text = pt.clean_string(text)
                self.parsed_content += self._remove_empty_lists(text)
            if code:
                self.parsed_content += self._strip_extra_newlines_code(code)

        self.parsed_content = self._replace_image_hashes(self.parsed_content)

        return self.parsed_content

    def get_image_map(self) -> Dict[str, ImageDocument]:
        return self.img_map

    async def execute_image_text_extraction(self, llm_client: Any | None) -> None:
        if not self.img_map:
            logger.debug("No images to process")
            return
        hashes = list(self.img_map.keys())
        async with aiohttp.ClientSession() as session:
            tasks = [self.process_image(session, hash, llm_client) for hash in hashes]
            await asyncio.gather(*tasks)

    async def process_image(
        self, session: ClientSession, hash: str, llm_client: Any | None
    ) -> None:
        # Ignore embedded data, high probability it is not a screenshot
        img_src = self.img_map[hash].url
        if img_src.startswith("data:"):
            logger.debug(f"Ignoring embedded image data: {img_src}")
            return
        if img_src.endswith(".svg"):
            logger.debug(f"Ignoring svg image: {img_src}")
            return

        if not self.force and self.use_db:
            # Check if image has been previously processed
            # TODO: may want to re-process the image if contents have changed
            try:
                img_dict = await self.core_db.get_document(IMAGE_INDEX, hash)
                if img_dict:
                    source = cast(dict, img_dict.get("_source"))
                    logger.debug(f"Using image from database for {source.get('url')}")
                    self.img_map[hash].hash = cast(str, source.get("hash"))
                    self.img_map[hash].text = cast(str, source.get("text"))
                    await self.core_db.upsert(
                        IMAGE_INDEX, hash, {"last_check": utils.get_current_time()}
                    )
                    return
            except Exception as e:
                logger.error(f"Error getting image {hash} from database: {e}")

        img_doc = self.img_map[hash]

        # Download image
        img_bytes = await utils.download_image(session, img_doc.url)
        if isinstance(img_bytes, int):
            msg = f"Error downloading image {img_doc.url}: {img_bytes}"
            logger.error(msg)
            self.errors.append(msg)
            return

        # Check image type
        try:
            img_props = pi.get_image_properties(img_bytes)

            if img_props.type not in SUPPORTED_IMG_TYPES:
                logger.debug(f"Image type not supported ({img_props.type}), skip ocr")
                return

            if img_props.size / (1024 * 1024) > 20:
                logger.debug(f"Image too large ({img_props.size}), skip ocr")
                return
        except Exception as e:
            logger.error(f"Error getting image properties: {e}")

        logger.debug(f"Extracting text from image: {img_doc.url}")
        self.img_map[hash].text = await pi.img_to_text(
            img_bytes, img_doc.type, llm_client
        )
        logger.debug(f"Finished extracting text from image: {img_doc.url}")

        if not self.img_map[hash].text:
            return

        # Update self.img_map
        self.img_map[hash].hash = utils.calculate_sha256_bytes(img_bytes)
        self.img_map[hash].created = utils.get_current_time()

        # Upsert image info to database
        if self.use_db:
            img_dict = self.img_map[hash].to_dict()
            try:
                await self.core_db.upsert(IMAGE_INDEX, hash, img_dict)
            except Exception as e:
                msg = f"Error upserting image {hash} to database: {e}"
                logger.error(msg)
                self.errors.append(msg)

    def _convert_newlines_to_space(self, string: str) -> str:
        # HTML might contain newlines which are just whitespaces to a browser
        pattern = r"[\n\r]+"
        return re.sub(pattern, " ", string)

    def _strip_extra_newlines_code(self, code: str) -> str:
        code = code.replace("\r\n", "\n")
        code = re.sub(r"```\n+", "```\n", code)
        code = re.sub(r"\n+```", "\n```", code)
        return code

    def _remove_empty_lists(self, text: str) -> str:
        pattern = r"(?<=\n)(-+\n)+"
        return re.sub(pattern, "", text)

    def _replace_image_hashes(self, corpus: str) -> str:
        if not self.img_map:
            logger.debug("No images to replace")
            return corpus

        def replace(match: re.Match) -> str:
            key = cast(str, match.group(0))
            img_doc = self.img_map.get(key)
            if not img_doc:
                return key
            if not img_doc.text:
                return img_doc.alt
            return f"[Image Transcript]\n{img_doc.text}\n[/Image Transcript]"

        escaped_keys = [re.escape(key) for key in self.img_map.keys()]
        pattern = "|".join(escaped_keys)
        result = re.sub(pattern, replace, corpus)
        return result

    def _is_header(self, tag: str) -> bool:
        return bool(re.match(r"^h\d+$", tag))

    def _get_header_level(self, tag: str) -> int:
        try:
            return int(tag[1:])
        except ValueError as e:
            logger.error(f"Exception converting header level to int: {e}")
            return 0

    def _get_header_string(self) -> str:
        header = self.text.rsplit(self.header_delimiter, 1)[-1]
        return header.strip()

    def _reset(self) -> None:
        self.parsed_content = ""
        self.prev_tag = ""
        self.list_level = 0
        self.list_start = False
        self.inline_code = False
        self.code_block = False
        self.table = False
        self.ignore_data = False
        self.text = ""
        self.text_list.clear()
        self.code_list.clear()
        self.link_url = ""
        self.link_collect = False
        self.link_text = ""
        self.ignore_stack.clear()
        self.img_map.clear()
        self.header_map.clear()
        self.use_db = True
        self.force = False
        self.errors = []
