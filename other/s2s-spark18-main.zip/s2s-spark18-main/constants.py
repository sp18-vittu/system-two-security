# Embedding
EMBEDDING_MODEL = "text-embedding-3-small"
EMBEDDING_TOKEN_LIMIT = 8192
EMBEDDING_DIMENSIONS = 1536
EMBEDDING_SIMILARITY_THRESHOLD = 0.78
EMBEDDING_DUPLICATE_THRESHOLD = 0.25

# LLM
LLM_DEFAULT_MODEL = "gpt-4-1106-preview"
LLM_DEFAULT_STRUCTURED_MODEL = "gpt-4o-mini-2024-07-18"
INTEL_DB_CHAT_LLM_MODEL = "gpt-4o-2024-05-13"
LLM_CHAR_TOKEN_RATIO = 4  # https://platform.openai.com/tokenizer
LLM_MAX_OUTPUT = 4096
LLM_STRUCTURED_MODELS = ["gpt-4o-2024-08-06", "gpt-4o-mini-2024-07-18"]
LLM_TOKEN_LIMITS = {  # https://platform.openai.com/docs/models/overview
    "gpt-3.5-turbo-1106": {"prompt": 4_000, "response": 4_096, "total": 16_385},
    "gpt-3.5-turbo-0125": {"prompt": 4_000, "response": 4_096, "total": 16_385},
    "gpt-3.5-turbo-16k": {"prompt": 4_000, "response": 4_096, "total": 16_385},
    "gpt-4-1106-preview": {"prompt": 4_000, "response": 4_096, "total": 128_000},
    "gpt-4-0125-preview": {"prompt": 4_000, "response": 4_096, "total": 128_000},
    "gpt-4-turbo-2024-04-09": {"prompt": 4_000, "response": 4_096, "total": 128_000},
    "gpt-4o-2024-05-13": {"prompt": 4_000, "response": 4_096, "total": 128_000},
    "gpt-4o-2024-08-06": {"prompt": 4_000, "response": 16_384, "total": 128_000},
    "gpt-4o-mini-2024-07-18": {"prompt": 4_000, "response": 16_384, "total": 128_000},
}
VISION_DEFAULT_MODEL = "gpt-4-turbo-2024-04-09"

# Core Database
ATTACK_FLOW_INDEX = "attack_flow"
CHAT_INDEX = "chat_message"
CTI_INDEX = "cti"
CTI_SECTION_INDEX = "cti_section"
IMAGE_INDEX = "image"
MITRE_ID = "mitre"
MITRE_INDEX = "mitre"
SIGMA_INDEX = "sigma"
SIGMA_DUPLICATE_INDEX = "sigma_duplicate"
SIGMA_REPLACED_INDEX = "sigma_replaced"
SIGMA_SOURCE_INDEX = "sigma_source"
SIGMAHQ_ID = "sigmahq"
DB_SEARCH_SIZE = 10
KNN_K = 50

# Time format
SIGMA_DATE_FORMAT = "%Y/%m/%d"

# Company
COMPANY_NAME = "System Two Security"
TEMP_MAX_COST = 50.0

# SigmaHQ
SIGMAHQ_RELEASE_URL = "https://github.com/SigmaHQ/sigma/releases/latest"
