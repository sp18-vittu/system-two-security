-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "lastSplitIndex" INTEGER;
