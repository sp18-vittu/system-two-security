image_schema = {
    "settings": {
        "index": {
            "number_of_shards": 1,
            "number_of_replicas": 1,
        }
    },
    "mappings": {
        "properties": {
            "url": {"type": "keyword"},
            "base_url": {"type": "keyword"},
            "type": {"type": "keyword"},
            "hash": {"type": "keyword"},
            "alt": {"type": "text"},
            "text": {"type": "text"},
            "created": {"type": "date"},
            "modified": {"type": "date"},
            "last_check": {"type": "date"},
        }
    },
}
