import { Prisma } from "@prisma/client";

type messageArgs = Prisma.MessageCreateArgs;

interface MessageCreateArgs {
  model: string;
  operation: string;
  args: messageArgs;
  query: Function;
}

export default MessageCreateArgs;
