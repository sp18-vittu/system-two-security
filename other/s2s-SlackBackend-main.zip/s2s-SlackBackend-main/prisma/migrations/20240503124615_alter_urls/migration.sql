/*
  Warnings:

  - A unique constraint covering the columns `[userId,s2sUrlId]` on the table `Url` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "Url_s2sUrlId_key";

-- CreateIndex
CREATE UNIQUE INDEX "Url_userId_s2sUrlId_key" ON "Url"("userId", "s2sUrlId");
