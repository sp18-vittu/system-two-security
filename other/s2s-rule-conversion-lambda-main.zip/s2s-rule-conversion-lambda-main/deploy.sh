#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

# Function to log messages with timestamp
log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1"
}

# Function to retrieve secrets from AWS Secrets Manager and set them as environment variables
load_secrets() {
  local secret_name="$1"
  secret_value=$(aws secretsmanager get-secret-value --secret-id "${secret_name}" --query 'SecretString' --output text)

  # Assuming the secret is in JSON format, parse and export each key-value pair
  for env_var in $(echo "$secret_value" | jq -r 'to_entries | .[] | "export \(.key)=\(.value)"'); do
    eval "$env_var"
  done
}

# Function to generate a new version number based on the current date and a sequence number
generate_version() {
  local date_part
  local latest_version
  local latest_seq
  local new_seq
  date_part=$(date '+%d-%b-%Y')
  latest_version=$(aws ecr describe-images --repository-name "${REPO_NAME}" --query 'sort_by(imageDetails,& imagePushedAt)[-1].imageTags[0]' --output text 2>/dev/null)
  if [[ $latest_version == $date_part* ]]; then
    latest_seq=$(echo "$latest_version" | awk -F'-' '{print $4}')
    new_seq=$((latest_seq + 1))
  else
    new_seq=1
  fi
  echo "${date_part}-${new_seq}"
}

# Function to untag the previous latest image
untag_previous_latest() {
  latest_tag=latest
  previous_latest_image=$(aws ecr describe-images --repository-name "${REPO_NAME}" --filter tagStatus=TAGGED --query "imageDetails[?contains(imageTags, '${latest_tag}')].imageTags[0]" --output text)
  if [ -n "$previous_latest_image" ]; then
    aws ecr batch-delete-image --repository-name "${REPO_NAME}" --image-ids imageTag=latest
    log "Removed 'latest' tag from previous image: ${previous_latest_image}"
  fi
}

# Function to replace placeholders in policy.json with actual values
replace_placeholders() {
  sed -i "s/{{AWS_REGION}}/$AWS_REGION/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{ENVIRONMENT}}/$ENVIRONMENT/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{ACCOUNT_ID}}/$ACCOUNT_ID/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{RECEIVE_QUEUE_FULL_NAME}}/$RECEIVE_QUEUE_FULL_NAME/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{SEND_QUEUE_FULL_NAME}}/$SEND_QUEUE_FULL_NAME/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{STATUS_QUEUE_FULL_NAME}}/$STATUS_QUEUE_FULL_NAME/g" infrastructure/policies/lambda_policy.json
  sed -i "s/{{S3_BUCKET}}/$S3_BUCKET/g" infrastructure/policies/lambda_policy.json
}

# Function to initialize Terraform configuration
initialize_terraform() {
  (
    cd infrastructure || exit
    terraform init
  )
}

# Function to build and push Docker image
build_and_push_docker_image() {
  log "Building Docker image"
  docker build -t "${DOCKER_IMAGE_NAME}" .

  log "Logging in to ECR"
  aws ecr get-login-password --region "${AWS_REGION}" | docker login --username AWS --password-stdin ${ACCOUNT_ID}.dkr.ecr."${AWS_REGION}".amazonaws.com

  if ! aws ecr describe-repositories --repository-names "${REPO_NAME}" --region "${AWS_REGION}" 2>/dev/null; then
    log "Creating ECR repository ${REPO_NAME}"
    aws ecr create-repository --repository-name "${REPO_NAME}" --region "${AWS_REGION}"
  else
    log "ECR repository ${REPO_NAME} already exists"
  fi

  log "Pushing Docker image to ECR"
  docker tag "${DOCKER_IMAGE_NAME}" "${ECR_REPOSITORY}":"${NEW_VERSION}"
  docker push "${DOCKER_IMAGE_NAME}"

  untag_previous_latest

  docker tag "${DOCKER_IMAGE_NAME}" "${ECR_REPOSITORY}":latest
  docker push "${ECR_REPOSITORY}":latest

  echo "${NEW_VERSION}" > VERSION
}

# Function to check and create S3 bucket if necessary
check_and_create_s3_bucket() {
  log "Checking if S3 bucket exists and creating it if necessary"
  if aws s3api head-bucket --bucket s2s-env-"$ENVIRONMENT" 2>/dev/null; then
    log "Bucket s2s-env-$ENVIRONMENT already exists"
  else
    log "Creating S3 bucket s2s-env-$ENVIRONMENT"
    aws s3 mb s3://s2s-env-"$ENVIRONMENT"
  fi
}

# Helper function to run Terraform with common variables
run_terraform() {
  local command=$1
  (
    cd infrastructure || exit
    terraform "$command" -auto-approve \
      -var="environment=$ENVIRONMENT" \
      -var="aws_region=$AWS_REGION" \
      -var="s3_bucket=$S3_BUCKET" \
      -var="account_id=$ACCOUNT_ID" \
      -var="receive_message_queue=$RECEIVE_QUEUE_FULL_NAME" \
      -var="send_message_queue=$SEND_QUEUE_FULL_NAME" \
      -var="send_status_queue=$STATUS_QUEUE_FULL_NAME" \
      -var="lambda_function_name=$LAMBDA_FUNCTION_NAME" \
      -var="queue_arn_root=$QUEUE_ARN_ROOT" \
      -var="lambda_arn_root=$LAMBDA_ARN_ROOT" \
      -var="name=$RECEIVE_QUEUE_NAME" \
      -var="rule_conversion_endpoint=$RULE_CONVERSION_ENDPOINT" \
      -var="docker_image=${ECR_REPOSITORY}:${NEW_VERSION}" \
      -var="vpc_id=${VPC_ID}" \
      -var="private_subnets=${PRIVATE_SUBNETS}" \
      -var="security_group_id=${SECURITY_GROUP_ID}"
  )
}

# Function to apply Terraform configuration
apply_terraform() {
  run_terraform "apply"
}

# Function to destroy Terraform-managed infrastructure
destroy_terraform() {
  run_terraform "destroy"
}

# Main script execution starts here

# Check if exactly one argument is provided (either 'apply' or 'destroy')
if [ "$#" -ne 1 ]; then
  echo "Usage: $0 <apply|destroy>"
  exit 1
fi

# Assign the first argument to ACTION
ACTION=$1

# Load environment variables from .env file
# Enable for local testing.
#log "Loading environment variables from .env file"
#export $(grep -v '^#' .env | xargs -I {} echo {} | xargs)

# Load secrets from AWS Secrets Manager
log "Loading secrets from AWS Secrets Manager"
LAMBDA_FUNCTION_NAME="s2s-${NAME}-lambda-${ENVIRONMENT}"
load_secrets "${ENVIRONMENT}/${LAMBDA_FUNCTION_NAME}"

# Hardcoded values and derived variables
ACCOUNT_ID=143364003363
S3_BUCKET="s2s-env-${ENVIRONMENT}"
QUEUE_ARN_ROOT="arn:aws:sqs:${AWS_REGION}:${ACCOUNT_ID}"
LAMBDA_ARN_ROOT="arn:aws:lambda:${AWS_REGION}"
RECEIVE_QUEUE_FULL_NAME="${ENVIRONMENT}-${AWS_REGION}-${RECEIVE_QUEUE_NAME}-queue"
SEND_QUEUE_FULL_NAME="${ENVIRONMENT}-${AWS_REGION}-${SEND_QUEUE_NAME}-queue"
STATUS_QUEUE_FULL_NAME="${ENVIRONMENT}-${AWS_REGION}-${STATUS_QUEUE_NAME}-queue"
REPO_NAME="s2s-${ENVIRONMENT}/${LAMBDA_FUNCTION_NAME}"
ECR_REPOSITORY="${ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com/${REPO_NAME}"

if [ "$ENVIRONMENT" == "dev" ]; then
  VPC_ID="vpc-0dbe948dfb0c2e795"
  PRIVATE_SUBNETS='["subnet-044f72c1151ae9bf8", "subnet-0f4dd52dcfa9d3821"]'
  SECURITY_GROUP_ID="sg-041939755682ee89b"
fi

# Generate a new version number
NEW_VERSION=$(generate_version)

# Tag the Docker image with the version number
DOCKER_IMAGE_NAME="${ECR_REPOSITORY}:${NEW_VERSION}"

# Replace placeholders in policy.json with actual values
log "Replacing placeholders in policy.json with actual values"
replace_placeholders

# Initialize Terraform configuration
log "Initializing Terraform"
initialize_terraform

if [ "$ACTION" == "apply" ]; then
  build_and_push_docker_image
  check_and_create_s3_bucket
  apply_terraform
elif [ "$ACTION" == "destroy" ]; then
  destroy_terraform
else
  # Print error message if an invalid action is provided
  echo "Invalid action: $ACTION"
  echo "Usage: $0 <apply|destroy>"
  exit 1
fi

log "Deployment complete."
