import { SlackEventType } from "../../../interfaces";
import SlackEvent from "../../../abstracts/slackEvent";
import UrlTitle from "./urlTitle";
import MessageActionHandler from "./messageActionHandler";
import ReportAction from "./reportAction";

class ReportEvent extends SlackEvent {
  url: string = '';
  urlTitle: string = '';

  constructor(event: any) {
    super(event);
    this.url = '';
    this.type = this.determineEventType();
    this.url = this.url?.replace(/\/+$/, '');
    this.url = this.url?.startsWith('https://') ? this.url : `https://${this.url?.replace(/^http:\/\//, '')}`;
  }

  determineEventType(): SlackEventType {
    switch (this._event.type) {
      case 'message_action':
        return new MessageActionHandler(this._event).handle(this);
      default:
        this.url = this._event.text;
        return this._event.command === process.env.ANALYSIS_COMMAND ? SlackEventType.ReportCommand : SlackEventType.Other;
    }
  }

  async handle(): Promise<boolean> {
    try {
      const action = new ReportAction();
      return await action.submit(this);
    } catch (err: any) {
      console.log(err.stack)
      return false
    }
  }

  async fetchTitle(): Promise<void> {
    if (this.url) {
      const title = new UrlTitle(this.url);
      this.urlTitle = await title.fetch();
    }
  }
}

export default ReportEvent;
