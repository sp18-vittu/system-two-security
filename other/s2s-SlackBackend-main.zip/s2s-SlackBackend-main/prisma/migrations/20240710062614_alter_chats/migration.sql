-- DropIndex
DROP INDEX "Chat_userId_key";

-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "channelId" TEXT;
