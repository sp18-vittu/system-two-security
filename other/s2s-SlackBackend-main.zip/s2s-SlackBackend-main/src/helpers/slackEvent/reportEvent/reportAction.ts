
import ReportEvent from ".";
import { S2SUrl, S2SUser, SlackUser } from "../..";
import { SlackMessage } from "../../../services/slack";
import { commandInstruction } from "../../../views"

class ReportAction {
  async submit(event: ReportEvent): Promise<boolean> {
    const slackUser = new SlackUser()
    await slackUser.create(event.user, event.team)

    const s2sUser = new S2SUser(event.user, event.team)
    if (await s2sUser.expired()) return false

    if (event.url) {
      await event.fetchTitle();
      const url = new S2SUrl()
      url.create(event)
      return true
    }
    else {
      const message = new SlackMessage(null, commandInstruction, event.team, event.user)
      await message.send()
      return false
    }
  }
}

export default ReportAction;