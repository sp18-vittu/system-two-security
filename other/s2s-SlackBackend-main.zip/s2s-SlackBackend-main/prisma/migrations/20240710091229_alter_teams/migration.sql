-- AlterTable
ALTER TABLE "Team" ADD COLUMN     "bot_user_id" TEXT;
