from typing import Any

from .cti_parser import CtiParser


class CisaCtiParser(CtiParser):
    """
    A parser for CISA CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            ignore_tags=["header", "footer", "nav"],
            ignore_classes=[
                "skiplinks",
                "usa-banner",
                "c-global-header-btns",
                "breadcrumb",
                "survey",
                "related",
            ],
            ocr=True,
        )
