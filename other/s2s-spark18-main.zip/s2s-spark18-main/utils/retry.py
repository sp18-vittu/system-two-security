import asyncio
import time
from functools import wraps
from typing import Any, Callable

from loguru import logger


def retry(max_tries: int = 5, wait: int = 60) -> Callable:
    def decorator(func: Callable) -> Callable:
        if asyncio.iscoroutinefunction(func):  # async function

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                for attempt in range(1, max_tries + 1):
                    try:
                        result = await func(*args, **kwargs)
                        return result
                    except Exception as e:
                        if attempt < max_tries:
                            logger.warning(
                                f"({attempt}/{max_tries}) Retrying "
                                f"{func.__name__} after {wait} seconds due to "
                                f"{e.__class__.__name__}: {e}"
                            )
                            await asyncio.sleep(wait)
                        else:
                            logger.error(
                                f"({attempt}/{max_tries}) (No retries left) "
                                f"{func.__name__} failed due to {e.__class__.__name__}:"
                                f" {e}"
                            )
                            raise

            return async_wrapper
        else:  # synchronous function

            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                for attempt in range(1, max_tries + 1):
                    try:
                        result = func(*args, **kwargs)
                        return result
                    except Exception as e:
                        if attempt < max_tries:
                            logger.warning(
                                f"({attempt}/{max_tries}) Retrying "
                                f"{func.__name__} after {wait} seconds due to "
                                f"{e.__class__.__name__}: {e}"
                            )
                            time.sleep(wait)
                        else:
                            logger.error(
                                f"({attempt}/{max_tries}) (No retries left) "
                                f"{func.__name__} failed due to {e.__class__.__name__}:"
                                f" {e}"
                            )
                            raise

            return sync_wrapper

    return decorator


def retry_backoff(max_tries: int = 4, start_wait: int = 5) -> Callable:
    def decorator(func: Callable) -> Callable:
        if asyncio.iscoroutinefunction(func):  # async function

            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                # wait = start_wait
                tries = kwargs.pop("max_tries", max_tries)
                init_wait = kwargs.pop("start_wait", start_wait)
                for attempt in range(tries):
                    try:
                        result = await func(*args, **kwargs)
                        return result
                    except Exception as e:
                        if attempt < tries - 1:
                            wait = init_wait * 2**attempt
                            logger.warning(
                                f"({attempt + 1}/{tries}) Retrying "
                                f"{func.__name__} after {wait} seconds due to "
                                f"{e.__class__.__name__}: {e}"
                            )
                            await asyncio.sleep(wait)
                        else:
                            logger.error(
                                f"({attempt + 1}/{tries}) (No retries left) "
                                f"{func.__name__} failed due to {e.__class__.__name__}:"
                                f" {e}"
                            )
                            raise

            return async_wrapper
        else:  # synchronous function

            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                tries = kwargs.pop("max_tries", max_tries)
                init_wait = kwargs.pop("start_wait", start_wait)
                for attempt in range(tries):
                    try:
                        result = func(*args, **kwargs)
                        return result
                    except Exception as e:
                        if attempt < tries - 1:
                            wait = init_wait * 2**attempt
                            logger.warning(
                                f"({attempt + 1}/{tries}) Retrying "
                                f"{func.__name__} after {wait} seconds due to "
                                f"{e.__class__.__name__}: {e}"
                            )
                            time.sleep(wait)
                        else:
                            logger.error(
                                f"({attempt + 1}/{tries}) (No retries left) "
                                f"{func.__name__} failed due to {e.__class__.__name__}:"
                                f" {e}"
                            )
                            raise

            return sync_wrapper

    return decorator
