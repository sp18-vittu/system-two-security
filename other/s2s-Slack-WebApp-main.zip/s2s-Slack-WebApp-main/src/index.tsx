import ReactDOM from "react-dom/client";
import App from "./pages";

import "./styles/index.css";

// Sentry.init({
//   dsn: "https://9d090ce0e93f4dc9b019100a2893e6ca@o1354046.ingest.sentry.io/6637157",
//   integrations: [new BrowserTracing()],
//   tracesSampleRate: 1.0,
// });

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);
root.render(
  // <React.StrictMode>
  <App />
  // </React.StrictMode>
);
