import { Request, Response, Router } from "express";
import moment from "moment";

import { User } from "../../models";
import { S2SLogin } from "../../services/s2s";
import SomethingWentWrongError from "../../errors/somethingWentWrongError";
import { HomeView } from "../../helpers";

const router = Router();

router.put('/login/:id', async (req: Request, res: Response) => {
  try {
    const { email, password, requestDomain } = req.body;
    const s2s = new S2SLogin(email, password, requestDomain);
    const data = await s2s.login();
    if (data.bearerToken) {
      const user = await User.update({
        where: {
          id: req.params.id
        },
        data: {
          email,
          requestDomain,
          s2sToken: data.bearerToken,
          s2sTokenExp: moment().add(24, 'hours').toDate(),
        },
        include: { team: true }
      });

      const homeView = new HomeView()
      await homeView.publish(user.slackId)

      res.status(200).send({ message: 'Login successful', data: { redirectUrl: process.env.SLACK_APP_URL } });
    }
    else {
      res.status(422).send({ message: 'Login Failed' });
    }
  } catch (err: any) {
    console.log(err.stack);
    const error = new SomethingWentWrongError()
    res.status(error.statusCode).send(error.toJson());
  }
})

export default router