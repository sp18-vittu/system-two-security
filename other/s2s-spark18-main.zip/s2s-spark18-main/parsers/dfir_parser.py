from typing import Any

from .cti_parser import CtiParser


class DfirCtiParser(CtiParser):
    """
    A parser for DFIR CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            ignore_tags=["header", "footer", "aside", "nav"],
            ignore_classes=[
                "header",
                "footer",
                "menu",
                "related",
                "skip-link",
                "sharedaddy",
            ],
            ocr=True,
        )
