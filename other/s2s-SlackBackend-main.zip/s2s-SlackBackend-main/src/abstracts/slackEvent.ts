import { SlackEventType } from "../interfaces";

abstract class SlackEvent {
  _event: any;
  type: SlackEventType = SlackEventType.Other;
  triggerId: string = '';
  user: string = '';
  team: string = '';
  view: string = '';
  url: string = '';
  channel: string = '';

  constructor(event: any) {
    this._event = event.payload ? JSON.parse(event.payload) : event;
    this.triggerId = this._event.trigger_id;
    this.user = this._event.user?.id || this._event.user_id;
    this.team = this._event.team?.id || this._event.team_id;
    this.view = this._event.view?.id;
    this.channel = this._event.channel?.id || this._event.channel_id || this._event.view?.private_metadata;
  }

  valid(): boolean {
    return this.type !== SlackEventType.Other;
  }

  abstract handle(): Promise<boolean>;
  abstract determineEventType(): SlackEventType;
}

export default SlackEvent;
