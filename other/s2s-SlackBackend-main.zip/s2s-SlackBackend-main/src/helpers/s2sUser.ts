import { User } from "../models";
import { SlackMessage } from "../services/slack";
import { tokenExpired } from "../views";

class S2SUser {
  constructor(private slackId: string, private teamSlackId: string) { }

  async expired(): Promise<boolean> {
    const [isExpired, user] = await User.s2sTokenExpired(this.slackId)
    if ((!user?.email || isExpired)) {
      tokenExpired[2].accessory!.url = `${process.env.SIGNUP_URL}?user-id=${user?.id}` || '';
      const message = new SlackMessage(null, tokenExpired, this.teamSlackId, this.slackId)
      await message.send()
      return true
    }

    return false
  }
}

export default S2SUser;