import { WorkbenchEvent } from "..";
import { SlackView } from "../../services/slack";
import { focusModel } from "../../views";
import FocusManager from "./focusManager";
import s2sCategory from "./s2sCategory";

class FocusModel {
  private focusManager = new FocusManager();
  private s2sCategories = s2sCategory;

  private async handleView(event: WorkbenchEvent, focus?: string, url?: string, update = false): Promise<void> {
    const selectedFocus = this.s2sCategories.categories.focus.find(f => f.type === focus);
    this.focusManager.updateFocusOptions(this.s2sCategories.categories.focus, selectedFocus!);
    this.focusManager.updateFocusDescription(selectedFocus!); // @ts-ignore

    if (focusModel.blocks[3]) { // @ts-ignore
      focusModel.blocks[3].element.initial_value = url || '';
    } // @ts-ignore

    focusModel.private_metadata = event.channel
    const view = new SlackView(focusModel, event.team);
    if (update) {
      await view.update(event.view);
    } else {
      await view.open(event.triggerId);
    }
  }

  async open(event: WorkbenchEvent, focus: string, url?: string): Promise<void> {
    await this.handleView(event, focus, url);
  }

  async update(event: WorkbenchEvent, focus: string, url?: string): Promise<void> {
    await this.handleView(event, focus, url, true);
  }
}

export default FocusModel;
