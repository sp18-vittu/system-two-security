interface S2SCategoryData {
  categories: Category[];
  metaData: {
    progressText: string
  },
  focus: Focus[]
}

interface Category {
  name: string;
  focus: string;
  graphic?: string;
  default: boolean;
  url_required: boolean;
  questions: string[];
}

interface Focus {
  type: string,
  displayName: string,
  description: string,
}

export { S2SCategoryData, Category, Focus };