/*
  Warnings:

  - A unique constraint covering the columns `[userId,url]` on the table `Url` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "ReportStatus" AS ENUM ('Started', 'Completed', 'Failed');

-- AlterTable
ALTER TABLE "Url" ADD COLUMN     "reportStatus" "ReportStatus" NOT NULL DEFAULT 'Started';

-- CreateIndex
CREATE UNIQUE INDEX "Url_userId_url_key" ON "Url"("userId", "url");
