import prisma from "./prismaClient";
import team from "./team";
import user from "./user";
import url from "./url";
import { message, messageModel } from "./message";

const xprisma = prisma.$extends({
  model: {
    team,
    user,
    message: messageModel
  },
  query: {
    url,
    message,
  }
});

export const User = xprisma.user;
export const Url = xprisma.url;
export const Team = xprisma.team;
export const Chat = xprisma.chat;
export const Message = xprisma.message;