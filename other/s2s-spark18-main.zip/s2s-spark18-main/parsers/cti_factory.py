from typing import Any

import processing.html as ph

from .cisa_parser import CisaCtiParser
from .crowdstrike_parser import CrowdstrikeCtiParser
from .cti_parser import CtiParser
from .default_parser import DefaultCtiParser
from .dfir_parser import DfirCtiParser
from .infoblox_parser import InfobloxCtiParser
from .mandiant_parser import MandiantCtiParser
from .microsoft_parser import MicrosoftCtiParser
from .securonix_parser import SecuronixCtiParser
from .splunk_parser import SplunkCtiParser
from .unit42_parser import Unit42CtiParser
from .welivesecurity_parser import WelivesecurityCtiParser


class CtiParserFactory:
    @staticmethod
    def create_parser(url: str, llm_client: Any | None) -> CtiParser:
        base_url = ph.get_base_url(url)
        if base_url.startswith("https://www.microsoft.com"):
            return MicrosoftCtiParser(url, llm_client)
        elif base_url.startswith("https://www.cisa.gov"):
            return CisaCtiParser(url, llm_client)
        elif base_url.startswith("https://www.securonix.com"):
            return SecuronixCtiParser(url, llm_client)
        elif base_url.startswith("https://blogs.infoblox.com"):
            return InfobloxCtiParser(url, llm_client)
        elif base_url.startswith("https://thedfirreport.com"):
            return DfirCtiParser(url, llm_client)
        elif base_url.startswith("https://www.crowdstrike.com"):
            return CrowdstrikeCtiParser(url, llm_client)
        elif base_url.startswith("https://cloud.google.com"):
            return MandiantCtiParser(url, llm_client)
        elif base_url.startswith("https://www.welivesecurity.com"):
            return WelivesecurityCtiParser(url, llm_client)
        elif base_url.startswith("https://unit42.paloaltonetworks.com"):
            return Unit42CtiParser(url, llm_client)
        elif base_url.startswith("https://www.splunk.com"):
            return SplunkCtiParser(url, llm_client)
        else:
            return DefaultCtiParser(url, llm_client)
