import { ReportStatus, Url, User } from "@prisma/client";
import { S2sInsites } from "../../interfaces";
import { reportGenerating, reportNotification, urlCreated, urlFailed } from "../../views";
import { SlackMessage } from "../../services/slack";
import S2SReport from "./s2sReport";

class ReportMessageView {
  async send(url: Url, oldUrl: Url | null, user: User, teamId: string, insites?: S2sInsites): Promise<any | null> {
    let view: any;

    switch (url.reportStatus) {
      case ReportStatus.Failed:
        view = urlFailed;
        break;
      case ReportStatus.Started:
        view = oldUrl?.reportStatus === ReportStatus.Started ? reportGenerating : urlCreated;
        break;
      case ReportStatus.Completed:
        view = reportNotification;
        break;
    }

    if (oldUrl?.reportStatus !== ReportStatus.Completed || url.reportStatus !== ReportStatus.Started) {
      if (url && url.reportStatus === ReportStatus.Completed) {
        view[1].elements![1].text = ' '
        if (insites) view[1].elements![1].text = S2SReport.reportSummary(insites)
        view[2].text!.text = `*Path:* Repository > Slack Repo > ${url.title}`
        view[3].accessory!.url = `https://${user?.requestDomain}.systemtwosecurity.com`
      }

      const message = new SlackMessage(null, view, teamId, user.slackId)
      await message.send()
    }
  }
}

export default ReportMessageView;