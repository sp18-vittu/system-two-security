import { Status, Prisma } from "@prisma/client"
import prisma from "./prismaClient"

type User = Prisma.UserGetPayload<{ include: { team: true } }>;

const user = {
  async s2sTokenExpired(slackId: string): Promise<[boolean, User]> {
    const user = await prisma.user.findUnique({
      where: {
        slackId,
        team: {
          status: Status.ACTIVE
        }
      },
      include: {
        team: true
      }
    })

    return [(!user?.s2sTokenExp || user.s2sTokenExp <= new Date()), user!]
  }
}

export default user;