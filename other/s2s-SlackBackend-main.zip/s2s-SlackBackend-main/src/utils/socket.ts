import WebSocket from 'ws';
import { Prisma } from '@prisma/client';
import { Message } from '../models';
import { S2SChatMessage } from '../interfaces';
import { S2SChat } from '../helpers';

type Message = Prisma.MessageGetPayload<{ include: { chat: true } }>
interface S2SChatResponse {
  [key: string]: string;
}

class Socket {
  private readonly socket: WebSocket;
  private reponse: S2SChatResponse = {};

  constructor(sessionId: number, sessionName: string, token: string) {
    const socketUrl = `${process.env.S2S_SOCKET_URL}/${sessionId}/${sessionName}?Authorization=${token}`
    this.socket = new WebSocket(socketUrl);

    this.socket.on("close", () => {
      console.log(`Disconnected from the server`);
    });

    this.socket.on("error", (error) => {
      console.log(`connect_error due to ${error}`);
      new S2SChat().serverDown(sessionId);
    });

    this.socket.on('message', this.saveMessage)
  }

  saveMessage(data: any): void {
    const response: S2SChatMessage = JSON.parse(data.toString());
    if (response.done) {
      Message.update({
        where: { id: response.message_id },
        data: {
          response: response.error || this.reponse[response.message_id],
          sources: response.sources,
        }
      }).catch((error) => {
        console.log(`Error saving message ${response.message_id}: ${error}`);
      });
    }
    else if (response.message) {
      if (this.reponse)
        this.reponse[response.message_id] += response.message;
      else
        this.reponse = { [response.message_id]: response.message }

      if (this.reponse[response.message_id].split(' ').length % 50 === 0 && response.message.startsWith(' ')) {
        Message.sendToSlack(response.message_id, this.reponse[response.message_id])
      }
    }
  }

  sendMessage(message: Message): void {
    this.socket.on("open", () => {
      console.log(`Connected to the server`);

      this.socket.send(JSON.stringify({
        message_id: message.id,
        message: message.question,
        cti_id: message.chat.ctiId,
        focus: message.focus,
        vault_id: message.chat.vaultId,
        report_id: message.chat.reportId
      }));
    });
  }
}

export default Socket;
