interface S2sInsites {
  TTPs?: number;
  CVEs?: number;
  IOC?: number;
  SIGMA?: number;
}

export default S2sInsites;