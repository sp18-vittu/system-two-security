import { serverDown } from "../views"
import { SlackMessage } from "../services/slack"
import SomethingWentWrongError from "./somethingWentWrongError"

class CatchError {
  constructor(private teamSlackId?: string, private slackId?: string) { }

  async handle(): Promise<SomethingWentWrongError> {
    if (this.teamSlackId && this.slackId) {
      const message = new SlackMessage(null, serverDown, this.teamSlackId, this.slackId)
      await message.send()
    }
    return new SomethingWentWrongError()
  }
}

export default CatchError;