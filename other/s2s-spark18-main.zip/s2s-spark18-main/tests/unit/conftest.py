from typing import Generator

import pytest
from pytest_mock import MockerFixture

import processing.html as ph
from database import AsyncOpenSearchClient


@pytest.fixture(autouse=True)
def mock_opensearch_client_server(mocker: MockerFixture) -> Generator[None, None, None]:
    """
    A pytest fixture that mocks the OpenSearchClient server calls.
    """
    mocker.patch.object(AsyncOpenSearchClient, "__init__", return_value=None)
    mocker.patch.object(AsyncOpenSearchClient, "info", return_value=None)
    yield


@pytest.fixture(autouse=True)
def mock_html_parser_fetch_html_content(
    mocker: MockerFixture,
) -> Generator[None, None, None]:
    """
    A pytest fixture that mocks the HtmlParser fetch_html_content calls.
    """
    mocker.patch.object(ph.HtmlParser, "fetch_html_content", return_value=None)
    yield
