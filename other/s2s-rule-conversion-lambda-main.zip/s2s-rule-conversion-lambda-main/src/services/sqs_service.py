import json

import boto3


class SQSService:
    def __init__(self, config):
        self.sqs = boto3.client("sqs", region_name=config.aws_region)
        self.config = config

    def send_message(self, queue_url, message_body):
        response = self.sqs.send_message(
            QueueUrl=queue_url, MessageBody=json.dumps(message_body)
        )
        return response
