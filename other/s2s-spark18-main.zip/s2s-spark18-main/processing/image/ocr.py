from typing import Any


async def img_to_text(img_data: bytes, img_type: str, llm_client: Any | None) -> str:
    return "REDACTED"
