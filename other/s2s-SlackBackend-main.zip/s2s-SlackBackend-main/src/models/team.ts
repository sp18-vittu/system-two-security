import { Status } from "@prisma/client"
import { GrantType } from "../interfaces"
import { SlackOAuth } from "../services/slack"
import prisma from "./prismaClient"

const team = {
  async getSlackAccessToken(slackId: string): Promise<string | null> {
    const team = await prisma.team.findUnique({
      where: {
        slackId,
        status: Status.ACTIVE
      }
    })

    if (team) {
      const slackToken = new SlackOAuth()
      const token = await slackToken.getAccessToken(team.refreshToken, GrantType.RefreshToken)
      await prisma.team.update({
        where: {
          id: team.id
        },
        data: {
          refreshToken: token.refresh_token
        }
      })

      return token.access_token
    }
    return null
  }
}

export default team;