# AWS Lambda for SQS and S3 Integration

This project contains an AWS Lambda function that reads a JSON object from an SQS receive queue, processes it, writes a JSON object to a response queue, stores the response object in an S3 bucket, and sends a status message to a status queue.

## Directory Structure

```
.
├── lambda_function.py
├── requirements.txt
├── .env
├── services
│   ├── __init__.py
│   ├── s3_service.py
│   ├── sqs_service.py
├── utils
│   ├── __init__.py
│   ├── config.py
├── infrastructure
│   ├── main.tf
│   ├── variables.tf
│   ├── outputs.tf
│   ├── policies
│   │   └── lambda_policy.json
│   └── deploy.sh
└── README.md
```

## Setup

### Prerequisites

- Python 3.7+
- AWS Account
- AWS CLI configured with appropriate permissions
- AWS SAM CLI for local testing
- Terraform for infrastructure as code

#### Installing AWS SAM CLI

Follow the instructions [here](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html) to install AWS SAM CLI.

##### macOS (using Homebrew)

```sh
brew tap aws/tap
brew install aws-sam-cli
```

##### Ubuntu

```sh
sudo apt-get update
sudo apt-get install -y unzip
curl -Lo sam-installation.zip https://github.com/aws/aws-sam-cli/releases/latest/download/aws-sam-cli-linux-x86_64.zip
unzip sam-installation.zip -d sam-installation
sudo ./sam-installation/install
```

##### Red Hat Linux

```sh
sudo yum update -y
sudo yum install -y unzip
curl -Lo sam-installation.zip https://github.com/aws/aws-sam-cli/releases/latest/download/aws-sam-cli-linux-x86_64.zip
unzip sam-installation.zip -d sam-installation
sudo ./sam-installation/install
```

#### Installing Terraform

Follow the instructions [here](https://learn.hashicorp.com/tutorials/terraform/install-cli) to install Terraform.

##### macOS (using Homebrew)

```sh
brew tap hashicorp/tap
brew install hashicorp/tap/terraform
```

##### Ubuntu

```sh
sudo apt-get update
sudo apt-get install -y gnupg software-properties-common curl
curl -fsSL https://apt.releases.hashicorp.com/gpg | sudo apt-key add -
sudo apt-add-repository "deb [arch=amd64] https://apt.releases.hashicorp.com $(lsb_release -cs) main"
sudo apt-get update
sudo apt-get install terraform
```

##### Red Hat Linux

```sh
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
sudo yum -y install terraform
```

### Installation

1. Clone the repository:

   ```sh
   git clone <repository-url>
   cd <repository-directory>
   ```

2. Create a virtual environment and activate it:

   ```sh
   python -m venv venv
   source venv/bin/activate
   ```

3. Install the dependencies:

   ```sh
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the root directory with the following content:

   ```env
   ENVIRONMENT=dev
   AWS_REGION=us-east-1
   RECEIVE_QUEUE_NAME={{RECEIVE_QUEUE_NAME}}
   SEND_QUEUE_NAME={{SEND_QUEUE_NAME}}
   STATUS_QUEUE_NAME={{STATUS_QUEUE_NAME}}
   REQUEST_QUEUE_URL={{REQUEST_QUEUE_URL}}
   RESPONSE_QUEUE_URL={{RESPONSE_QUEUE_URL}}
   STATUS_QUEUE_URL={{STATUS_QUEUE_URL}}
   RULE_CONVERSION_ENDPOINT={{RULE_CONVERSION_ENDPOINT}}
   ```

## Usage

### Running the Lambda Locally with AWS SAM

1. Build the SAM application:

   ```sh
   sam build
   ```

2. Create a test event JSON file (`event.json`):

   ```json
   {
     "Records": [
       {
         "body": "{\"request_id\": \"abc123\", \"tenant_id\": \"tenant42\", \"target\": \"splunk\", \"caller\": \"api\", \"scope\": \"hunt\", \"location\": \"s3://s2s-env-dev/tenant42/hunt/20240702\", \"config\": \"base64 encoded splunk config\", \"pipeline\": \"s3 location of pipeline\", \"data\": {\"type\": \"results\", \"format\": \"normalized\", \"query_id\": \"q001\", \"log_sources\": [\"O365\"], \"parent_query_id\": \"q000\", \"query_state\": \"completed\", \"query\": \"search index=main sourcetype=access_combined status=200\", \"timestamp\": \"2024-07-02T12:00:00Z\", \"additional_info\": \"Query for successful access logs\", \"path\": \"S3 path for the results\"}}"
       }
     ]
   }
   ```

3. Invoke the Lambda function locally:

   ```sh
   sam local invoke MyLambdaFunction --event event.json
   ```

### Deploying the Lambda to AWS

1. Ensure Terraform is installed and initialize it within the `infrastructure` directory:

   ```sh
   cd infrastructure
   terraform init
   cd ..
   ```

2. Apply the Terraform configuration and deploy the Lambda function:

   ```sh
   ./deploy.sh apply
   ```

3. Destroy the Lambda function and associated resources:

   ```sh
   ./deploy.sh destroy
   ```

### Environment Variables

- `ENVIRONMENT`: The deployment environment (e.g., dev, prod).
- `AWS_REGION`: The AWS region where resources are located.
- `S3_BUCKET`: The name of the S3 bucket.
- `RECEIVE_QUEUE_NAME`: The name of the SQS receive queue.
- `RESPONSE_QUEUE_URL`: The URL of the SQS response queue.
- `STATUS_QUEUE_URL`: The URL of the SQS status queue.
- `ACCOUNT_ID`: The AWS account ID.
- `QUEUE_ARN_ROOT`: The ARN root for the SQS queues.
- `LAMBDA_ARN_ROOT`: The ARN root for the Lambda functions.

## Code Overview

### `lambda_function.py`

- Main handler for the Lambda function.
- Processes incoming SQS messages, writes response messages to another SQS queue, stores response messages in S3, and sends status messages to a status queue.

### `services/sqs_service.py`

- Contains the `SQSService` class to handle SQS operations (sending messages).

### `services/s3_service.py`

- Contains the `S3Service` class to handle S3 operations (uploading JSON objects).

### `utils/config.py`

- Contains the `Config` class to load environment variables using `dotenv`.

## Testing

- To test locally, use AWS SAM CLI:

  ```sh
  sam local invoke MyLambdaFunction --event event.json
  ```

- Ensure the `.env` file is properly set up for local testing.