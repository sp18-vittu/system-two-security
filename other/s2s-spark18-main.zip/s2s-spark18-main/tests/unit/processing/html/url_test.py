import pytest

import processing.html as ph


@pytest.mark.parametrize(
    "url, expected",
    [
        ("/usr/local/bin", ""),
        ("C:\\Program Files\\Adobe", "c:"),
        ("random", ""),
        ("/content/images/1.jpg", ""),
        ("www.google.com", ""),
        ("https://www.google.com", "https://www.google.com"),
        ("https://www.google.com/other#1", "https://www.google.com"),
    ],
)
def test_get_base_url(url: str, expected: str) -> None:
    """Tests `get_base_url()` returns proper base URL for various inputs"""
    assert ph.get_base_url(url) == expected


@pytest.mark.parametrize(
    "input_url, expected_clean_url",
    [
        ("http://example.com/", "http://example.com"),
        ("http://example.com////", "http://example.com"),
        (
            "https://www.python.org/dev/peps/pep-0249/#exceptions",
            "https://www.python.org/dev/peps/pep-0249",
        ),
        ("ftp://example.com/some/path/", "ftp://example.com/some/path"),
        ("https://example.com?query=param", "https://example.com"),
        ("https://example.com#fragment", "https://example.com"),
        ("", ""),  # Assuming the function should handle empty strings
        ("http://[::1]/", "http://[::1]"),  # IPv6 address
        ("http://example.com:8080/path/", "http://example.com:8080/path"),
        ("file:///C:/path/to/file.txt", "file:///C:/path/to/file.txt"),
        (
            "https://example.com/path/with/trailing/slash/",
            "https://example.com/path/with/trailing/slash",
        ),
        (
            "https://example.com/multiple//slashes///together",
            "https://example.com/multiple//slashes///together",
        ),
        ("/usr/local/bin", "/usr/local/bin"),
        ("C:\\Program Files\\Adobe", "c:\\Program Files\\Adobe"),
        ("random", "random"),
        ("/content/images/1.jpg", "/content/images/1.jpg"),
    ],
)
def test_get_clean_url(input_url: str, expected_clean_url: str) -> None:
    """Test get_clean_url returns expected cleaned url for various input urls"""
    assert ph.get_clean_url(input_url) == expected_clean_url


@pytest.mark.parametrize(
    "url, expected",
    [
        ("/usr/local/bin", False),
        ("C:\\Program Files\\Adobe", False),
        ("random", False),
        ("/content/images/1.jpg", False),
        ("www.google.com", False),
        ("https://www.google.com", True),
        ("https://www.google.com/other#1", True),
    ],
)
def test_is_url(url: str, expected: bool) -> None:
    """Tests `that is_url()` returns expected bool for various inputs"""
    assert ph.is_url(url) == expected
