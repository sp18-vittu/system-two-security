from typing import Any

from .cti_parser import CtiParser


class SplunkCtiParser(CtiParser):
    """
    A parser for Splunk CTI reports.

    Args:
    - url (str): CTI report URL
    - openai_client (Any | None): OpenAIClient, or None
    """

    version = "1.0.0"

    def __init__(
        self,
        url: str,
        openai_client: Any | None = None,
    ) -> None:
        super().__init__(
            url,
            openai_client,
            ignore_classes=[
                "skipMainContent",
                "globalcomponent-enabler-header",
                "globalcomponent-enabler-footer",
                "latestblog",
                "about-splunk",
                "subscribe",
                "headerSocialIconsSection",
                "sidebar",
                "sub-nav",
            ],
            ocr=True,
        )
