import { focusModel, urlInput } from "../../views";
import { Focus } from "../../interfaces";

class FocusManager {
  updateFocusDescription(focus: Focus): void {
    try {
      focusModel.blocks = focusModel.blocks.slice(0, 3);
      focusModel.blocks[0].text.text = `*Your current workbench focus is set to ${focus.displayName}.*`
      focusModel.blocks[2].text.text = focus.description
      if (focus.type === 'cti') { // @ts-ignore
        focusModel.blocks.push(urlInput)
      }
    } catch (err: any) {
      console.error(err.stack);
    }
  }

  updateFocusOptions(allFocus: Focus[], focus: Focus): void {
    const options = allFocus.map(focus => ({
      text: { type: 'plain_text', text: focus.displayName }, value: focus.type
    }));// @ts-ignore
    focusModel.blocks[1].accessory!.options = options;
    if (focus) focusModel.blocks[1].accessory!.initial_option = {
      text: { type: 'plain_text', text: focus.displayName }, value: focus.type
    };
  }
}

export default FocusManager;
